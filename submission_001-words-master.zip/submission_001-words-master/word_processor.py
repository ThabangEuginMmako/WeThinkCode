import operator


def split(delimiters, text):
    """
    Splits a string using all the delimiters supplied as\
    input string
    :param delimiters:
    :param text: string containing delimiters to use to\
    split the string, e.g. `,;? `
    :return: a list of words from splitting text using\
    the delimiters
    """

    import re
    regex_pattern = '|'.join(map(re.escape, delimiters))
    return re.split(regex_pattern, text, 0)


def convert_to_word_list(text):
    """converts a string into a list of lowercased words\
    without special characters"""
    text = text.lower()
    rem_specialchar_text = split(". , ; : ?", text)
    filtered_lst = list(filter(lambda char: False if char ==
                        '' else True, rem_specialchar_text))
    return filtered_lst


def words_longer_than(length, text):
    """returns only the words that are longer than the given\
    length"""
    words = split(". , ; : ?", text)
    long_than_words = filter(lambda word: len(word) > length, words)
    lst_long_than = list(long_than_words)
    return lst_long_than


def words_lengths_map(text):
    """returns a dictionary with the lengths of every word and\
    how many times that given length occurs"""
    rem_specialchar_text = split(". , ; : ?", text)
    filtered_lst = list(filter(lambda char: False if char ==
                        '' else True, rem_specialchar_text))
    mapped_lenght_list = list(map(lambda word: len(word), filtered_lst))
    set_lenght = set(mapped_lenght_list)
    lst_lenght = list(set_lenght)
    mapped_lst = list(map(lambda x: mapped_lenght_list.count(x), lst_lenght))
    dictionary = dict(zip(lst_lenght, mapped_lst))
    return dictionary


def letters_count_map(text):
    """returns a dictionary containing all the letters of the alphabet\
    and how many times each letter occurs in a given string"""
    text = text.lower()
    rem_specialchar_text = split(". , ; : ?", text)
    lst_letters = list(str(rem_specialchar_text))
    alphabets = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l',
                 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
    mapped_lst_alphabets = list(map(lambda x: lst_letters.count(x), alphabets))
    dictionary = dict(zip(alphabets, mapped_lst_alphabets))
    return dictionary


def most_used_character(text):
    """returns the most frequently occuring letter in a string"""
    if text == '':
        return (None)
    else:
        letters_count = letters_count_map(text)
        max_key_value_pair = max(
            letters_count.items(), key=operator.itemgetter(1))
        return max_key_value_pair[0]


def run_prog():
    """Calls all the user defined functions and runs the program\ 
    then prints the output from all function calls"""

    text = 'These are indeed interesting, an obvious understatement, times. What say you?'
    length = 10

    print(convert_to_word_list(text))
    print(words_longer_than(length, text))
    print(words_lengths_map(text))
    print(letters_count_map(text))
    print(most_used_character(text))


if __name__ == "__main__":
    run_prog()
