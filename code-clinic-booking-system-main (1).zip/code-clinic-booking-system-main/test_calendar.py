import unittest
import code_clinic
from unittest.mock import patch 
from io import StringIO 
from test_base import captured_io
import sys
sys.stdout = StringIO()
class TestClinic(unittest.TestCase):
    
    def test_getting_user_calendar(self):
        with captured_io(StringIO('1\noff')) as (out, err):
            code_clinic.start()
            
            output = out.getvalue().strip()
            
            
            self.assertEqual("""welcome to the code clinic booking system! 
What must i do next: Getting the upcoming events for the next seven days.
""",output[:118])
            
    def test_getting_code_clinic_calendar(self):
        with captured_io(StringIO('2\noff')) as (out, err):
            code_clinic.start()
            
            output = out.getvalue().strip()
            
            
            self.assertEqual("""welcome to the code clinic booking system! 
What must i do next: Getting events for the next seven days: """,output[:105])
            
            
if __name__ == '__main__':
    unittest.main()