import unittest
import code_clinic
from unittest.mock import patch 
from io import StringIO 
from test_base import captured_io
import sys
sys.stdout = StringIO()
class TestCodeClinic(unittest.TestCase):
    
    def test_off_function(self):
        with captured_io(StringIO('off\n')) as (out, err):
            code_clinic.start()
            
            output = out.getvalue().strip()
            
            self.assertEqual("""welcome to the code clinic booking system! 
What must i do next: Thank you for using the code clinic booking system.""",output)
            
    def test_help_fucntion(self):
        with captured_io(StringIO('help\noff\n')) as (out, err):
            code_clinic.start()
    
    
        output = out.getvalue().strip()

        self.assertEqual("""welcome to the code clinic booking system! 
What must i do next: Press the corresponding key to what you'd want to do:
1. View your available events for the next seven days.
2. View the code clinic events/slots for the next 7 days.
3. Allows user to make a booking as a volunteer.
4. Allows user to make a booking as a student.
5. Allows a student to make a cancelation.
6. Allows volunteer to create a cancelation.
To logout type 'off'
What must i do next: Thank you for using the code clinic booking system.""",output)
        
        
    
        
    def test_welcome(self):
        name='clinic'
        self.assertEqual(code_clinic.welcome_message(name),'clinic')
        
    def test_get_command(self):
            with captured_io(StringIO('off\n')) as (out, err):
                code_clinic.start()
                output = out.getvalue().strip()
                
            self.assertEqual("""welcome to the code clinic booking system! 
What must i do next: Thank you for using the code clinic booking system.""",output)
    
    
    @patch("sys.stdin", StringIO("1\n"))
    def test_corresponding_key_correct(self):
        self.assertEqual(code_clinic.corresponding_key(),'1')
        
        
        
    def test_path_directory_exists(self):
        self.assertFalse(code_clinic.create_dirs())
        
        
    # def test_path_directory_not_exist(self):
    #     self.assertTrue(code_clinic.create_dirs())
    
    
      
   
    
        
    
if __name__ == '__main__':
    unittest.main()