# import datetime

# current_date = "12/6/20"
# current_date_temp = datetime.datetime.strptime(current_date, "%m/%d/%y")
# new_date = current_date_temp + datetime.timedelta(days=5)

# print(new_date)
hope=1
print(hope)
hope-=1
print(hope)

