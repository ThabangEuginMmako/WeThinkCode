
from getpass import getpass
import json
import re 
import os
from Login import registration
from configuration import configure







filePath = '/home/wtc/code_clinic/data_files/'


def get_email():
    count=0
    regex="[\w-]{3,20}@\w{2,20}\.\w{2,20}\.\w{2,3}\.\w{2,3}$"
    print("Please fill in the details below to login: ")
    email=input("Enter Your Email Address:\n ")
    while email =='':
        email=input("Enter Your Email Address:\n ")
        
    split_email=email.split('@')
    while email!="":
        if re.search(regex,email) and split_email[1] in ['student.wethinkcode.co.za']:

            return email
        else:
            if count<3:
                print("Incorrect email format (username@student.wethinkcode.co.za): ")
                email=input("Enter Your Email Address:\n ")
                count=count+1
                #return email
            else:
                reg=input("Account doesn't exist with us, would you like to register instead?\ny/n:  ")
                if reg not in ['y','n']:
                    reg=input("Account doesn't exist with us, would you like to register instead?\ny/n:  ")
                elif reg=='y':
                    return registration.registration()
                elif reg=='n':
                    login_creds()

    
def get_password():
    count=0
    reg = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!#%*?&]{8,18}$"
    # password=input("Enter password:\n ")
    password=getpass("Enter password:\n ")
    while password =='':
        password=getpass("Enter password:\n ")
    if password!="":
        if re.search(reg,password):

            return password
        else:
            if count<3:
                print("Incorrect password formart:8 charecter long with uppercase,charecter,number ): ")
                password=input("Enter Your password:\n ")
                count=count+1
                
            else:
                reg=input("Account doesn't exist with us, would you like to register instead?\ny/n:  ")
                if reg not in ['y','n']:
                    reg=input("Account doesn't exist with us, would you like to register instead?\ny/n:  ")
                elif reg=='y':
                    return registration.registration()
                elif reg=='n':
                    login_creds()
    
                   
                    
def reg_que():
    reg=input("Would you like to register your account first? \ny/n:  ")
    if reg not in ['y','n']:
        return reg_que()
    elif reg.lower()=='y':
        return registration.registration()
    elif reg.lower()=='n':
        return login_creds()                    
                    
                    
                    
count=0
def validate_input(email,password):
    global count

    
    if os.path.exists(filePath + email + '.json'):
        
        with open(filePath + email + '.json','r') as myfile:
            data=myfile.read()
            obj = json.loads(data)
            
    else:
        reg_que()
                    


def login_creds():
    
    
    email=get_email()
    password=get_password()
    validate_input(email,password)
    return email,password




def readFile():
    with open('json_data.json') as json_file:


        pass
  
    
def Save_To_file():
    pass



