
import json
import re 

from Login import login

filePath = '/home/wtc/code_clinic/data_files/'

''''''''
def get_username():
    name = input("Enter name: ")
    while len(name) == 0:
        name = input("Enter name: ")
    return name


def validate_input_registration(username,email,password):
    
    #regex = '^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$' 
    split_email=email.split('@')
    regex="[\w-]{1,20}@\w{2,20}\.\w{2,20}\.\w{2,3}\.\w{2,3}$"
    reg = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!#%*?&]{8,18}$"

    if re.search(reg,password) and re.search(regex,email) and split_email[1] in ['student.wethinkcode.co.za']:
        
        dic={"username":username,"email":email,"password":password}
        with open(filePath + email + '.json','w') as fp:
                
                
                json.dump(dic,fp)
        print("You have registered")      
    else:   
        print("Incorrect format, please try again")
        return registration()

def registration():
    print("Please register your account.")
    username=get_username()
    email=login.get_email()
    password=login.get_password()
    validate_input_registration(username,email,password)
    login.login_creds()
    
    return email,password
        
        
    
    
   
    

    



