from textwrap import indent
from googleapiclient.discovery import build
from configuration import configure
import datetime
from googleapiclient.errors import HttpError
import json
import re 
from prettytable import PrettyTable




def getCalendar(getConf):
    
    """Gets the user calendar and tabulates it."""
    
    service = build('calendar', 'v3', credentials=getConf)
    data={}
    newTable = PrettyTable(["count","Event", "Time","id"]) 
    count=1

    try:
        # Call the Calendar API
        now = datetime.datetime.utcnow()
        now=(now+datetime.timedelta(hours=2))
        max=(now+datetime.timedelta(days=7)).isoformat()[:-7] +'Z'
        print('Getting the upcoming events for the next seven days.')
        print("You're currently viewing your calendar")
        events_result = service.events().list(calendarId='primary', timeMin=now.isoformat()[:-7] +"Z",
                                              timeMax=max, singleEvents=True,
                                              orderBy='startTime').execute()
        events = events_result.get('items', [])
        
        #reading from a file
        with open('Events.json','w')as fp:
                json.dump(events,fp)
                
        if not events:
            print('No upcoming events found.')
            return
    
        for event in events:
            start = event['start'].get('dateTime', event['start'].get('date'))
            #print(event)
            newTable.add_row([count,event['summary'],start,event["id"]])  
            count=count+1
          
           
    
          
    except HttpError as error:
        print('An error occurred: %s' % error)
    print(newTable)  
        
def codeClinics(getConf):
    """Gets the code_clinic calndar and tabulates it"""
    
    service = build('calendar', 'v3', credentials=getConf)
    data={}
    newTable = PrettyTable(["count","Event", "Time","id"]) 
    count=1
    
    try:
        # Call the Calendar API
        now = datetime.datetime.utcnow()
        now=(now+datetime.timedelta(hours=2))
        max=(now+datetime.timedelta(days=7)).isoformat()[:-7] +'Z'
        print('Getting events for the next seven days: ')
        print("You're currently viewing the code clinic calendar")
        events_result = service.events().list(calendarId='codeclinicsystem@gmail.com', timeMin=now.isoformat()[:-7] + 'Z',
                                              timeMax=max, singleEvents=True,
                                              orderBy='startTime').execute()
        events = events_result.get('items', [])
        #reading from a file
        with open('code_clinic.json','w')as fp:
                json.dump(events,fp)               
        if not events:
            print('No upcoming events found.')
            return
       
       
        for event in events:
            start = event['start'].get('dateTime', event['start'].get('date'))
            newTable.add_row([count,event['summary'],start,event['id']]) 
            count=count+1
            #print(start, event['summary'])

            
       
    except HttpError as error:
        print('An error occurred: %s' % error)
    print(newTable)
   
   
   # Call the Calendar API
def display():
    with open('Events.json', 'r') as myfile:
        data=myfile.read()

# parse file
    obj = json.loads(data)
    count=0
   
    for i in range(len(obj)):
       
        for key, val in obj[i].items():
            if key=="summary" or key=="id" or key=="organizer" or key=="start" or key=="end":
                
                print("{} : {}".format(key, val))
   
    
def codeClinic(getConf):
    page_token = None
    calendar_ids = []
    service = build('calendar', 'v3',  credentials=getConf)
    while True:
        calendar_list = service.calendarList().list(pageToken=page_token).execute()
        for calendar_list_entry in calendar_list['items']:
            if '@qxf2.com' in calendar_list_entry['id']:
                calendar_ids.append(calendar_list_entry['id'])
        page_token = calendar_list.get('nextPageToken')
        if not page_token:
            break


    
    
    
    
   
    
    

    
