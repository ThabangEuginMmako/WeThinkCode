import os
from calendars import calendars
from booking import booking_volunteer,booking_student
from cancelations import student_cancelation,volunteer_cancelation
from configuration import configure
import datetime as dt
from prettytable import PrettyTable
from Login import login,registration
import sys
import code_clinic
def print_welcome():
    print("welcome to the code clinic booking system!")

if sys.argv[1].lower() in ['view_calendar']:
    if not os.path.isfile('token.json'):
        email,password=login.login_creds()
        print_welcome()
        # username=login.get_user_Info()
        conf=configure.main()
    else:
        print_welcome()
        conf=configure.main()
    calendars.getCalendar(conf)
        
        
elif sys.argv[1].lower() in ['cc_calendar']:
    if not os.path.isfile('token.json'):
        email,password=login.login_creds()
        print_welcome()
        conf=configure.main()
    else:
        print_welcome()
        conf=configure.main()
    calendars.codeClinics(conf)
    
elif sys.argv[1].lower() in ['volunteer_book']:
    if not os.path.isfile('token.json'):
        email,password=login.login_creds()
        print_welcome()
        conf=configure.main()
    else:
        print_welcome()
        conf=configure.main()
    calendars.codeClinics(conf)
    booking_volunteer.v_booking(conf)

elif sys.argv[1].lower() in ['student_book']:
    if not os.path.isfile('token.json'):
        email,password=login.login_creds()
        print_welcome()
        conf=configure.main()
    else:
        print_welcome()
        conf=configure.main()
    calendars.codeClinics(conf)
    booking_student.student_booking(conf)
    
elif sys.argv[1].lower() in ['student_cancel']:
    if not os.path.isfile('token.json'):
        email,password=login.login_creds()
        print_welcome()
        conf=configure.main()
    else:
        print_welcome()
        conf=configure.main()
    calendars.codeClinics(conf)
    student_cancelation.student_cancelation(conf)
    
elif sys.argv[1].lower() in ['volunteer_cancel']:
    if not os.path.isfile('token.json'):
        email,password=login.login_creds()
        print_welcome()
        conf=configure.main()
    else:
        print_welcome()
        conf=configure.main()
    calendars.codeClinics(conf)
    volunteer_cancelation.cancelation_volunteer(conf)
    
elif sys.argv[1].lower() in ['help']:
    print(code_clinic.help_arguments())