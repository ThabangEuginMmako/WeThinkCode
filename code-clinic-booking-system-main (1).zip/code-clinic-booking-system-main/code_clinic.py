import os
from pickle import TRUE
from calendars import calendars
from booking import booking_volunteer,booking_student
from cancelations import student_cancelation,volunteer_cancelation
from configuration import configure
import datetime as dt
from prettytable import PrettyTable
from Login import login,registration
import json
cal=True
hel=True

filePath = '/home/wtc/code_clinic'

def user_entry_options():
    """Login/registration oprtion"""
    
    options="""Welcome the code clinic booking system!
Please click the corresponding key to the options below:
1. Login
2. Register acoount"""
    return options

def corresponding_key():
    """Prompts user for login/registration option"""
    
    user=input("Enter corresponding key: ")
    while user.lower() not in ['1','2']:    
        user= input ("Enter corresponding key: ")
        
    
    return user


def command_handle_registration_login(command):
    if command == '1':
        login.login_creds()
        return True
        
    if command == '2':
        registration.registration()
        return True
    
    if command == 'off':
        signing_out_message()
        return cal== False
    
    return True
    

def get_command():
    command = input("What must i do next: ")
    while len(command) == 0:
        command = input("what must i do next: ")
    return command


def welcome_message(name):
    print(f"Welcome {name}!")
    return name
    


def signing_out_message():
    print(f"Thank you for using the code clinic booking system.")


def create_dirs():
    """Creates the path directory"""
    if not os.path.exists(filePath):
        os.mkdir(filePath)
        os.mkdir(filePath+ '/data_files')
        return True
    return False
        
def help_arguments():
    
    """List of all the available functionalities"""
    
    args="""The following arguments can be passes to access the corresponding fucntionalities:
    help: Displays the available arguments and functionalites.
    
    view_calendar: Displays the user calendar.
    
    code_clinic_calendar: Displays the code clinic calendar.
    
    volunteer_booking: Displays code clinic calendar and allows user to book as a volunteer.
    
    student_booking: Displays code clinic calendar and allows user to book only on available slots.
    
    student_cancelation: Allows user to cancel booking.
    
    volunteer_cancelation: Allows volunteer to cancel the slot if no user has attended."""
    
    return args
  

def help_function_after_login():
    """List of all the available functionalities"""
    
    
    help_a ="""Press the corresponding key to what you'd want to do:
1. View your available events for the next seven days.
2. View the code clinic events/slots for the next 7 days.
3. Allows user to make a booking as a volunteer.
4. Allows user to make a booking as a student.
5. Allows a student to make a cancelation.
6. Allows volunteer to create a cancelation.
To logout type 'off'"""
    print (help_a)
    
def next(name):
    """Prompts user what to do next"""
    
    next= input(f"What would you like to do {name}? ")
    if len(next)==0:
        next=input(f"What would you like to do {name}?")
    return next


def print_welcome():
    print("welcome to the code clinic booking system! ")

def command_handle(command,conf):
    """Handles all the commands of the app"""
    if command=='help':
            (help_function_after_login())
    elif command=='off':
        signing_out_message()
        return cal==False
    elif command=='1':
        calendars.getCalendar(conf)
        user_entry_options()
    elif command=='2':
        calendars.codeClinics(conf)
    elif command=='3':
        booking_volunteer.v_booking(conf)
    elif command=='4':
        booking_student.student_booking(conf)
        
    elif command=='5':
        student_cancelation.student_cancelation(conf)
        
    elif command== '6':
        volunteer_cancelation.cancelation_volunteer(conf)
    return True
 
 
                
                
def start():
    """For the full user experience, this code is ran"""
    cal==True
    create_dirs()
    if not os.path.isfile('token.json'):
        print(user_entry_options())
        command=corresponding_key()
        command_handle_registration_login(command)
    print_welcome()
    conf=configure.main()
    command=get_command()
    while command_handle(command,conf):
        command=get_command()
  
if __name__ == "__main__":
    start()


