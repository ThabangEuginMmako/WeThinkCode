import unittest
import code_clinic
from booking.booking_student import *
from booking.booking_student import *
from unittest.mock import patch
from io import StringIO 
from test_base import captured_io
import sys
sys.stdout = StringIO()

class TestBookings(unittest.TestCase):
    
    @patch("sys.stdin", StringIO("12345678codeclinic\n"))
    def test_get_ID(self):
        self.assertEqual(get_Id(),"12345678codeclinic")
        
    @patch("sys.stdin", StringIO("abcde123@student.wethinkcode.co.za\n"))
    def test_get_email_True(self):
        self.assertEqual(get_email(),"abcde123@student.wethinkcode.co.za")
        
        
    @patch("sys.stdin", StringIO("abcde123@studentsssss.wethinkcode.co.za\nabcde123@student.wethinkcode.co.za"))
    def test_get_email_False_then_True(self):
        self.assertEqual(get_email(),"abcde123@student.wethinkcode.co.za")
        
        
    def  test_volunteer_booking_True(self):
        with captured_io(StringIO('3\nVolunteer\n2022/03/05\n12:30\noff')) as (out, err):
            
            code_clinic.start()
            output = out.getvalue().strip()
            self.assertTrue(output.find('event created') > -1)
            
            
  
            
            
if __name__ == '__main__':
    unittest.main()