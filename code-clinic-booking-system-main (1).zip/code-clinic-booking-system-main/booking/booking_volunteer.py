
from asyncio import events
import json
from googleapiclient.discovery import build
from datetime import datetime,timedelta,date
from googleapiclient.errors import HttpError
from pandas import describe_option
import re



def get_user_name():
      name=input("Volunteer name: ")
      return name
    
    
def get_user_date():
    from datetime import date
    from dateutil.parser import parse 
    reg = "^\d{4}/(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])$"
    dates=input("Please enter date (yyyy/mm/dd): ")
    if re.search(reg,dates):
     
        dates=dates.split('/')
        datess=date(int(dates[0]),int(dates[1]),int(dates[2]))
        dates = datess.isoformat() 
        todayy= date.today()
        today = date.today().isoformat()
        end = (todayy + timedelta(days=7))
        while dates!="":
            if (today==dates or today<dates) and  datess<end:
                dates=dates.split('-')
                return int(dates[0]),int(dates[1]),int(dates[2])
            else:
                print("Please choose another date in the next seven days.")
                dates=input("Please enter date (yyyy/mm/dd): ")
    else:
        print("Please enter the correct format date: yyyy/mm/dd")
        return get_user_date()
    
    
def get_user_time():
    reg = "^(2[0-3]|[01]?[0-9]):([0-5]?[0-9])$"
    time=input("Please enter time (hh:mm): ")
    if re.search(reg,time):
        time=time.split(':')
        return int(time[0]),int(time[1])
    else: 
        print("Please enter the correct time-format: HH:MM")
        return get_user_time()

def get_Id():
    print("event Id ")
    ID=input("enter ID ")
    while ID =='':
        ID=input("Enter ID: ")
    return ID

    
def check_event_exist(getconf,startt):
    """Shows basic usage of the Google Calendar API.

    Creates a Google Calendar API service object and outputs a list of the next
    10 events on the user's calendar.
    """
    service = build('calendar', 'v3',  credentials=getconf)
    try:
        # Call the Calendar API
        
        now = datetime.utcnow()
        end = now + timedelta(days=7)
        events_result = service.events().list(calendarId='codeclinicsystem@gmail.com', timeMin=now.isoformat() + 'Z', 
                                            timeMax=end.isoformat() + 'Z'
                                            ,maxResults=7, singleEvents=True,
                                            orderBy='startTime').execute()
        events = events_result.get('items', [])

        for event in events:
            start = event['start'].get('dateTime', event['start'].get('date'))
            creater=event['organizer']['email']
            
            if start == startt:
                return True
            else:
                
                return False
    except HttpError as error:
        print('An error occurred: %s' % error)
    
def v_booking(getconf):
    """Shows basic usage of the Google Calendar API.

    Creates a Google Calendar API service object and outputs a list of the next
    10 events on the user's calendar.
    """
    name=get_user_name()
    year,month,day=get_user_date()
    hour,minute=get_user_time()
    start=datetime(year,month,day,hour,minute)
    end=(start+(timedelta(minutes=30))).isoformat() + '+02:00'
    start = start.isoformat() + '+02:00'
    service = build('calendar', 'v3',  credentials=getconf)
    body={
            'summary': f'Code clinic with {name}',
            'location': 'wethinkconde_',
            'description': '',
            'start': {
                'dateTime': start,
                'timeZone': 'Africa/Johannesburg',
            },
            'end': {
                'dateTime': end,
                'timeZone': 'Africa/Johannesburg',
            },
            'recurrence': [
                'RRULE:FREQ=DAILY;COUNT=1'
            ],
            'attendees': [{'email': 'codeclinicsystem@gmail.com'}],
            'reminders': {
                'useDefault': False,
                'overrides': [
                {'method': 'email', 'minutes': 24 * 60},
                {'method': 'popup', 'minutes': 10},
                ],
            },
        }

 
    if not check_event_exist(getconf,start):
        event_result=service.events().insert(
                calendarId='primary',
                body=body).execute()
    
        if event_result:
            print("event created.")
    
    else:
        print("Sorry, slot already booked. Please try booking another one")
        
        return v_booking(getconf)
        

    