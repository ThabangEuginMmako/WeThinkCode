from asyncio import events
import json
from googleapiclient.discovery import build
from datetime import datetime,timedelta
from googleapiclient.errors import HttpError
from pandas import describe_option
import re

def get_Id():
    ID=input("enter ID ")
    while ID =='':
        ID=input("Enter ID: ")
    return ID


def check_Id_cancelation_volunteer(getconf,email,input_id):
    """Shows basic usage of the Google Calendar API.

    Creates a Google Calendar API service object and outputs a list of the next
    10 events on the user's calendar.
    """
    service = build('calendar', 'v3',  credentials=getconf)
    try:
        now = datetime.utcnow()
        end = now + timedelta(days=7)
        events_result = service.events().list(calendarId='codeclinicsystem@gmail.com', timeMin=now.isoformat() + 'Z', 
                                            timeMax=end.isoformat() + 'Z'
                                            ,maxResults=7, singleEvents=True,
                                            orderBy='startTime').execute()
        events = events_result.get('items', [])

        for event in events:
            '''start = event['start'].get('dateTime', event['start'].get('date'))
            creater=event['organizer']['email']'''
            id=event["id"]
            if event["id"]!=input_id:
                pass
            elif event["id"]==input_id:
                if len(event["attendees"])<2:
                    service.events().delete(calendarId='codeclinicsystem@gmail.com', eventId=input_id).execute()
                return True
            else:
                print(len(event["attendees"]))
                return False
    except HttpError as error:
        print('An error occurred: %s' % error)
 
 
def get_email():
    regex="[\w-]{2,20}@\w{2,20}\.\w{2,20}\.\w{2,3}\.\w{2,3}$"
    email=input("Please insert email:\n")
    while len(email)==0:
        return get_email()
    split_email=email.split('@')
    if re.search(regex,email) and split_email[1] in ['student.wethinkcode.co.za']:
        return email
    else:
        print("Please insert correct email: abcd12@student.wethinkcode.co.za")
        return get_email()       
    
        
def cancelation_volunteer(conf):
    email=get_email
    id=get_Id()
    if check_Id_cancelation_volunteer(conf,email,id):
        print("Event has been deleted.")
        return 
        
    else:
        print("Error deleting event, please try again: ")
        return cancelation_volunteer(conf)