const loginUser = async(email) =>{

        const options = {
             method: "POST",
             body: JSON.stringify({"email": email})
         };

        
        try {
          const respond = await fetch("http://localhost:5050/people", options)
          const data = await respond.json()
          // Save to cookie
          createCookie("userId", data.id)
          createCookie("userEmail", data.email)
          return data
        } catch (error) {
          console.log(error) 
        }
}

function createCookie(key, value) {
  const cookie = escape(key) + "=" + escape(value) + ";";
  document.cookie = cookie;
  console.log(cookie);
  console.log("Creating new cookie with key: " + key + " value: " + value);
}
// "key=value; anotherKey=value; "
function readCookie(name) {
  let key = name + "=";
  let cookies = document.cookie.split(";");
  for (let i = 0; i < cookies.length; i++) {
      let cookie = cookies[i];
      while (cookie.charAt(0) === " ") {
          cookie = cookie.substring(1, cookie.length);
      }
      if (cookie.indexOf(key) === 0) {
          return cookie.substring(key.length, cookie.length);
      }
  }
  return null;
}

function expense(){
    const form = document.getElementById("expenses");

        const options = {
            method: 'GET',
        };


        fetch('http://localhost:5050/expenses', options)
            .then(response => response.json())
            .then(data => {
                data = {

                };
                console.log(data);
                const template = document.getElementById('expense-template').innerText;
                const compiledFunction = Handlebars.compile(template);
            });
    };

const newExpense= async(personId,description,date,amount) =>{

    const form = document.getElementById("newexpense")

    const options = {
        method: "POST",
        body: JSON.stringify({"personId": personId,"description": description, "date": date, "amount": amount})
    };

    try {
      const respond = await fetch("http://localhost:5050/expenses", options)
      const data = await respond.json()
      console.log(data)
    } catch (error) {
      console.log(data)
    }   
}
function badPayers(date){
  const options = {
    method: 'GET',
  };

  fetch("http://localhost:5050/expenses", options)
  .then(response => response.json)
  console.log(data)
  .then(data =>{

  })

}


window.addEventListener('load', () => {
  const app = $('#app');

  const navTemplate = Handlebars.compile($('#nav-template').html());
  const loginTemplate = Handlebars.compile($("#login-template").html()) // load the script template section
  const expenseTemplate = Handlebars.compile($("#expense-template").html())
  const newExpenseTemplate = Handlebars.compile($("#newexpense-template").html())
  const badPayersTemplate = Handlebars.compile($("#badpayers-template").html())

 // Proper REST NAMING /api/v1/expense
  const router = new Router({
    mode:'hash',
    root:'index.html',
    page404: (path) => {

      const html = navTemplate()
      app.html(html);
    }
  });

  router.add('/expenses', async () => {
      console.log("EXPENSES TODO")
      const nav = navTemplate();
      app.html(nav);
      const html = expenseTemplate();
      app.html(html);
    
      document.getElementById("userEmail").innerText = readCookie("userEmail")
      $("form").on("submit", async(event)=>{
        event.preventDefault();
        const email = new FormData(event.target).get("email")
        this.user = await loginUser(email)
        const path = "#/expenses"
        router.navigateTo(path)
      })
  });

  
  router.add('/newexpense', async () => {
    console.log('new expense')
    const html = newExpenseTemplate()
    app.html(html)
    document.getElementById("userEmail").innerText = readCookie("userEmail")
    $("form").on("submit", async(event) =>{
      event.preventDefault();
      const description = new FormData(event.target).get("description");
      const date = new FormData(event.target).get("date");
      const amount = new FormData(event.target).get("amount");
      this.user = await newExpense(readCookie("userId"),description,date,amount)
      const path = "#/expenses"
      router.navigateTo(path)
      
    })

  });

  router.add('/badpayers', async() =>{
       console.log('bad payers')
       const html = badPayersTemplate()
       app.html(html)
       document.getElementById("userEmail").innerText = readCookie("userEmail")
  });



  router.addUriListener();

  router.add("/login", async ()=>{
      const html = loginTemplate()
      app.html(html)
  
      $("form").on("submit", async(event) =>{
        event.preventDefault();
        const email = $("#email").val()
        loginUser(email)
        router.navigateTo("/expenses")
      })
  });

  $('a').on('click', (event) => {
    event.preventDefault();
    const target = $(event.target);
    const href = target.attr('href');
    const path = href.substring(href.lastIndexOf('/'));
    router.navigateTo(path);
  });

  router.navigateTo('/login');

});