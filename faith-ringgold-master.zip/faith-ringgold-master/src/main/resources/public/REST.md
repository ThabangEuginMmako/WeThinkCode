## Versioning
1. Headers
   - ["version": "v2"]
2. URL
   - api/<version>/endpoint
     - ```api/v1/expenses```
## Naming
Endpoints start with api
    - "api/...."