package za.co.wethinkcode.toyrobot;

public enum Direction {
    UP,
    RIGHT,
    LEFT,
    DOWN
}
