package za.co.wethinkcode.toyrobot.maze;

public class EmptyMaze extends AbstractMaze {
}
