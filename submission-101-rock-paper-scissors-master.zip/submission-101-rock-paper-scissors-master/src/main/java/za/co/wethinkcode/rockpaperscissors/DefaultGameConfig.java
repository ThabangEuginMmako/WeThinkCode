package za.co.wethinkcode.rockpaperscissors;

public class DefaultGameConfig extends GameConfig {
    public DefaultGameConfig(Integer integer) {
        super(integer);
    }

    // TODO implement this
    @Override
    public void howManyPlayers() {
        super.howManyPlayers();

    }
}

