package za.co.wethinkcode.rockpaperscissors.hands;

// TODO implement this class

public class Rock extends Paper {
    public Rock rock = new Rock();

}