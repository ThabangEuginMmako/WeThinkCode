package za.co.wethinkcode.rockpaperscissors;

import za.co.wethinkcode.rockpaperscissors.results.GameResult;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
// TODO Implement this
import java.util.Scanner;
import java.util.Random;
import java.util.Scanner;

public class Game {
    Scanner scanner = new Scanner(System.in);
    private String playerName;
    private String playerHandChoice;
    private boolean gameWinner;

    public Game(){

    }

    public Game(String playerName) {
        this.playerName = playerName;
    }

    public String getPlayerName() {
        return playerName;
    }


    public void playerHand(){
        this.playerHandChoice = scanner.nextLine();
        if (playerHandChoice.equalsIgnoreCase("R")){
            System.out.println("Player has chosen Rock!");
        }else if(playerHandChoice.equalsIgnoreCase("P")){
            System.out.println("Player has chosen Paper!");
        }else if(playerHandChoice.equalsIgnoreCase("S")){
            System.out.println("Player has chosen Scissors!");
        } else {
            System.out.println("You must have entered a wrong input!");
        }
    }