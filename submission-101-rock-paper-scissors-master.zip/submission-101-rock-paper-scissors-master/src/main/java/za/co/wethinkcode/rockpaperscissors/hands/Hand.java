package za.co.wethinkcode.rockpaperscissors.hands;




public abstract class Hand implements Comparable<Hand> {


    // TODO implement this
    enum PlayedMove {
        PAPER(0),
        ROCK(1),
        SCISSORS(2);

        private final int value;

        PlayedMove(int value) {
            this.value = value;
        }

        public boolean isPaper() {
            return this.value == PAPER.value;
        }


    }


}




