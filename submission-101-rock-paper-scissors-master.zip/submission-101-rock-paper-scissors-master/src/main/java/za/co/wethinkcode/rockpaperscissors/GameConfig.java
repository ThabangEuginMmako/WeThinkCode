package za.co.wethinkcode.rockpaperscissors;

public class GameConfig {
    public GameConfig(Integer integer) {

    }

    // TODO implement this
    public void howManyPlayers() {
    }

    public int getMinimumPlayers() {
        return 0;
    }
}
