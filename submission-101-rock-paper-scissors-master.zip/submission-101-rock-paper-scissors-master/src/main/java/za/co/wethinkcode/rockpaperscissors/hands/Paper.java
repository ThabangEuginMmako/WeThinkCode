package za.co.wethinkcode.rockpaperscissors.hands;

// TODO implement this class

 public class  Paper {

  public Paper paper = new Paper();

 }



