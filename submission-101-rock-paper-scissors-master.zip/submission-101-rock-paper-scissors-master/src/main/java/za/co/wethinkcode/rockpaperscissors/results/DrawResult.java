package za.co.wethinkcode.rockpaperscissors.results;

import za.co.wethinkcode.rockpaperscissors.Game;

// TODO implement this class

public class DrawResult {


}




