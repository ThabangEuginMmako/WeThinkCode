package za.co.wethinkcode.rockpaperscissors;

import za.co.wethinkcode.rockpaperscissors.hands.Hand;
import za.co.wethinkcode.rockpaperscissors.hands.Paper;
import za.co.wethinkcode.rockpaperscissors.hands.Rock;

import java.util.List;

public class Player {
    private Game currentGame;
    private Hand hand;
    private int wins = 0;

public Player(){

}

    public void join(Game game) {
        // TODO implement this
        this.currentGame = game;
    }

    public void choose(Paper hand) {
        // TODO implement this
        this.hand = hand;
    }

    public List<Player> opponents() {
        // TODO implement this
        List<Player> players = opponents();
        return players;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public Game getCurrentGame() {
        return currentGame;
    }

    public Hand getHand() {
        return hand;
    }

    public int getWins() {
        return this.wins;
    }

    public void addWin() {
        wins = wins + 1;
    }


    public <PlayedMove> PlayedMove chooseMove() {
        return null;
    }
}