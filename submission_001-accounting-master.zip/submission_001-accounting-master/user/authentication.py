print('[Module] User Authentication loaded.')
def authenticate_user():
    return True, print(f'Authenticating User')


if __name__ == '__main__':
    authenticate_user()