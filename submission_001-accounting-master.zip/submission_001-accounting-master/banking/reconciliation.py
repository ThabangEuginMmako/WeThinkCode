print('[Module] Reconciliation loaded.')

def do_reconciliation():
    return True, print('Doing bank reconciliation.')

