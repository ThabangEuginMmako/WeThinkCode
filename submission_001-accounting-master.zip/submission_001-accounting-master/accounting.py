from user.authentication import authenticate_user
from transactions.journal import *
# from banking.reconciliation import do_reconciliation
# from banking.fvb.reconciliation import  do_reconciliation
# from banking.ubsa.reconciliation import do_reconciliation
# from banking.online.reconciliation import do_reconciliation
import banking
import sys

def system_arguments():
    for i in range(1,len(sys.argv)):
        print(sys.argv[i])

if __name__ == '__main__':
    system_arguments()
    authenticate_user()
    receive_income(100)
    pay_expense(100)
    banking.reconciliation.do_reconciliation()
    #help("modules")




