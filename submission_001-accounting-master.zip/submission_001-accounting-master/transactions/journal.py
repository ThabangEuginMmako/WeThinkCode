print('[Module] Journal loaded.')

def receive_income(amount):
    """prints out the amount received"""
    print('[Journal] Received R{0:.2f}'.format(amount))


def pay_expense(amount):
    """Prints out the amount paid by customer"""
    print('[Journal] Paid R{0:.2f}'.format(amount))