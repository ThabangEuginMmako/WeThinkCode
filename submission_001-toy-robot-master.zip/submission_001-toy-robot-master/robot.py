# TODO: Decompose into functions

def move_square(size, degrees):
    '''This function is to move the toy robot in a square shape'''
    print("Moving in a square of size "+str(size))
    for i in range(4):
        print("* Move Forward "+str(size))
        print("* Turn Right "+str(degrees)+" degrees")


def move_cicle():
    '''This function is to move the toy robot in a circle shape'''
    print("Moving in a circle")
    degrees = 1
    for i in range(360):
        length = 1
        print("* Move Forward "+str(length))
        print("* Turn Right "+str(degrees)+" degrees")


def move_rectangle(length, width, degrees):
    '''This function is to move the toy robot in a rectangle shape'''
    print("Moving in a rectangle of "+str(length)+" by "+str(width))
    for i in range(2):
        print("* Move Forward "+str(length))
        print("* Turn Right "+str(degrees)+" degrees")
        print("* Move Forward "+str(width))
        print("* Turn Right "+str(degrees)+" degrees")


def dancing_square(size, length, degrees):
    '''This function is to move the toy robot in a dancing square pattern'''
    size = 20
    print("Square dancing - 3 squares of size 20")
    for i in range(3):
        length = 20
        print("* Move Forward "+str(length))
        print("Moving in a square of size "+str(size))
        for j in range(4):
            print("* Move Forward " + str(size))
            print("* Turn Right " + str(degrees) + " degrees")


def crop_circle(size, length, degrees):
    '''This function purpose is to move the toy robot in a crop circle pattern'''
    length = 20
    print("Crop circles - 4 circles")
    for i in range(4):
        print("* Move Forward "+str(length))
        move_cicle()


def move():
    '''I would had preferred to use move_shapes as my function name cause the functions purpose is to 
       move the toy robot in various shapes by calling all the move shapes functions'''
    size = 10
    length = 20
    width = 10
    degrees = 90

    move_square(size, degrees)
    move_rectangle(length, width, degrees)
    move_cicle()
    dancing_square(size, length, degrees)
    crop_circle(size, length, degrees)


def robot_start():
    '''The purpose of this function is to start the robot to move in various shapes by calling the
       move function'''
    move()


if __name__ == "__main__":
    robot_start()