from random import random
import unittest
import mastermind
import random
import sys,os

from io import StringIO
from unittest.mock import patch

sys.stdout = open(os.devnull,"w")
class TestFunctions(unittest.TestCase):
    
        def test_create_code(self):
            for i in range(100):
                self.assertEqual(len(mastermind.create_code()), 4, "The lenth of the generated code shoulb be 4!")
                for j in range(4):
                    self.assertTrue(1 <= mastermind.create_code()[j] <=8, "needs to generate num between 1 and 8!")


        def test_check_correctness(self):
            correct_digits_and_position = random.randint(0,4)
            turns = random.randint(0,12)
            if correct_digits_and_position == 4:
                self.assertTrue(mastermind.check_correctness(turns, correct_digits_and_position))
            else:
                self.assertFalse(mastermind.check_correctness(turns, correct_digits_and_position))

        @patch("sys.stdin", StringIO("1\n12\n123\n1234\n12345\nabc\n"))
        def test_get_answer_input(self):
            self.assertEqual(mastermind.get_answer_input(), "1234")

        @patch("sys.stdin", StringIO("1423\n1285\n5432\n5243\n2375\n4175\n"))
        def test_take_turns(self):
            code = [4,1,7,5]
            self.assertEqual(mastermind.take_turn(code), (0,2))
            self.assertEqual(mastermind.take_turn(code), (1,1))
            self.assertEqual(mastermind.take_turn(code), (0,2))
            self.assertEqual(mastermind.take_turn(code), (0,2))
            self.assertEqual(mastermind.take_turn(code), (2,0))
            self.assertEqual(mastermind.take_turn(code), (4,0))







