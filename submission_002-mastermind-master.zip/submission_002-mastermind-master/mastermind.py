import random

"""
TODO: implement Mastermind code here
"""

def run_game():
    code = [0,0,0,0] # initializing a list with for elements to zero
    for i in range(4): # creating a loop that iterates in a range of 4
        value = random.randint(1, 8) # 8 possible digits randomly generated
        while value in code: # creating a while loop to gerenate random integer numbers into a list called code
            value = random.randint(1, 8)  # 8 possible digits randomly generated
        code[i] = value # assigning the contents of value into a list called code according to iterated index
       
      
    print('4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.') #printing out the message to the user

    correct = False # initializing correct variable to boolean False
    turns = 0 # initializing turns variable to zero
    while not correct and turns < 12: # creating a while loop to keep track of correct and turns variables conditions 
        answer = input("Input 4 digit code: ") # getting input from the user with the prompt message
                        
        if len(answer) != 4 or answer.isnumeric() == False: # conditional statement to check the length of characters entered by 
                                                            # the user and validating whether is a numeric value 
            print("Please enter exactly 4 digits.") # promting message for a user to enter the correct input
            continue # continue statement
        correct_digits_and_position = 0 # initializing correct_digits_and_position variable to zero
        correct_digits_only = 0 # initializing correct_digits_only vaiable to zero
        for i in range(len(answer)): # loop to iterate over the lenght of user input
            if code[i] == int(answer[i]): # conditional statement to check whether the contents of the list code and user input are 
                                          # equal and on the same index position
                correct_digits_and_position += 1 # incremental by one for corect_digits_and_postion variable 
            elif int(answer[i]) in code: # conditional statement to check whether one of the inserted code is in the code
                correct_digits_only += 1 # incremental by one for correct_digitd_only variable

        print('Number of correct digits in correct place:     '+str(correct_digits_and_position)) # printing the number of correct
                                                                                                  # digits in correct place
        print('Number of correct digits not in correct place: '+str(correct_digits_only)) # printing the number of correct digts not
                                                                                          # n correct place

        turns += 1 # incrementing turns by one

        if correct_digits_and_position == 4: # conditional statement to check whether the user has entered the correct code
            correct = True # initializing the correct variable to boolean True
            print('Congratulations! You are a codebreaker!') # message to prompt the user that they've entered the correct code
        else:
            print('Turns left: '+str(12 - turns)) # message to prompt the user about the number of turns they have left

    print("{}{}{}{}{}".format('The code was: ',code[0],code[1],code[2],code[3])) # message to reveal the code to the user after 
                                                                                  #they have ran out of turns 

     
if __name__ == "__main__":
    run_game()



