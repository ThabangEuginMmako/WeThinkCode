#! /bin/bash
mvn compiler:compile -f `pwd`
mvn exec:java -Dexec.mainClass="de.wethinkco.robotworlds.Server"