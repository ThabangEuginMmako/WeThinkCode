#! /bin/bash
mvn compiler:compile -f `pwd`
mvn exec:java -Dexec.mainClass="libs/reference-server-0.1.0 (1).jar"