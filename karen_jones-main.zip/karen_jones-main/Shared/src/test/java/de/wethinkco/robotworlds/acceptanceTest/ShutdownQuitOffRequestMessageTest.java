package de.wethinkco.robotworlds.acceptanceTest;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import de.wethinkco.robotworlds.protocol.RequestsHandler.BackRequestMessage;
import de.wethinkco.robotworlds.protocol.RequestsHandler.LaunchRequestMessage;
import de.wethinkco.robotworlds.protocol.RequestsHandler.ShutdownQuitOffRequestMessage;
import org.codehaus.jackson.annotate.JsonSubTypes;
import org.codehaus.jackson.annotate.JsonTypeInfo;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class ShutdownQuitOffRequestMessageTest {
    private final static int DEFAULT_PORT = 5000;
    private final static String DEFAULT_IP = "localhost";
    private final RobotWorldClient serverClient = new RobotWorldJsonClient();

    @JsonTypeInfo(
            use = JsonTypeInfo.Id.NAME,
            include = JsonTypeInfo.As.PROPERTY,
            property = "type"
    )
    @JsonSubTypes({
            @JsonSubTypes.Type(value = LaunchRequestMessage.class, name = "launch"),
            @JsonSubTypes.Type(value = BackRequestMessage.class, name = "back")
    })
    @JsonDeserialize(as = BackRequestMessage.class)
    @BeforeEach
    void connectToServer() {
//        try {
//            Process proc = Runtime.getRuntime().exec("java -jar .libs/reference-server-0.1.0.jar");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        serverClient.connect(DEFAULT_IP, DEFAULT_PORT);

    }

    @AfterEach
    void disconnectFromServer() {
        serverClient.disconnect();
    }
    @Test
    void ValidateIfRequestIsEmpty() {
        ShutdownQuitOffRequestMessage actualShutdownQuitOffRequestMessage = new ShutdownQuitOffRequestMessage();
        assertTrue(actualShutdownQuitOffRequestMessage.getArguments().isEmpty());
        assertNull(actualShutdownQuitOffRequestMessage.getRobot());
        assertNull(actualShutdownQuitOffRequestMessage.getCommand());
    }
    //This will happen when there are no active players in the world.
    //If the server connection is disrupted.
    //Shutdown - Quit,OffRequestMessage (String)}

    @Test
    void ValidateIfRequestHasString() {
        ShutdownQuitOffRequestMessage actualShutdownQuitOffRequestMessage = new ShutdownQuitOffRequestMessage("Robot");
        assertTrue(actualShutdownQuitOffRequestMessage.getArguments().isEmpty());
        assertEquals("Robot", actualShutdownQuitOffRequestMessage.getRobot());
        assertEquals("quit", actualShutdownQuitOffRequestMessage.getCommand());
    }
}

