package de.wethinkco.robotworlds.unittets;

import com.fasterxml.jackson.databind.JsonNode;
import de.wethinkco.robotworlds.protocol.RequestsHandler.ForwardRequestMessage;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.ResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.Robot;
import de.wethinkco.robotworlds.protocol.world.World;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

public class ForwardCommandTest {

    @Test
    void testForwardRequest() {
        String request = "{" +
                "  \"robot\": \"HAL\"," +
                "  \"command\": \"forward\"," +
                "  \"arguments\": [\"5\"]" +
                "}";

        ArrayList<Object> objectList = new ArrayList<>();
        ForwardRequestMessage actualForwardRequestMessage = new ForwardRequestMessage("Robot", objectList);
        List<Object> arguments = actualForwardRequestMessage.getArguments();
        assertSame(objectList, arguments);
//       assertTrue(arguments.isEmpty())
        Robot target = new Robot();
        ResponseMessage actualExecuteResult = actualForwardRequestMessage.execute(target, new World());
        assertEquals("Robot", actualForwardRequestMessage.getRobot());
        assertEquals("forward", actualForwardRequestMessage.getCommand());
        assertEquals(new ArrayList<>(), actualForwardRequestMessage.getArguments());
        assertEquals("OK", actualExecuteResult.getResult());
        assertSame(arguments, objectList);

    }
}
