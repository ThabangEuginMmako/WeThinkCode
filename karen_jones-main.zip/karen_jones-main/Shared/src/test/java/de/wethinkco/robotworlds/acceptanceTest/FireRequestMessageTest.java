package de.wethinkco.robotworlds.acceptanceTest;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import de.wethinkco.robotworlds.protocol.Position;
import de.wethinkco.robotworlds.protocol.RequestsHandler.BackRequestMessage;
import de.wethinkco.robotworlds.protocol.RequestsHandler.FireRequestMessage;
import de.wethinkco.robotworlds.protocol.RequestsHandler.LaunchRequestMessage;
import de.wethinkco.robotworlds.protocol.robots.AssaultRobot;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.ResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.SuccessResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.Robot;
import de.wethinkco.robotworlds.protocol.world.IWorldObject;
import de.wethinkco.robotworlds.protocol.world.World;
import org.codehaus.jackson.annotate.JsonSubTypes;
import org.codehaus.jackson.annotate.JsonTypeInfo;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FireRequestMessageTest {
    private final static int DEFAULT_PORT = 5000;
    private final static String DEFAULT_IP = "localhost";
    private final RobotWorldClient serverClient = new RobotWorldJsonClient();
    @JsonTypeInfo(
            use = JsonTypeInfo.Id.NAME,
            include = JsonTypeInfo.As.PROPERTY,
            property = "type"
    )
    @JsonSubTypes({
            @JsonSubTypes.Type(value = LaunchRequestMessage.class, name = "launch"),
            @JsonSubTypes.Type(value = FireRequestMessage.class, name = "fire")
    })
    @JsonDeserialize(as = BackRequestMessage.class)

    @BeforeEach
    void connectToServer() {
//                try {
//            Process proc = Runtime.getRuntime().exec("java -jar .libs/reference-server-0.1.0.jar");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        serverClient.connect(DEFAULT_IP, DEFAULT_PORT);
    }

    @AfterEach
    void disconnectFromServer() {
        serverClient.disconnect();
    }


    @Test
    void testFireCommand() {
        FireRequestMessage actualFireRequestMessage = new FireRequestMessage("Robot");
        assertTrue(actualFireRequestMessage.getArguments().isEmpty());
        assertEquals("Robot", actualFireRequestMessage.getRobot());
        assertEquals("fire", actualFireRequestMessage.getCommand());
    }

    @Test
    void testFireRequest() {
        ArrayList<Object> objectList = new ArrayList<>();
        FireRequestMessage actualFireRequestMessage = new FireRequestMessage("Robot", objectList);

        List<Object> arguments = actualFireRequestMessage.getArguments();
        assertSame(objectList, arguments);
        assertTrue(arguments.isEmpty());
        assertEquals("Robot", actualFireRequestMessage.getRobot());
        assertEquals("fire", actualFireRequestMessage.getCommand());
        assertSame(arguments, objectList);
    }

    @Test
    void testUnexpectedCommand() {
        FireRequestMessage fireRequestMessage = new FireRequestMessage("Robot");
        Robot target = new Robot();
        ResponseMessage actualExecuteResult = fireRequestMessage.execute(target, new World());
        assertEquals(1, actualExecuteResult.getData().size());
        assertEquals("Error", actualExecuteResult.getResult());
    }

    @Test
    void testExepectedCommand() {
        FireRequestMessage fireRequestMessage = new FireRequestMessage("Robot");
        AssaultRobot assaultRobot = new AssaultRobot("message");
        ResponseMessage actualExecuteResult = fireRequestMessage.execute(assaultRobot, new World());
        assertEquals(1, actualExecuteResult.getData().size());
        HashMap<String, Object> state = ((SuccessResponseMessage) actualExecuteResult).getState();
//        assertSame(assaultRobot, state);
//        assertEquals("OK", actualExecuteResult.getResult());
//        assertEquals(2, state.getShots().intValue());
    }

    @Test
    void testRequestMessage() {
        FireRequestMessage fireRequestMessage = new FireRequestMessage("Robot");

        Robot robot = new Robot();
        robot.setShots(1);
        ResponseMessage actualExecuteResult = fireRequestMessage.execute(robot, new World());
        assertEquals(1, actualExecuteResult.getData().size());
        HashMap<String, Object> state = ((SuccessResponseMessage) actualExecuteResult).getState();
//        assertSame(robot, state);
//        assertEquals("OK", actualExecuteResult.getResult());
//        assertEquals(0, state.getShots().intValue());
    }

    @Test
    void testExecuteCommand() {

        FireRequestMessage fireRequestMessage = new FireRequestMessage("Robot");
        AssaultRobot target = new AssaultRobot("message");
        World world = new World();
        world.addRobot(new Robot());

    }

    @Test
    void testArrayList() {
        FireRequestMessage fireRequestMessage = new FireRequestMessage("Robot");

        ArrayList<Integer> integerList = new ArrayList<>();
        integerList.add(-1);
        integerList.add(2);
        AssaultRobot assaultRobot = new AssaultRobot("message");
        assaultRobot.setPosition(integerList);
        ResponseMessage actualExecuteResult = fireRequestMessage.execute(assaultRobot, new World());
        assertEquals(1, actualExecuteResult.getData().size());
        HashMap<String, Object> state = ((SuccessResponseMessage) actualExecuteResult).getState();
//        assertSame(assaultRobot, state);
//        assertEquals("OK", actualExecuteResult.getResult());
//        assertEquals(2, state.getShots().intValue());
    }

    @Test
    void testPositions() {
        FireRequestMessage fireRequestMessage = new FireRequestMessage("Robot");

        AssaultRobot assaultRobot = new AssaultRobot("message");
        assaultRobot.setPosition(2, -919806160);
        ResponseMessage actualExecuteResult = fireRequestMessage.execute(assaultRobot, new World());
        assertEquals(1, actualExecuteResult.getData().size());
        HashMap<String, Object> state = ((SuccessResponseMessage) actualExecuteResult).getState();
//        assertSame(assaultRobot, state);
//        assertEquals("OK", actualExecuteResult.getResult());
//        assertEquals(2, state.getShots().intValue());
    }

    @Test
    void testHitObstaclesInPath() {
        FireRequestMessage fireRequestMessage = new FireRequestMessage("Robot");
        Robot target = new Robot();
        Position robotPosition = new Position(2, 3);

        ArrayList<IWorldObject> iWorldObjectList = new ArrayList<>();
        iWorldObjectList.add(new AssaultRobot());

    }

    @Test
    void testGetClosestObject() {
        FireRequestMessage fireRequestMessage = new FireRequestMessage("Error");
        AssaultRobot assaultRobot = new AssaultRobot("Robot Name");
        assaultRobot.setRobotPosition(new Position(2, 3));
        ArrayList<IWorldObject> iWorldObjectList = new ArrayList<>();
        iWorldObjectList.add(new AssaultRobot());
        assertNull(fireRequestMessage.getClosestObject(assaultRobot, iWorldObjectList));
    }

    @Test
    void testGetDistanceToObject() {
        FireRequestMessage fireRequestMessage = new FireRequestMessage("Robot");
        Robot target = new Robot("NORTH");
    }

    @Test
    void testGetMaxRangePosition() {
        FireRequestMessage fireRequestMessage = new FireRequestMessage("Robot");
        Position actualMaxRangePosition = fireRequestMessage.getMaxRangePosition("Direction", new Position(2, 3), 1);
        assertEquals(0, actualMaxRangePosition.getX());
        assertEquals(0, actualMaxRangePosition.getY());
    }

}

