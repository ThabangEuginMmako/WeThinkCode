package de.wethinkco.robotworlds.acceptanceTest;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import de.wethinkco.robotworlds.protocol.Position;
import de.wethinkco.robotworlds.protocol.RequestsHandler.BackRequestMessage;
import de.wethinkco.robotworlds.protocol.RequestsHandler.LaunchRequestMessage;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.ResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.SuccessResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.Robot;
import de.wethinkco.robotworlds.protocol.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.codehaus.jackson.annotate.JsonSubTypes;
import org.codehaus.jackson.annotate.JsonTypeInfo;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * ITERATION 1
 * As a player
 * I want to move back by certain steps.

 *ITERATION 2
 As a player
 I want to command my robot to move back a specified number of steps
 so that I can explore the world and not be a sitting duck in a battle.
 */

class BackRequestMessageTest {

    private final static int DEFAULT_PORT = 5000;
    private final static String DEFAULT_IP = "localhost";
    private final RobotWorldClient serverClient = new RobotWorldJsonClient();

    @BeforeEach
    void connectToServer() {
//        try {
//            Process proc = Runtime.getRuntime().exec("java -jar .libs/reference-server-0.1.0.jar");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        serverClient.connect(DEFAULT_IP, DEFAULT_PORT);

    }

    @AfterEach
    void disconnectFromServer() {
        serverClient.disconnect();
    }

    /**
     * ITERATION 1
     Successfully moved backwards.
     If there is no obstacle or another robot in the robot's view, then the robot will be able to move backwards.

     *ITERATION 2
     Successfully moved backwards.
     Given that I am connected to a running Robot Worlds server
     And the world is of size 200x400 with no obstacles or pits
     And a robot called "HAL" is already connected and launched
     When I send a command for "HAL" to move backward by 10 steps
     Then I should get an "OK" response with the message "Moved backward by 10 steps"
     and the position information returned should be at co-ordinates [0,-10] if the robot
     was initially at position [0,0].
     */

//    @Test
//    void testBackRequest() {
//        Assertions.assertTrue(serverClient.isConnected());
//        String request = "{" +
//                "\"robot\": \"HAL\"," +
//                "\"command\": \"launch\"," +
//                "\"arguments\": [\"sniper\",\"5\",\"1\"]"+
//                "}";
//        JsonNode response = serverClient.sendRequest(request);
//
//        request = "{" +
//                "\"robot\": \"HAL\"," +
//                "\"command\": \"back\"," +
//                "\"arguments\": [\"1\"]" +
//                "}";
//        response = serverClient.sendRequest(request);
//
//        assertNotNull(response);
//        assertNotNull(response.get("data"));
//        assertNotNull(response.get("state"));
//
////        ArrayList<Object> objectList = new ArrayList<>();
////        BackRequestMessage actualBackRequestMessage = new BackRequestMessage("Robot", objectList);
////        objectList.add("10");
////        List<Object> arguments = actualBackRequestMessage.getArguments();
////        assertSame(objectList, arguments);
////        assertEquals("Robot", actualBackRequestMessage.getRobot());
////        assertEquals("back", actualBackRequestMessage.getCommand());
////        assertSame(arguments, objectList) ;
//    }
//
//    /**
//     *ITERATION 1
//     If the user inputs and invalid step i.e not a digit, the server will respond with an error
//     message saying "Invalid Steps".
//
//     *ITERATION 2
//     Given that I am connected to a running Robot Worlds server
//     And a robot called "HAL" is already connected and launched
//     When I send a command for "HAL" to move back by a non numeric argument e.g "back gh"
//     Then I should get an "ERROR" response with the message "Invalid Steps"
//     and the position information returned should be at co-ordinates [0,0] if the robot
//     was initially at position [0,0].
//     */
//
//    @Test
//    void testInvalidSteps() {
//        Assertions.assertTrue(serverClient.isConnected());
//        String request = "{" +
//                "\"robot\": \"HAL\"," +
//                "\"command\": \"launch\"," +
//                "\"arguments\": [\"sniper\",\"5\",\"1\"],"+
//                "\"command\": \"back\"," +
//                "\"arguments\": [\"HG\"]" +
//                "}";
//        JsonNode response = serverClient.sendRequest(request);
//        BackRequestMessage backRequestMessage = new BackRequestMessage();
//        Robot target = new Robot();
//        ResponseMessage actualExecuteResult = backRequestMessage.execute(target, new World());
//        assertEquals(1, actualExecuteResult.getData().size());
//        assertEquals("Error", actualExecuteResult.getResult());
//    }
//
//    /**
//     *OBSTACLE ON THE WAY
//     * ITERATION 1
//     * Unsuccessful attempt to move backwards.
//     If there is an obstacle or another robot within 10 steps in the robot's view, the robot will be restricted from moving backwards.
//     The position of the robot has not changed.
//
//     *ITERATION 2
//     Given that I am connected to a running Robot Worlds server
//     And the world is of size 200x400 obstacles or pits
//     And a robot called "HAL" is already connected and launched
//     When I send a command for "HAL" to move backward by 10 steps and there is an obstacle
//     within 10 steps at the back of the robot
//     Then I should get an "OK" response with the message "There is an obstacle on the way"
//     and the position information returned should be at co-ordinates [0,0] if the robot
//     was initially at position [0,0].
//     */
//    @Test
//    void testObstacleOnTheWay() {
//    Assertions.assertTrue(serverClient.isConnected());
//    String request = "{" +
//            "\"robot\": \"HAL\"," +
//            "\"command\": \"launch\"," +
//            "\"arguments\": [\"sniper\",\"5\",\"1\"],"+
//            "\"command\": \"back\"," +
//            "\"arguments\": [\"10\"]" +
//            "}";
//    JsonNode response = serverClient.sendRequest(request);
//        ArrayList<Object> objectList = new ArrayList<>();
//        objectList.add("42");
//        BackRequestMessage backRequestMessage = new BackRequestMessage("message", objectList);
//        Robot robot = new Robot();
//        ResponseMessage actualExecuteResult = backRequestMessage.execute(robot, new World());
//        assertEquals(1, actualExecuteResult.getData().size());
//        HashMap<String, Object> state = ((SuccessResponseMessage) actualExecuteResult).getState();
//        assertSame(robot, state);
////        assertNull(state.getObstacles());
////        List<Integer> position = state.getPosition();
////        assertEquals(2, position.size());
////        assertEquals(-42, position.get(1));
////        Position robotPosition = state.getRobotPosition();
////        assertEquals(-42, robotPosition.getY());
//    }
//
//    /**
//     * TOO MANY ARGUMENTS
//     * ITERATION 1
//     unsuccessful attempt due to many arguments provided.
//     If the user provides too many arguments,the server will send back an error message saying
//     'Too many arguments provided.' and therefor restricting the robot to move.
//
//     *ITERATION 2
//     Given that I am connected to a running Robot Worlds server
//     And a robot called "HAL" is already connected and launched
//     When I send a command for "HAL" to move backward by 10 10, i.e too many arguments
//     Then I should get an "ERROR" response with the message "Too mant "
//     and the position information returned should be at co-ordinates [0,0] if the robot
//     was initially at position [0,0].
//     */
//    @Test
//    void testManyArguments() {
//        Assertions.assertTrue(serverClient.isConnected());
//        String request = "{" +
//                "\"robot\": \"HAL\"," +
//                "\"command\": \"launch\"," +
//                "\"arguments\": [\"sniper\",\"5\",\"1\"],"+
//                "\"command\": \"back\"," +
//                "\"arguments\": [\"42\",\"42\"]" +
//                "}";
//        JsonNode response = serverClient.sendRequest(request);
//        ArrayList<Object> objectList = new ArrayList<>();
//        objectList.add("42");
//        objectList.add("42");
//        BackRequestMessage backRequestMessage = new BackRequestMessage("message", objectList);
//        Robot target = new Robot();
//        ResponseMessage actualExecuteResult = backRequestMessage.execute(target, new World());
//        assertEquals(1, actualExecuteResult.getData().size());
//        assertEquals("Error", actualExecuteResult.getResult());
//    }
//
//    /**
//     *ITERATION 1
//     * Zero steps
//     * if the user inputs 0 for the number of steps,the server will respond with an
//     error message saying "zero steps".
//
//     *ITERATION 2
//     Zero steps
//     Given that I am connected to a running Robot Worlds server
//     And a robot called "HAL" is already connected and launched
//     When I send a command for "HAL" to move forward by zero steps i.e "back 0"
//     Then I should get an "ERROR" response with the message "Zero Steps"
//     and the position information returned should be at co-ordinates [0,0] if the robot
//     was initially at position [0,0].
//     */
//    @Test
//    void test0steps() {
//        Assertions.assertTrue(serverClient.isConnected());
//        String request = "{" +
//                "\"robot\": \"HAL\"," +
//                "\"command\": \"launch\"," +
//                "\"arguments\": [\"sniper\",\"5\",\"1\"],"+
//                "\"command\": \"back\"," +
//                "\"arguments\": [\"0\"]" +
//                "}";
//        JsonNode response = serverClient.sendRequest(request);
//        Assertions.assertTrue(serverClient.isConnected());
//        ArrayList<Object> objectList = new ArrayList<>();
//        objectList.add("NORTH");
//        BackRequestMessage backRequestMessage = new BackRequestMessage("message", objectList);
//        Robot target = new Robot();
//        ResponseMessage actualExecuteResult = backRequestMessage.execute(target, new World());
//        assertEquals(1, actualExecuteResult.getData().size());
//        assertEquals("ERROR", actualExecuteResult.getResult());
//    }
//
//    /**
//     * Outside zone
//     If the user attempts to move outside the allowed area, the server will block the robot
//     from moving and send a response that the robot cannot move outside the zone.
//     */
//    @Test
//    void testOutsideZone() {
//        Assertions.assertTrue(serverClient.isConnected());
//        String request = "{" +
//                "\"robot\": \"HAL\"," +
//                "\"command\": \"launch\"," +
//                "\"arguments\": [\"sniper\",\"5\",\"1\"],"+
//                "\"command\": \"back\"," +
//                "\"arguments\": [\"0\"]" +
//                "}";
//        JsonNode response = serverClient.sendRequest(request);
//        ArrayList<Object> objectList = new ArrayList<>();
//        objectList.add(0);
//        BackRequestMessage backRequestMessage = new BackRequestMessage("message", objectList);
//        Robot robot = new Robot();
//        ResponseMessage actualExecuteResult = backRequestMessage.execute(robot, new World());
//        assertEquals(1, actualExecuteResult.getData().size());
//        HashMap<String, Object> state = ((SuccessResponseMessage) actualExecuteResult).getState();
//        assertSame(robot, state);
//        assertNull(state.getObstacles());
//        List<Integer> position = state.getPosition();
//        assertEquals(2, position.size());
//        assertEquals(0, position.get(1));
//        Position robotPosition = state.getRobotPosition();
//        assertEquals(0, robotPosition.getY());
//    }
}

