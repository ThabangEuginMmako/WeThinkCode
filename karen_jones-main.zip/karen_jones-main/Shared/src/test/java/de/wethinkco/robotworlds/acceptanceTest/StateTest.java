package de.wethinkco.robotworlds.acceptanceTest;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import de.wethinkco.robotworlds.protocol.RequestsHandler.BackRequestMessage;
import de.wethinkco.robotworlds.protocol.RequestsHandler.LaunchRequestMessage;
import de.wethinkco.robotworlds.protocol.RequestsHandler.RequestMessage;
import de.wethinkco.robotworlds.protocol.RequestsHandler.StateRequestMessage;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.ResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.SuccessResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.Robot;
import de.wethinkco.robotworlds.protocol.world.*;
import org.codehaus.jackson.annotate.JsonSubTypes;
import org.codehaus.jackson.annotate.JsonTypeInfo;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class StateTest {
    private final static int DEFAULT_PORT = 5000;
    private final static String DEFAULT_IP = "localhost";
    private final RobotWorldClient serverClient = new RobotWorldJsonClient();

    @JsonTypeInfo(
            use = JsonTypeInfo.Id.NAME,
            include = JsonTypeInfo.As.PROPERTY,
            property = "type"
    )
    @JsonSubTypes({
            @JsonSubTypes.Type(value = LaunchRequestMessage.class, name = "launch"),
            @JsonSubTypes.Type(value = BackRequestMessage.class, name = "back")
    })
    @JsonDeserialize(as = BackRequestMessage.class)
    @BeforeEach
    void connectToServer() {
//        try {
//            Process proc = Runtime.getRuntime().exec("java -jar .libs/reference-server-0.1.0.jar");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        serverClient.connect(DEFAULT_IP, DEFAULT_PORT);

    }

    @AfterEach
    void disconnectFromServer() {
        serverClient.disconnect();
    }

    @Test
    void getStateRequest(){
        StateRequestMessage test = new StateRequestMessage("aalz");
        assertEquals("state", test.getCommand());
    }

    @Test
    public void doStateRequest() {
        List<IObstacle> list = new ArrayList<IObstacle>();
        IObstacle obstacle = new SquareObstacle(1,1);
        StateRequestMessage test = new StateRequestMessage();
        list.add(obstacle);
        GridSize grid = new GridSize(200, 100);
        RobotVisionField visionField = new RobotVisionField(10);
        Robot robot = new Robot();
        World world = new World(list);

        ResponseMessage responseMessage= test.execute(robot, world);
        assertEquals("OK",responseMessage.getResult());

        assertInstanceOf(SuccessResponseMessage.class, responseMessage);
        SuccessResponseMessage success = (SuccessResponseMessage) responseMessage;
        assertNotNull(success);
//        assertNotNull(success.getState());
//        assertEquals("NORTH", success.getState().getDirection());

        //do a move to blocked
        // assert state again
//        RequestMessage forward = RequestMessage.createRequest("aalz", "forward 1");
//        responseMessage= forward.execute(robot, world);
//        assertEquals("OK",responseMessage.getResult());
//        assertEquals(1, responseMessage.getData().size());
//        assertInstanceOf(SuccessResponseMessage.class, responseMessage);
//        success = (SuccessResponseMessage) responseMessage;
//        assertNotNull(success);
//        assertNotNull(success.getState());
//        assertEquals("NORTH", success.getState().getDirection());
    }
}
