package de.wethinkco.robotworlds.acceptanceTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import de.wethinkco.robotworlds.protocol.Position;
import de.wethinkco.robotworlds.protocol.RequestsHandler.BackRequestMessage;
import de.wethinkco.robotworlds.protocol.RequestsHandler.FireRequestMessage;
import de.wethinkco.robotworlds.protocol.RequestsHandler.ForwardRequestMessage;
import de.wethinkco.robotworlds.protocol.RequestsHandler.LaunchRequestMessage;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.ResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.SuccessResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.Robot;
import de.wethinkco.robotworlds.protocol.world.World;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.codehaus.jackson.annotate.JsonSubTypes;
import org.codehaus.jackson.annotate.JsonTypeInfo;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
/**
 * ITERATION 1
 * As a player
 * I want to move forward by certain steps.

 *ITERATION 2
 As a player
 I want to command my robot to move forward a specified number of steps
 so that I can explore the world and not be a sitting duck in a battle.
 */
class ForwardRequestMessageTest {
    private final static int DEFAULT_PORT = 5000;
    private final static String DEFAULT_IP = "localhost";
    private final RobotWorldClient serverClient = new RobotWorldJsonClient();


    @BeforeEach
    void connectToServer() {
//                try {
//            Process proc = Runtime.getRuntime().exec("java -jar .libs/reference-server-0.1.0.jar");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        serverClient.connect(DEFAULT_IP, DEFAULT_PORT);
    }

    @AfterEach
    void disconnectFromServer() {
        serverClient.disconnect();
    }


    /**
     * ITERATION 1
     * Successfully moved forward.
     If there is no obstacle or another robot in the robot's view, then the robot will be able to move forward.

     *ITERATION 2
     Given that I am connected to a running Robot Worlds server
     And the world is of size 1x1 with no obstacles or pits
     And a robot called "HAL" is already connected and launched
     When I send a command for "HAL" to move forward by 10 steps
     Then I should get an "OK" response with the message "Moved forward by 10 steps"
     and the position information returned should be at co-ordinates [10,0]
     */
    @Test
    void testForwardRequest() {
        Assertions.assertTrue(serverClient.isConnected());
        String LaunchRequest = "{" +
                "  \"robot\": \"HAL\"," +
                "  \"command\": \"launch\"," +
                "  \"arguments\": [\"sniper]\",\"5\",\"5\"]" +
                "}";

        String request = "{" +
                "  \"robot\": \"HAL\"," +
                "  \"command\": \"forward\"," +
                "  \"arguments\": [\"5\"]" +
                "}";
        JsonNode LaunchResponse = serverClient.sendRequest(LaunchRequest);
        JsonNode response = serverClient.sendRequest(request);
        ArrayList<Object> objectList = new ArrayList<>();
        ForwardRequestMessage actualForwardRequestMessage = new ForwardRequestMessage("Robot", objectList);

        List<Object> arguments = actualForwardRequestMessage.getArguments();
        assertSame(objectList, arguments);
//       assertTrue(arguments.isEmpty());
        assertEquals("Robot", actualForwardRequestMessage.getRobot());
        assertEquals("forward", actualForwardRequestMessage.getCommand());
        assertSame(arguments, objectList);
    }

    /**
     * ITERATION 1
     * If the user inputs and invalid step i.e not a digit, the server will respond
     * with an error message saying "Invalid Steps".

     *ITERATION 2

     */
    @Test
    void testInvalidSteps() {
        Assertions.assertTrue(serverClient.isConnected());
        String LaunchRequest = "{" +
                "  \"robot\": \"HAL\"," +
                "  \"command\": \"launch\"," +
                "  \"arguments\": [\"sniper]\",\"5\",\"5\"]" +
                "}";

        String request = "{" +
                "\"robot\": \"HAL\"," +
                "\"command\": \"forward\"," +
                "\"arguments\": [\"0\"]" +
                "}";
        JsonNode LaunchResponse = serverClient.sendRequest(LaunchRequest);
        JsonNode response = serverClient.sendRequest(request);
        ForwardRequestMessage forwardRequestMessage = new ForwardRequestMessage();
        Robot target = new Robot();
        ResponseMessage actualExecuteResult = forwardRequestMessage.execute(target, new World());
        assertEquals(1, actualExecuteResult.getData().size());
        assertEquals("Error", actualExecuteResult.getResult());
    }
    /**
     * ITERATION 1
     * Obstacle on the way.
     If there is an obstacle or another robot within 10 steps in the robot's view, the robot will be restricted from moving backwards.
      The position of the robot has not changed.

     *ITERATION 2
     * Obstacle on the way.
     Given that I am connected to a running Robot Worlds server
     And the world is of size 100x200 with obstacles or pits
     And a robot called "HAL" is already connected and launched
     When I send a command for "HAL" to move forward by 10 steps
     Then I should get an "OK" response with the message "There is an obstacle on the way"
     and the position information returned should be at co-ordinates [0,0]
     */
    @Test
    void testOstacleOnTheWay() {
        Assertions.assertTrue(serverClient.isConnected());
        String LaunchRequest = "{" +
                "  \"robot\": \"HAL\"," +
                "  \"command\": \"launch\"," +
                "  \"arguments\": [\"sniper]\",\"5\",\"5\"]" +
                "}";
        String request = "{" +
                "\"robot\": \"HAL\"," +
                "\"command\": \"forward\"," +
                "\"arguments\": [\"10\"]" +
                "}";
        JsonNode LaunchResponse = serverClient.sendRequest(LaunchRequest);
        JsonNode response = serverClient.sendRequest(request);

        ArrayList<Object> objectList = new ArrayList<>();
        objectList.add("42");
        ForwardRequestMessage forwardRequestMessage = new ForwardRequestMessage("message", objectList);
        Robot robot = new Robot();
        ResponseMessage actualExecuteResult = forwardRequestMessage.execute(robot, new World());
        assertEquals(1, actualExecuteResult.getData().size());
        HashMap<String, Object> state = ((SuccessResponseMessage) actualExecuteResult).getState();
//        assertSame(robot, state);
////        assertEquals("Blocked", actualExecuteResult.getResult());
//        assertNull(state.getObstacles());
//        List<Integer> position = state.getPosition();
//        assertEquals(2, position.size());
////        assertEquals(-1, position.get(0));
//        assertEquals(-42, position.get(1));
//        Position robotPosition = state.getRobotPosition();
////        assertEquals(-1, robotPosition.getX());
//        assertEquals(-42, robotPosition.getY());
    }

    /**
     * ITERATION 1
     unsuccessful attempt due to many arguments provided.
     If the user provides too many arguments,the server will send back an error message saying
     'Too many arguments provided.' and therefor restricting the robot to move.

     *ITERATION 2
     *  unsuccessful attempt due to many arguments provided.
     Given that I am connected to a running Robot Worlds server
     And a robot called "HAL" is already connected and launched
     When I send a command for "HAL" to move forward and provide many arguments e.g "back 10 10"
     Then I should get an "ERROR" response with the message "Too many arguments"
     and the position information returned should be at co-ordinates [0,0] if the robot
     was initially at position [0,0].
     */
    @Test
    void testTooManyArguments() {
        Assertions.assertTrue(serverClient.isConnected());
        String LaunchRequest = "{" +
                "  \"robot\": \"HAL\"," +
                "  \"command\": \"launch\"," +
                "  \"arguments\": [\"sniper]\",\"5\",\"5\"]" +
                "}";

        String request = "{" +
                "  \"robot\": \"HAL\"," +
                "  \"command\": \"forward\"," +
                "  \"arguments\": [\"42\",\"42\"]" +
                "}";
        JsonNode LaunchResponse = serverClient.sendRequest(LaunchRequest);
        JsonNode response = serverClient.sendRequest(request);
        Assertions.assertTrue(serverClient.isConnected());
        ArrayList<Object> objectList = new ArrayList<>();
        objectList.add("42");
        objectList.add("42");
        ForwardRequestMessage forwardRequestMessage = new ForwardRequestMessage("message", objectList);
        Robot target = new Robot();
        ResponseMessage actualExecuteResult = forwardRequestMessage.execute(target, new World());
        assertEquals(1, actualExecuteResult.getData().size());
        assertEquals("Error", actualExecuteResult.getResult());
    }
    /**
     * ITERATION 1
     * Zero steps
     * if the user inputs 0 for the number of steps,the server will respond with an
     error message saying "zero steps".

      *ITERATION 2
           Zero steps
     *      Given that I am connected to a running Robot Worlds server
     *      And a robot called "HAL" is already connected and launched
     *      When I send a command for "HAL" to move backward  by zero steps i.e "back 0"
     *      Then I should get an "ERROR" response with the message "Zero Steps"
     *      and the position information returned should be at co-ordinates [0,0] if the robot
     *      was initially at position [0,0].

     */
    @Test
    void test0steps() {
        Assertions.assertTrue(serverClient.isConnected());
        String LaunchRequest = "{" +
                "  \"robot\": \"HAL\"," +
                "  \"command\": \"launch\"," +
                "  \"arguments\": [\"sniper]\",\"5\",\"5\"]" +
                "}";
        String request = "{" +
                "\"robot\": \"HAL\"," +
                "\"command\": \"forward\"," +
                "\"arguments\": [\"0\"]" +
                "}";
        JsonNode response = serverClient.sendRequest(request);
        ArrayList<Object> objectList = new ArrayList<>();
        objectList.add("NORTH");
        ForwardRequestMessage forwardRequestMessage = new ForwardRequestMessage("message", objectList);
        Robot target = new Robot();
        ResponseMessage actualExecuteResult = forwardRequestMessage.execute(target, new World());
        assertEquals(1, actualExecuteResult.getData().size());
        assertEquals("ERROR", actualExecuteResult.getResult());
    }


    /**
     * Outside zone
     * If the user attempts to move outside the allowed area, the server will block the robot
     * from moving and send a response that the robot cannot move outside the zone.
     */
    @Test
    void testOutsideZone() {
        Assertions.assertTrue(serverClient.isConnected());
        String LaunchRequest = "{" +
                "  \"robot\": \"HAL\"," +
                "  \"command\": \"launch\"," +
                "  \"arguments\": [\"sniper]\",\"5\",\"5\"]" +
                "}";
        String request = "{" +
                "\"robot\": \"HAL\"," +
                "\"command\": \"forward\"," +
                "\"arguments\": [\"0\"]" +
                "}";
        JsonNode response = serverClient.sendRequest(request);
        Assertions.assertTrue(serverClient.isConnected());
        ArrayList<Object> objectList = new ArrayList<>();
        objectList.add(0);
        ForwardRequestMessage forwardRequestMessage = new ForwardRequestMessage("message", objectList);
        Robot robot = new Robot();
        ResponseMessage actualExecuteResult = forwardRequestMessage.execute(robot, new World());
        assertEquals(1, actualExecuteResult.getData().size());
        HashMap<String, Object> state = ((SuccessResponseMessage) actualExecuteResult).getState();
//        assertSame(robot, state);
////        assertEquals("Ok", actualExecuteResult.getResult());
//        assertNull(state.getObstacles());
//        List<Integer> position = state.getPosition();
//        assertEquals(2, position.size());
////        assertEquals(-1, position.get(0));
//        assertEquals(0, position.get(1));
//        Position robotPosition = state.getRobotPosition();
////        assertEquals(-1, robotPosition.getX());
//        assertEquals(0, robotPosition.getY());
    }
}

