package de.wethinkco.robotworlds.acceptanceTest;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import de.wethinkco.robotworlds.protocol.RequestsHandler.BackRequestMessage;
import de.wethinkco.robotworlds.protocol.RequestsHandler.LaunchRequestMessage;
import de.wethinkco.robotworlds.protocol.RequestsHandler.LookRequestMessage;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.ObstacleResponse;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.ResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.Robot;
import de.wethinkco.robotworlds.protocol.world.*;
import org.codehaus.jackson.annotate.JsonSubTypes;
import org.codehaus.jackson.annotate.JsonTypeInfo;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class LookTest {
    private final static int DEFAULT_PORT = 5000;
    private final static String DEFAULT_IP = "localhost";
    private final RobotWorldClient serverClient = new RobotWorldJsonClient();


    @BeforeEach
    void connectToServer() {
//        try {
//            Process proc = Runtime.getRuntime().exec("java -jar .libs/reference-server-0.1.0.jar");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        serverClient.connect(DEFAULT_IP, DEFAULT_PORT);
    }

    @AfterEach
    void disconnectFromServer() {
        serverClient.disconnect();
    }

    @Test
    void getLookRequest(){
        LookRequestMessage test = new LookRequestMessage("aalz");
        assertEquals("look", test.getCommand());
    }

    @Test
    public void lookRequest() {
        List<IObstacle> list = new ArrayList<>();
        IObstacle obstacle = new SquareObstacle(1,1);
        LookRequestMessage test = new LookRequestMessage();
        list.add(obstacle);
        GridSize grid = new GridSize(200, 100);
        RobotVisionField visionField = new RobotVisionField(10);
        Robot robot = new Robot();
        World world = new World(list);

        ResponseMessage responseMessage= test.execute(robot, world);
        assertEquals("OK",responseMessage.getResult());
        assertEquals(1, responseMessage.getData().size());
        assertTrue(responseMessage.getData().containsKey("objects"));
        List<ObstacleResponse> obstacles = (List<ObstacleResponse>) responseMessage.getData().get("objects");
        assertEquals(1, obstacles.size());
        ObstacleResponse obstacleResponse = obstacles.get(0);
        assertEquals("NORTH", obstacleResponse.getDirection());
        assertEquals(TypeOfObject.OBSTACLE, obstacleResponse.getTypeOfObject());
        assertEquals(1, obstacleResponse.getSteps());
    }

//    @Test
//    void LookIfWorldIsEmptyTest(){
//        assertTrue(serverClient.isConnected());
//
//        String LaunchRequest = "{" +
//                "  \"robot\": \"HAL\"," +
//                "  \"command\": \"launch\"," +
//                "  \"arguments\": [\"sniper]\",\"5\",\"5\"]" +
//                "}";
//
//        String Request = "{" +
//                "  \"robot\": \"HAL\"," +
//                "  \"command\": \"look\"," +
//                "  \"arguments\": []" +
//                "}";
//        JsonNode LaunchResponse = serverClient.sendRequest(LaunchRequest);
//        JsonNode response = serverClient.sendRequest(Request);
//
//        assertNotNull(response.get("result"));
//        assertEquals("OK", response.get("result").asText());
//
//        assertNotNull(response.get("data"));
//        assertNotNull(response.get("state"));
////        assertTrue(response.get("data").get("message").asText().contains("Robot does not exist"));
//    }

//    @Test
//    void seeAnObstacleTest(){
//        assertTrue(serverClient.isConnected());
//
//        //        Given a world of size 2x2
//        //        and the world has an obstacle at coordinate [0,1]
//        //        and I have successfully launched a robot into the world
//        String launch_request = "{" +
//                "  \"robot\": \"HAL\"," +
//                "  \"command\": \"launch\"," +
//                "  \"arguments\": [\"sniper]\",\"5\",\"5\"]" +
//                "}";
//        String request = "{" +
//                "  \"robot\": \"HAL\"," +
//                "  \"command\": \"look\"," +
//                "  \"arguments\": []" +
//                "}";
//        //        When I ask the robot to look
//        JsonNode Response = serverClient.sendRequest(launch_request);
////        System.out.println(Response);
//        JsonNode response = serverClient.sendRequest(request);
//        System.out.println(response);
//
//        //        Then I should get a response back with an object of type OBSTACLE at a distance of 1 step.
//        assertNotNull(response.get("result"));
//        assertEquals("OK", response.get("result").asText());
//        assertNotNull(response.get("data").get("objects"));
//        assertTrue(response.get("data").get("objects").isArray());
//
//        JsonNode arr = response.get("data").get("objects");
//
//        for(JsonNode elem: arr){
//            if (elem.get("type").asText().equals("OBSTACLE")) {
//                assertEquals("1", elem.get("distance").asText());
//                break;
//            }
//        }
//    }

}
