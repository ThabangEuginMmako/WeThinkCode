package de.wethinkco.robotworlds.acceptanceTest;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import de.wethinkco.robotworlds.protocol.RequestsHandler.BackRequestMessage;
import de.wethinkco.robotworlds.protocol.RequestsHandler.LaunchRequestMessage;
import de.wethinkco.robotworlds.protocol.RequestsHandler.ReloadRequestMessage;
import de.wethinkco.robotworlds.protocol.RobotStatus;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.ResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.SuccessResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.Robot;
import de.wethinkco.robotworlds.protocol.world.World;
import org.codehaus.jackson.annotate.JsonSubTypes;
import org.codehaus.jackson.annotate.JsonTypeInfo;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ReloadRequestMessageTest {

    private final static int DEFAULT_PORT = 5000;
    private final static String DEFAULT_IP = "localhost";
    private final RobotWorldClient serverClient = new RobotWorldJsonClient();

    @JsonTypeInfo(
            use = JsonTypeInfo.Id.NAME,
            include = JsonTypeInfo.As.PROPERTY,
            property = "type"
    )
    @JsonSubTypes({
            @JsonSubTypes.Type(value = LaunchRequestMessage.class, name = "launch"),
            @JsonSubTypes.Type(value = BackRequestMessage.class, name = "back")
    })
    @JsonDeserialize(as = BackRequestMessage.class)
    @BeforeEach
    void connectToServer() {
//        try {
//            Process proc = Runtime.getRuntime().exec("java -jar .libs/reference-server-0.1.0.jar");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        serverClient.connect(DEFAULT_IP, DEFAULT_PORT);

    }

    @AfterEach
    void disconnectFromServer() {
        serverClient.disconnect();
    }

    @Test
    void testReloadRequest() {
        ArrayList<Object> objectList = new ArrayList<>();
        ReloadRequestMessage actualReloadRequestMessage = new ReloadRequestMessage("Robot", objectList);

        List<Object> arguments = actualReloadRequestMessage.getArguments();
        assertSame(objectList, arguments);
        assertTrue(arguments.isEmpty());
        assertEquals("Robot", actualReloadRequestMessage.getRobot());
        assertEquals("reload", actualReloadRequestMessage.getCommand());
        assertSame(arguments, objectList);
    }

    @Test
    void testReloadRequestMessage() {
        ReloadRequestMessage actualReloadRequestMessage = new ReloadRequestMessage("Robot");
        assertTrue(actualReloadRequestMessage.getArguments().isEmpty());
        assertEquals("Robot", actualReloadRequestMessage.getRobot());
        assertEquals("reload", actualReloadRequestMessage.getCommand());
    }

    @Test
    void testResponseMessage() {
        ReloadRequestMessage reloadRequestMessage = new ReloadRequestMessage("Robot");
        Robot robot = new Robot();
        ResponseMessage actualExecuteResult = reloadRequestMessage.execute(robot, new World());
        assertEquals(1, actualExecuteResult.getData().size());
        HashMap<String, Object> state = ((SuccessResponseMessage) actualExecuteResult).getState();
//        assertSame(robot, state);
//        assertEquals("OK", actualExecuteResult.getResult());
//        assertEquals(RobotStatus.RELOAD, state.getStatus());
//        assertEquals(0, state.getShots().intValue());
    }


}

