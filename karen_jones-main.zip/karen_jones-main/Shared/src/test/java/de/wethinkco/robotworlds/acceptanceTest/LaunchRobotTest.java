package de.wethinkco.robotworlds.acceptanceTest;

import com.fasterxml.jackson.databind.JsonNode;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;

import static org.junit.jupiter.api.Assertions.*;

//     * As a player
//     * I want to launch my robot in the online robot world
//     */

public class LaunchRobotTest {

    final static int DEFAULT = 5000;
    final static String DEFAULT_IP = "localhost";
    private final RobotWorldClient serverClient = new RobotWorldJsonClient();

    @BeforeEach
    public void connectToServer() {
//        try {
//            Process proc = Runtime.getRuntime().exec("java -jar .libs/reference-server-0.2.3.jar");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        serverClient.connect(DEFAULT_IP, DEFAULT);
    }

//    @AfterEach
//    void disconnectFromServer() {
//        serverClient.disconnect();
//    }
//
//    @Test
//    public void invalidLaunchShouldFailTest() {
//
//        // Given that I am connected to a running Robot Worlds server
//        Assertions.assertEquals(true, serverClient.isConnected());
//
//        // When I send a invalid launch request with the command "luanch" instead of "launch"
//        String request = "{" +
//                "\"robot\": \"HAL\"," +
//                "\"command\": \"luanch\"," +
//                "\"arguments\": [\"sniper\",\"1\",\"5\"]" +
//                "}";
//        JsonNode response = serverClient.sendRequest(request);
//
//        // Then I should get an error response
//        Assertions.assertNotNull(response.get("result"));
//        Assertions.assertEquals("ERROR", response.get("result").asText());
//
//        // And the message "Unsupported command"
//        Assertions.assertNotNull(response.get("data"));
//        Assertions.assertNotNull(response.get("data").get("message"));
//        Assertions.assertTrue(response.get("data").get("message").asText().contains("Unsupported command"));
//    }
//
//    @Test
//    public void validLaunchShouldSucceedTest() {
//        // Given that I am connected to a running Robot Worlds server
//        // And the world is of size 1x1 (The world is configured or hardcoded to this size)
//        Assertions.assertTrue(serverClient.isConnected());
//
//        // When I send a valid launch request to the server
//        String request = "{" +
//                "  \"robot\": \"HAL\"," +
//                "  \"command\": \"launch\"," +
//                "  \"arguments\": [\"tank\",\"5\",\"1\"]" +
//                "}";
//        JsonNode response = serverClient.sendRequest(request);
//
//        // Then I should get a valid response from the server
//        Assertions.assertNotNull(response.get("result"));
//        Assertions.assertEquals("OK", response.get("result").asText());
//
//        // And the position should be (x:0, y:0)
//        Assertions.assertNotNull(response.get("data"));
//        Assertions.assertNotNull(response.get("data").get("position"));
//        Assertions.assertEquals(0, response.get("data").get("position").get(0).asInt());
//        Assertions.assertEquals(0, response.get("data").get("position").get(1).asInt());
//
//        // And I should also get the state of the robot
//
//        Assertions.assertNotNull(response.get("state"));
//
//        assertNotNull(response.get("state"));
//
//        JsonNode arr = response.get("data").get("objects");
//
//        for(JsonNode elem: arr){
//            if (elem.get("type").asText().equals("state")) {
//                assertEquals("1", elem.get("distance").asText());
//                break;
//            }
//        }
//    }
//
//}

    @Test
    public void validLaunchShouldSucceed(){
        serverClient.connect(DEFAULT_IP, DEFAULT);
        // Given that I am connected to a running Robot Worlds server
        // And the world is of size 1x1 (The world is configured or hardcoded to this size)

        assertTrue(serverClient.isConnected());

        // When I send a valid launch request to the server
        String request = "{" +
                "  \"robot\": \"jake\"," +
                "  \"command\": \"launch\"," +
                "  \"arguments\": [\"sniper]\",\"5\",\"5\"]" +
                "}";

        JsonNode response = serverClient.sendRequest(request);
        System.out.println(response);

        // Then I should get a valid response from the server
        assertNotNull(response.get("result"));
        assertEquals("OK", response.get("result").asText());

        // And the position should be (x:0, y:0)
        assertNotNull(response.get("data"));
        assertNotNull(response.get("state"));
        assertNotNull(response.get("state").get("position"));

        serverClient.disconnect();
    }

    @Test
    public void invalidLaunchShouldFail(){
        serverClient.connect(DEFAULT_IP, DEFAULT);
        // Given that I am connected to a running Robot Worlds server
        assertTrue(serverClient.isConnected());

        // When I send an invalid launch request with the command "luanch" instead of "launch"
        String request = "{" +
                "\"robot\": \"HAL\"," +
                "\"command\": \"luanch\"," +
                "\"arguments\": [\"sniper\",\"5\",\"5\"]" +
                "}";
        JsonNode response = serverClient.sendRequest(request);
        System.out.println(response);

        // Then I should get an error response
        assertNotNull(response.get("result"));
        assertEquals("ERROR", response.get("result").asText());

        // And the message "Unsupported command"
        assertNotNull(response.get("data"));
        assertNotNull(response.get("data").get("message"));
        assertTrue(response.get("data").get("message").asText().contains("Unsupported command"));

        serverClient.disconnect();
    }

    @Test
    public void tooManyOfYou(){
        serverClient.connect(DEFAULT_IP, DEFAULT);

        // Given that I am connected to a running Robot Worlds server
        assertTrue(serverClient.isConnected());

        // When I send a valid launch request to a full server
        String firstRequest = "{" +
                "\"robot\": \"HAL\"," +
                "\"command\": \"launch\"," +
                "\"arguments\": [\"sniper\",\"5\",\"5\"]" +
                "}";
        JsonNode response;

        response = serverClient.sendRequest(firstRequest);

        String secondRequest = "{" +
                "\"robot\": \"HAL\"," +
                "\"command\": \"launch\"," +
                "\"arguments\": [\"sniper\",\"5\",\"5\"]" +
                "}";
        response = serverClient.sendRequest(secondRequest);

        // Then I should get an error response
        assertEquals("ERROR", response.get("result").asText());

        // And the message "Too many of you in this world"
        assertNotNull(response.get("data"));
        assertNotNull(response.get("data").get("message"));
        assertTrue(response.get("data").get("message").asText().contains("Too many of you in this world"));

        serverClient.disconnect();
    }

    //2x2 world
    @Test
    public void canLaunchAnotherRobot(){
        serverClient.connect(DEFAULT_IP, DEFAULT);

        assertTrue(serverClient.isConnected());

        // robot "HAL" has already been launched into the world
       String firstRobot = "{" +
               "  \"robot\": \"Hal\"," +
               "  \"command\": \"launch\"," +
               "  \"arguments\": [\"sniper\",\"5\",\"5\"]" +
               "}";

       JsonNode response1 = serverClient.sendRequest(firstRobot);
       System.out.println(response1);

       // Launch should be successful
       assertNotNull(response1.get("result"));

       assertEquals("OK", response1.get("result").asText());

       assertNotNull(response1.get("data"));
       assertNotNull(response1.get("state").get("position"));
       assertNotNull(response1.get("state"));

        // Given a world of size 2x2
        assertTrue(serverClient.isConnected());

       // When I launch robot "R2D2" into the world
       String secondRobot = "{" +
               "  \"robot\": \"R2D2\"," +
               "  \"command\": \"launch\"," +
               "  \"arguments\": [\"sniper\",\"5\",\"5\"]" +
               "}";

       JsonNode response2 = serverClient.sendRequest(secondRobot);

       // Launch should be successful
       assertNotNull(response2.get("result"));

       assertEquals("OK", response2.get("result").asText());

       // and a randomly allocated position of R2D2 should be returned
       assertNotNull(response2.get("data"));
       assertNotNull(response2.get("state").get("position"));
       assertNotNull(response2.get("state"));

        serverClient.disconnect();
   }

//    @Test
//    @Disabled
//    public void worldWorldWithoutObstaclesIsFull(){
//        serverClient.connect(DEFAULT_IP, DEFAULT);
//
//        // Given that I am connected to a running Robot Worlds server
//        assertTrue(serverClient.isConnected());
//
//        String R1 = "{" +
//                "  \"robot\": \"Robot1\"," +
//                "  \"command\": \"launch\"," +
//                "  \"arguments\": [\"sniper\",\"5\",\"5\"]" +
//                "}";
//
//        serverClient.sendRequest(R1);
//        //  launch 2nd robot into world
//        String R2 = "{" +
//                "  \"robot\": \"Robot2\"," +
//                "  \"command\": \"launch\"," +
//                "  \"arguments\": [\"sniper\",\"5\",\"5\"]" +
//                "}";
//
//        serverClient.sendRequest(R2);
//        //  launch 3rd robot into world
//        String R3 = "{" +
//                "  \"robot\": \"Robot3\"," +
//                "  \"command\": \"launch\"," +
//                "  \"arguments\": [\"sniper\",\"5\",\"5\"]" +
//                "}";
//
//        serverClient.sendRequest(R3);
//        //  launch 4th robot into world
//        String R4 = "{" +
//                "  \"robot\": \"Robot4\"," +
//                "  \"command\": \"launch\"," +
//                "  \"arguments\": [\"sniper\",\"5\",\"5\"]" +
//                "}";
//
//        serverClient.sendRequest(R4);
//        //  launch 5th robot into world
//        String R5 = "{" +
//                "  \"robot\": \"Robot5\"," +
//                "  \"command\": \"launch\"," +
//                "  \"arguments\": [\"sniper\",\"5\",\"5\"]" +
//                "}";
//
//        serverClient.sendRequest(R5);
//        //  launch 6th robot into world
//        String R6 = "{" +
//                "  \"robot\": \"Robot6\"," +
//                "  \"command\": \"launch\"," +
//                "  \"arguments\": [\"sniper\",\"5\",\"5\"]" +
//                "}";
//
//        serverClient.sendRequest(R6);
//        //  launch 7th robot into world
//        String R7 = "{" +
//                "  \"robot\": \"Robot7\"," +
//                "  \"command\": \"launch\"," +
//                "  \"arguments\": [\"sniper\",\"5\",\"5\"]" +
//                "}";
//
//        serverClient.sendRequest(R7);
//        //  launch 8th robot into world
//        String R8 = "{" +
//                "  \"robot\": \"Robot8\"," +
//                "  \"command\": \"launch\"," +
//                "  \"arguments\": [\"sniper\",\"5\",\"5\"]" +
//                "}";
//
//        serverClient.sendRequest(R8);
//        //  launch 9th robot into world
//        String R9 = "{" +
//                "  \"robot\": \"Robot9\"," +
//                "  \"command\": \"launch\"," +
//                "  \"arguments\": [\"sniper\",\"5\",\"5\"]" +
//                "}";
//
//        serverClient.sendRequest(R9);
//        //  launch 10th robot into world (should fail)
//        String R10 = "{" +
//                "  \"robot\": \"Robot10\"," +
//                "  \"command\": \"launch\"," +
//                "  \"arguments\": [\"sniper\",\"5\",\"5\"]" +
//                "}";
//
//        JsonNode response = serverClient.sendRequest(R10);
//
//        // Then I should get an error response
//        assertEquals("ERROR", response.get("result").asText());
//
//        // And the message "No more space in this world"
//        assertNotNull(response.get("data"));
//        assertNotNull(response.get("data").get("message"));
//        //    System.out.println(response.get("data").get("message"));
//        assertTrue(response.get("data").get("message").asText().contains("No more space in this world"));
//
//        serverClient.disconnect();
//    }
}
