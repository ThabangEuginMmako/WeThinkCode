package de.wethinkco.robotworlds.protocol.world;

public interface Obstacle {

}
