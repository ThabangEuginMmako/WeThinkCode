package de.wethinkco.robotworlds.protocol.robots.ResponseHandler;

public enum NewPositionResponse {
    OBSTACLE_BLOCKED, ROBOT_BLOCKED, NOT_BLOCKED, OUTSIDE_WORLD, INVALID_MOVEMENT
}
