package de.wethinkco.robotworlds.protocol.RequestsHandler;

import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.ResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.SuccessResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.Robot;

import de.wethinkco.robotworlds.protocol.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StateRequestMessage extends RequestMessage{
    public StateRequestMessage(String robot, List<Object> arguments) {
        super(robot, "state", arguments);
    }
    public StateRequestMessage(String robot) {
        super(robot, "state", new ArrayList<>());
    }

    public StateRequestMessage() {

    }

    @Override
    public ResponseMessage execute(Robot target, World world) {

        Map<String, Object> mapData = new HashMap<>();
        HashMap<String, Object> state = new HashMap<>();

        int x = target.getPosition().get(0);
        int y = target.getPosition().get(1);

        state.put("position", "["+x+","+y+"]");
        state.put("direction", target.getDirection());
        state.put("shields", target.getShields());
        state.put("reload", target.reloadTime());
        state.put("repair", target.repairTime());
        state.put("shots", target.getShots());
        state.put("status", target.getStatus());

        mapData.put("message", "state");

        // Error message stating that the user already has a robot launched.
        return new SuccessResponseMessage("OK", mapData, state);


    }
}
