package de.wethinkco.robotworlds.protocol.robots.ResponseHandler;

import de.wethinkco.robotworlds.protocol.robots.Robot;

import java.util.HashMap;
import java.util.Map;

public class SuccessResponseMessage extends ResponseMessage {

    public SuccessResponseMessage() {
        super("OK", new HashMap<String, Object>() {});
    }
    public SuccessResponseMessage(String result, Map < String, Object > data) {
            super(result, data);
        }
    public SuccessResponseMessage(String result, Map < String, Object > data, HashMap<String, Object> state) {
            super(result, data);
            this.state = state;
    }

    public void setState (HashMap<String, Object> state){
        this.state = state;
    }

}

