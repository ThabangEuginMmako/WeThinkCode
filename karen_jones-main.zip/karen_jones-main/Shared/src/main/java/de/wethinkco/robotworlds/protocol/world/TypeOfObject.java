package de.wethinkco.robotworlds.protocol.world;

public enum TypeOfObject {
    OBSTACLE, EDGE, ROBOT
}
