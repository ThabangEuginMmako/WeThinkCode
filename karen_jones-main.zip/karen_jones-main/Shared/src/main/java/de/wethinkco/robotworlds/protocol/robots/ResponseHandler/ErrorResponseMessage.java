package de.wethinkco.robotworlds.protocol.robots.ResponseHandler;

import java.util.Map;

public class ErrorResponseMessage extends ResponseMessage{

    public ErrorResponseMessage(String result, Map<String, Object> data) {
        super(result, data);
    }
}
