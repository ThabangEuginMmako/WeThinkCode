package de.wethinkco.robotworlds;

import de.wethinkco.robotworlds.helpers.JsonHelper;
import de.wethinkco.robotworlds.protocol.*;
import de.wethinkco.robotworlds.protocol.RequestsHandler.*;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.ErrorResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.ResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.ResponseHandler.SuccessResponseMessage;
import de.wethinkco.robotworlds.protocol.robots.Robot;
import de.wethinkco.robotworlds.protocol.world.ServerConfig;
import de.wethinkco.robotworlds.protocol.world.World;
import org.json.JSONObject;

import java.io.*;
import java.net.Socket;
import java.util.*;

/**
 * When a client connects the server spawns a thread to handle the client.
 * This way the server can handle multiple clients at the same time.
 *
 * This keyword should be used in setters, passing the object as an argument,
 * and to call alternate constructors (a constructor with a different set of
 * arguments.
 */

// Runnable is implemented on a class whose instances will be executed by a thread.
public class ClientHandler implements Runnable {

    // Array list of all the threads handling clients.
    public static ArrayList<ClientHandler> clientHandlers = new ArrayList<>();

    // Socket for a connection, buffer reader and writer for receiving and sending data respectively.
    private Socket socket;
    private BufferedReader bufferedReader;
    private BufferedWriter bufferedWriter;
    private String clientUsername;
    private static Robot robot;
    private String clientMake;
    // a helper class that serializes and deserializes json to objects
    private final JsonHelper jsonHelper = new JsonHelper();

    private final World world;
    // Creating the client handler from the socket the server passes.
    public ClientHandler(Socket socket, World world) {
        this.world = world;
        try {
            this.socket = socket;
            this.bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.bufferedWriter= new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
//            sendServerConfig(bufferedWriter);
            // When a client connects their username is sent.
//            String[] splitInitInput = bufferedReader.readLine().split(" ");
//            this.clientUsername = splitInitInput[0];
//            this.clientMake = splitInitInput[1];
            // Add the new robot client to the array so they can can interact on server with other robots.
//            this.world.addRobot(new Robot(this.clientUsername)); // Should make a createRobot method.
            clientHandlers.add(this);
        } catch (IOException e) {
            // Close everything more gracefully.
            closeEverything(socket, bufferedReader, bufferedWriter);
        }
    }

    // Everything in this method is run on a separate thread. We want to listen for messages
    // on a separate thread because listening (bufferedReader.readLine()) is a blocking operation.
    // A blocking operation means the caller waits for the callee to finish its operation.
    @Override
    public void run() {
        String jsonFromClient;
        // Continue to listen for messages while a connection with the client is still established.
        while (socket.isConnected()) {
            try {
                // Read what the client sent and then send it to every other client.
                jsonFromClient = bufferedReader.readLine();
                System.out.println("Request from client <<< "+ jsonFromClient);

                if (jsonFromClient != null) {
                    if (jsonFromClient.equals("response")) {
                        Map<String, Object> mapData = new HashMap<>();
                        mapData.put("message", "Unsupported command");
                        ResponseMessage responseMessage = new ErrorResponseMessage("ERROR", mapData);
                        HandleUnsupportedCommand(responseMessage);
                    } else {
                        String responseToClient = handleClientRequest(jsonFromClient);

                        System.out.println("response to client >>> " + responseToClient);
                        this.bufferedWriter.write(responseToClient);
                        this.bufferedWriter.newLine();
                        this.bufferedWriter.flush();
                        //                    RequestMessage requestMessage = jsonHelper.JsonToRequestMessage(jsonFromClient);
                        //                    HandleRequestMessage(requestMessage);
                    }
                } else {
                    throw new IOException("Request from client is 'null'");
                }
            } catch (IOException e) {
                // Close everything gracefully.
                closeEverything(socket, bufferedReader, bufferedWriter);
                break;
            }// The client disconnected or an error occurred so remove them from the list so no message is broadcasted.
        }
    }

    private String handleClientRequest(String jsonFromClient) {
        JSONObject jsonRequest = new JSONObject(jsonFromClient);
        String command = jsonRequest.get("command").toString();
        String robotName = jsonRequest.get("robot").toString();
        String arguments = jsonRequest.get("arguments").toString();

        arguments = arguments.replace("[", "").replace("]", "");
        String[] argumentsList = arguments.split(",");

        String robotMake = argumentsList[0];
        robotMake = robotMake.replaceAll("\"", "");

        RequestMessage requestMessage;
        ResponseMessage responseMessage = null;
        List<Object> args;

        switch (command) {
            case "launch":
                for (Robot connectedRobot:world.getRobots()) {
                    if (robotName.equals(connectedRobot.getRobotName())) {
                        JSONObject jsonResponse = new JSONObject();
                        JSONObject data = new JSONObject();
                        data.put("message", "Too many of you in this world");

                        jsonResponse.put("result", "ERROR");
                        jsonResponse.put("data", data);
                        return jsonResponse.toString();
                    }
                }
                robot = Robot.createRobot(robotName,robotMake);
                args = new ArrayList<>();

                Collections.addAll(args, argumentsList);

                requestMessage = new LaunchRequestMessage(robot.getRobotName(), args);
                responseMessage = requestMessage.execute(robot,world);
                world.addRobot(robot);
                break;
            case "forward":
                args = new ArrayList<>();
                args.add(argumentsList[0]);
                requestMessage = new ForwardRequestMessage(args);
                responseMessage = requestMessage.execute(robot, world);
                break;
            case "back":
                args = new ArrayList<>();
                args.add(argumentsList[0]);
                requestMessage = new BackRequestMessage(args);
                responseMessage = requestMessage.execute(robot, world);
                break;
            case "look":
                requestMessage = new LookRequestMessage();
                responseMessage = requestMessage.execute(robot, world);
                break;
            case "state":
                requestMessage = new StateRequestMessage();
                responseMessage = requestMessage.execute(robot, world);
                break;
            case "turn":
                break;
            case "fire":
                break;
            case "reload":
                break;
            case "repair":
                break;
            default:
                JSONObject jsonResponse = new JSONObject();
                JSONObject data = new JSONObject();
                data.put("message", "Unsupported command");

                jsonResponse.put("result", "ERROR");
                jsonResponse.put("data", data);
                return jsonResponse.toString();
        }
        JSONObject jsonResponse = new JSONObject();
        jsonResponse.put("result", responseMessage.getResult());
        jsonResponse.put("data", responseMessage.getData());
        jsonResponse.put("state", responseMessage.getState());

        return jsonResponse.toString();
    }

    private void HandleRequestMessage(RequestMessage requestMessage) {
        ResponseMessage responseMessage = null;
        Robot robot = this.world.getRobotByName(this.clientUsername);
        if (requestMessage.getRobot().equals("") && !(requestMessage instanceof LaunchRequestMessage)){
            Map<String, Object> mapData = new HashMap<>();
            mapData.put("message", "No robot launched");
            responseMessage = new ErrorResponseMessage("ERROR", mapData);

        } else if (!(robot == null) && robot.isDead()) {
            Map<String, Object> mapData = new HashMap<>();
            mapData.put("message", "Your robot is dead.");
            responseMessage = new ErrorResponseMessage("ERROR", mapData);
            closeEverything(socket, bufferedReader, bufferedWriter);
        }
        else {
            if (!(robot == null) && robot.isReloading()){
                robot.setStatus(RobotStatus.NORMAL);
            }
            responseMessage = requestMessage.execute(robot, this.world);

            if (requestMessage instanceof LaunchRequestMessage
                    && responseMessage instanceof SuccessResponseMessage){
                this.clientUsername = (String) requestMessage.getArguments().get(1);
            }
        }

        String jsonToSend = jsonHelper.ResponseMessageToJson(responseMessage);
        System.out.println("json to send: "+jsonToSend);


        try {
            this.bufferedWriter.write(jsonToSend);
            this.bufferedWriter.newLine();
            this.bufferedWriter.flush();
        } catch (IOException e) {
            closeEverything(socket, bufferedReader, bufferedWriter);
        }
        // if quit was successful, then close off the connection and remove the clienthandler
        // only close off after response written to client
        if (requestMessage instanceof ShutdownQuitOffRequestMessage
                && responseMessage instanceof SuccessResponseMessage){
            closeEverything(socket,bufferedReader,bufferedWriter);
        }
    }

    private void HandleUnsupportedCommand(ResponseMessage errorResponse){
        String jsonToSend = jsonHelper.ResponseMessageToJson(errorResponse);

        try{
            this.bufferedWriter.write(jsonToSend);
            this.bufferedWriter.newLine();
            this.bufferedWriter.flush();
        } catch (IOException e){
            closeEverything(socket, bufferedReader, bufferedWriter);
        }
    }

    // If the client disconnects for any reason remove them from the list so their not interacted with in world
    public void removeClientHandler() {
        clientHandlers.remove(this);
    }

    // Helper method to close everything so you don't have to repeat yourself.
    public void closeEverything(Socket socket, BufferedReader bufferedReader, BufferedWriter bufferedWriter) {
        // Note you only need to close the outer wrapper as the underlying streams are closed when you close the wrapper.
        // Note you want to close the outermost wrapper so that everything gets flushed.
        // Note that closing a socket will also close the socket's InputStream and OutputStream.
        // Closing the input stream closes the socket. You need to use shutdownInput() on socket to just close the input stream.
        // Closing the socket will also close the socket's input stream and output stream.
        // Close the socket after closing the streams.

        // If the client disconnects for any reason remove them from the list so their not interacted with in world
        removeClientHandler();
        try {
            if (bufferedReader != null) {
                bufferedReader.close();
            }
            if (bufferedWriter != null) {
                bufferedWriter.close();
            }
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void sendServerConfig(BufferedWriter bufferedWriter){
        ServerConfig serverConfig = de.wethinkco.robotworlds.MainServer.getConfig();
        String serverConfigJson = jsonHelper.ServerConfigToJson(serverConfig);

        try {
            this.bufferedWriter.write(serverConfigJson);
            this.bufferedWriter.newLine();
            this.bufferedWriter.flush();
        } catch (IOException e) {
            closeEverything(socket, bufferedReader, bufferedWriter);
        }
    }

    @Override
    public String toString() {
        return "ClientHandler{" +
                "clientUsername='" + clientUsername + '\'' +
                ", robots=" + world.getRobots() +
                '}';
    }
}