def quote(args):
    return args