def cdr(args):
    if(lst, list):
        if (len(lst) == 0):
            return lst
        else:
            return lst[0]
    
