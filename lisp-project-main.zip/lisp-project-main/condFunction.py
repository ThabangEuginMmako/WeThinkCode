def cond(args):
    for arg in args:
        if arg[0] == "t":
            return arg[1]
    return []