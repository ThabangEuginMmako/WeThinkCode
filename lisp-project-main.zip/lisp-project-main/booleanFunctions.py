def equals(args):
    if(args[0] == args[1]):
        return "t"
    return []

def atom(args):
    if(type(args) != list or len(args) == 0):
        return "t"
    return []