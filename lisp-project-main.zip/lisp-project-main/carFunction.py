def car(args):
    if(len(args)==0):
        return args
    if(type(args) != list):
        raise
    return args[0]