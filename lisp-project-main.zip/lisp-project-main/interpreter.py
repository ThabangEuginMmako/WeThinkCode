from evaluator import evaluate

def tokenizer(string):
    return [ x for x in (string.replace("("," ( ")\
        .replace(")"," ) ")\
            .replace("'", " ' ").split(" ")) if x!=""]


def listWrapper(token):
    return listBuilder(token)[0]
    
def listBuilder(token):
    instruction = []
    while token:
        t = token.pop(0)
        if t == "(":
            closeIndex = findClosingBracket(token)
            subToken = token[:closeIndex]
            token = token[closeIndex:]
            instruction.append(listBuilder(subToken))
        elif t == "'":
            if(token[0]) == "(":
                closeIndex = findClosingBracket(token)
                subToken = token[:closeIndex]
                token = token[closeIndex:]
                subToken = listBuilder(subToken)
                instruction.append(subToken)
            else:
                instruction.append(token.pop(0))
        elif t != ")":
            if t.isnumeric():
                instruction.append(int(t))
            else:
                instruction.append(t)
        

    return instruction

def findClosingBracket(token):
    numOpen = 1
    for ind,char in enumerate(token):
        if(char == "("):
            numOpen+=1
        if(char == ")"):
            numOpen-=1
        if(numOpen == 0):
            return ind



    

if __name__ == "__main__":
    print(listWrapper(tokenizer("(cond ( (eq 'a 'b) 'first) ( 't 'last))")))
    print(evaluate(listWrapper(tokenizer("(cond ( (eq 'a 'b) 'first) ( 't 'last))"))))