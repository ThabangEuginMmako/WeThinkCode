from quoteFunction import *
from cdrFunction import *
from  carFunction import *
from mathsFunctions import *
from booleanFunctions import *
from consFunction import *
from condFunction import *
def evaluate(sExpression):
    if(type(sExpression) != list or len(sExpression) == 0):
        return sExpression
    if(sExpression[0] == "car"):
        return car(evaluate(sExpression[1]))
    elif(sExpression[0] == "'"):
        return quote(evaluate(sExpression[1]))
    elif(sExpression[0] == "cdr"):
        return cdr(evaluate(sExpression[1]))
    elif(sExpression[0] == "atom"):
        return atom(evaluate(sExpression[1]))
    elif(sExpression[0] == "cons"):
        subExpression = [ evaluate(exp) for exp in sExpression[1:]]
        return cons(evaluate(subExpression))
    elif(sExpression[0] == "/"):
        subExpression = [ evaluate(exp) for exp in sExpression[1:]]
        return division(evaluate(subExpression))
    elif(sExpression[0] == "eq"):
        subExpression = [ evaluate(exp) for exp in sExpression[1:]]
        return equals(evaluate(subExpression))
    elif(sExpression[0] == "*"):
        subExpression = [ evaluate(exp) for exp in sExpression[1:]]
        return multiplication(evaluate(subExpression))
    elif(sExpression[0] == "+"):
        subExpression = [ evaluate(exp) for exp in sExpression[1:]]
        return addition(evaluate(subExpression))
    elif(sExpression[0] == "-"):
        subExpression = [ evaluate(exp) for exp in sExpression[1:]]
        return subtraction(evaluate(subExpression))
    elif(sExpression[0] == "cond"):
        predExp = sExpression[1:]
        subExpression = [ [evaluate(predexp[0]),evaluate(predexp[1])] for predexp in sExpression[1:]]
        return cond(evaluate(subExpression))
    else:
        return sExpression