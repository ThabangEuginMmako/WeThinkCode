def addition(args):
    return args[0] + args[1]

def subtraction(args):
    return abs(args[0] - args[1])

def division(args):
    return int((args[0]/args[1]))

def multiplication(args):
    return args[0]*args[1]