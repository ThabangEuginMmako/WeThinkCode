def cons(args):
    args[1].insert(0,args[0])
    return args[1]