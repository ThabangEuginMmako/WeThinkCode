INSERT INTO Genres(code, description)
    VALUES ("SCIFI", "Science Fiction");

INSERT INTO Genres(code, description)
    VALUES ("BIO", "Biography");
     
INSERT INTO Genres(code, description)
    VALUES ("PROG", "Programming");
