SELECT * FROM Genres
WHERE description LIKE "%io%";