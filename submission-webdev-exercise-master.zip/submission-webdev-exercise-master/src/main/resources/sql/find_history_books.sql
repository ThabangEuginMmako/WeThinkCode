SELECT COUNT(*)
FROM Books
WHERE Genre_code = "Them"