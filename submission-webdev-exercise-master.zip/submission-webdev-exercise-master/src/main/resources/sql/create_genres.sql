CREATE TABLE Genres (
    "code" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    PRIMARY KEY("code")
)