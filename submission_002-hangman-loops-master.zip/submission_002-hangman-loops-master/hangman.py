import random


def read_file(file_name):
    file = open(file_name,'r')
    return file.readlines()


def get_user_input():
    return input('Guess the missing letter: ')


def ask_file_name():
    file_name = input("Words file? [leave empty to use short_words.txt] : ")
    if not file_name:
        return 'short_words.txt'
    return file_name


def select_random_word(words):
    random_index = random.randint(0, len(words)-1)
    word = words[random_index].strip()
    return word


# TODO: Step 1 - update to randomly fill in one character of the word only
def random_fill_word(word):

    ''' 
    The purpose of this function is to randomly fill one letter in the word the user supposed to guess from the original word and 
    replace the rest of the letters with underscores 
    '''

    random_index = random.randint(0, len(word) - 1)
    hidden_word = "_"*len(word)
    letter = word[random_index]

    hidden_word = list(hidden_word)
    hidden_word[random_index] = letter
    new_word=""
    for i in range (len(hidden_word)):
        new_word = new_word + hidden_word[i]

    return new_word

# TODO: Step 1 - update to check if character is one of the missing characters
def is_missing_char(original_word, answer_word, char):
    
    '''
    The purpose of this function is to check whether the letter inserted by the user from the answer word is one of the missing 
    letters in the original word 
    '''

    if char in original_word and char not in answer_word:
        return True
    else:
        return False


# TODO: Step 1 - fill in missing char in word and return new more complete word
def fill_in_char(original_word, answer_word, char):
    
    '''
    The purpose of this function is to fill in missing letters in the new word by iterating through the new word one letter at a
    time
    '''
    original_list = list(original_word)
    answer_list = list(answer_word)
    new_word =""

    for i in range(len(original_list)):
        if original_list[i] == char:
            answer_list[i] = char
    for x in range(len(answer_list)):
        new_word = new_word + answer_list[x]
    return new_word

def do_correct_answer(original_word, answer, guess):

    '''
    The purpose of this function is to check whether the guessed letter is in both the original word and the guessed word
    '''
    
    answer = fill_in_char(original_word, answer, guess)
    print(answer)
    return answer


# TODO: Step 4: update to use number of remaining guesses
def do_wrong_answer(answer, number_guesses):
    
    '''
    The purpose of this function is to prompt the user about the number of guesses they have remaining and also to call the
    draw figure function and print the figure according to remaining guesses the user still has
    '''
    
    print('Wrong! Number of guesses left: '+str(number_guesses))
    draw_figure(number_guesses)

# TODO: Step 5: draw hangman stick figure, based on number of guesses remaining
def draw_figure(number_guesses):

    '''
    The purpose of this function is to print the stages of the hangman character in accordance to the number of guesses the user
    still has remaining
    '''

    if number_guesses == 4:
        print("/----\n|\n|\n|\n|\n_______")
    elif number_guesses == 3:
        print("/----\n|   0\n|\n|\n|\n_______")
    elif number_guesses == 2:
        print("/----\n|   0\n|  /|\\\n|\n|\n_______")
    elif number_guesses == 1:
        print("/----\n|   0\n|  /|\\\n|   |\n|\n_______")
    elif number_guesses == 0:
        print("/----\n|   0\n|  /|\\\n|   |\n|  / \\\n_______")


# TODO: Step 2 - update to loop over getting input and checking until whole word guessed
# TODO: Step 3 - update loop to exit game if user types `exit` or `quit`
# TODO: Step 4 - keep track of number of remaining guesses
def run_game_loop(word, answer):

    '''
    The purpose of this function is to get the user input whether the user want to quit or exit and to also check the user input
    until the whole word is guessed correctly and to also keep track of remaining guesses the user still has
    '''

    num = 5
    print("Guess the word: "+str(answer))
    while num >= 0:
        guess = get_user_input()
        if guess.lower() == "exit" or guess.lower() == "quit":
            print("Bye!")
            break
        if is_missing_char(word, answer, guess):
            answer = do_correct_answer(word, answer, guess)
        elif num > 1:
            num-=1
            do_wrong_answer(answer, num)
        else:
            do_wrong_answer(answer, 0)
            print("Sorry, you are out of guesses. The word was: "+word)
            break
        if word == answer:
            break


# TODO: Step 6 - update to get words_file to use from commandline argument
if __name__ == "__main__":
    
    '''
    This piece of code will load the short_list.txt file to read from unless the user specifies they want the program to read from
    another file called my_words.txt from the command line as a sys.argv argument.
    And this is were all the rest of the functions of the program are called.
    '''
    words_file = ask_file_name()
    words = read_file(words_file)
    selected_word = select_random_word(words)
    current_answer = random_fill_word(selected_word)

    run_game_loop(selected_word, current_answer)
