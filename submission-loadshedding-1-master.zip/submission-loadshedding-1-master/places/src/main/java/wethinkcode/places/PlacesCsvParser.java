package wethinkcode.places;

import java.io.*;
import java.util.*;

import com.google.common.annotations.VisibleForTesting;
import wethinkcode.places.db.memory.PlacesDb;
import wethinkcode.places.model.Places;
import wethinkcode.places.model.Town;


/**
 * PlacesCsvParser : I parse a CSV file with each line containing the fields (in order):
 * <code>Name, Feature_Description, pklid, Latitude, Longitude, Date, MapInfo, Province,
 * fklFeatureSubTypeID, Previous_Name, fklMagisterialDistrictID, ProvinceID, fklLanguageID,
 * fklDisteral, Local Municipality, Sound, District Municipality, fklLocalMunic, Comments, Meaning</code>.
 * <p>
 * For the PlaceNameService we're only really interested in the <code>Name</code>,
 * <code>Feature_Description</code> and <code>Province</code> fields.
 * <code>Feature_Description</code> allows us to distinguish towns and urban areas from
 * (e.g.) rivers, mountains, etc. since our PlaceNameService is only concerned with occupied places.
 */
public class PlacesCsvParser {

    private List<List<String>> records = new ArrayList<>();

    private Set<Town> TOWNS = new HashSet<>();

    private List<String> exampleTypes = new ArrayList<>() {{
        add("Urban Area");
        add("Town");
    }};


    /**
     * "Given a file, open it, read it line by line, and parse each line."
     *
     * The first line of the function is a declaration of the function's return type, which is a `Places` object. The next
     * line is the function's name, `parseCsvSource`, and the parameter list, which is a single parameter of type `File`
     * named `csvFile`. The next line is the function's body, which is a single statement. The statement is a call to the
     * `parseDataLines` function, which is defined in the same class. The `parseDataLines` function takes a single
     * parameter of type `LineNumberReader`, which is a Java class that reads a file line by line. The `parseDataLines`
     * function returns a `Places` object
     *
     * @param csvFile The file to be parsed.
     * @return A Places object.
     */
    public Places parseCsvSource( File csvFile ) throws FileNotFoundException {

        FileReader fileReader = new FileReader(csvFile);
        LineNumberReader lineNumberReader = new LineNumberReader(fileReader);
        return parseDataLines(lineNumberReader);
    }

    /**
     * It takes a string of comma separated values, splits it into lines, and then splits each line into a list of strings
     *
     * @param line The string to be split.
     * @return A list of lists of strings.
     */
    public List<List<String>> firstLineSkipped(String line) {
        List<List<String>> records = new ArrayList<>();
        String[] lines = line.split("\n");
        for (String l: lines) {
            if (!(l.startsWith("Name"))) {
                records.add(List.of(l.split(",")));
            }
        }
        return records;
    }

    /**
     * "Given a line of text, return a list of towns that are of the given type."
     *
     * The first thing we do is split the line into a list of records. We then create a list of towns to return. We then
     * iterate over the records, and if the record is of the given type, we add it to the list of towns
     *
     * @param line the line of the file that you want to read
     * @param type The type of place you want to find.
     * @return A list of towns.
     */
    public List<Town> findPlaces(String line, String type) {
        List<List<String>> records = firstLineSkipped(line);
        List<Town> Places = new ArrayList<>();
        if (type.equalsIgnoreCase("Town") ||
                (type.equalsIgnoreCase("Urban Area"))) {
            for (List<String> record: records) {
                if (record.get(1).equalsIgnoreCase(type)) {
                    Places.add(new Town(record.get(0), record.get(7)));
                }
            }
        }
        return Places;
    }

    @VisibleForTesting
    // Reading the file line by line and splitting the line into a list of records.
    Places parseDataLines( final LineNumberReader in ) {
        try {
            String line;
            while ((line= in.readLine())!=null) {
                String[] lines = line.split("\n");
                for (String l: lines) {
                    if (!(l.startsWith("Name"))) {
                        records.add(List.of(l.split(",")));
                    }
                }
            }
        } catch (IOException exception) {
            exception.printStackTrace();
        }

        for (List<String> record : records) {
            if (record.size() < 3) {
            }else if (exampleTypes.contains(record.get(1))) {
                Town town = new Town(record.get(0), record.get(7));
                TOWNS.add(town);
            }
        }
        return new PlacesDb(TOWNS);
    }
}

