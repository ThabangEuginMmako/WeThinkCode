package wethinkcode.places.db.memory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;
import wethinkcode.places.model.Places;
import wethinkcode.places.model.Town;

/**
 * TODO: javadoc PlacesDb
 */
public class PlacesDb implements Places {

    private Set<Town> TOWNS;

    public PlacesDb(Set<Town> towns) {
        TOWNS = towns;
    }

    @Override
    public Collection<String> provinces(){
        Collection<String> provinces = new ArrayList<>();
        for (Town town: TOWNS) {
            if (!provinces.contains(town.getProvince())) {
                provinces.add(town.getProvince());
            }
        }
        return provinces;
    }

    @Override
    public Collection<Town> townsIn( String aProvince ){
        Collection<Town> townsIn = new ArrayList<>();
        for (Town town:TOWNS) {
            if (town.getProvince().equalsIgnoreCase(aProvince)) {
                townsIn.add(town);
            }
        }
        return townsIn;
    }

    @Override
    public int size(){
        return TOWNS.size();
    }



}