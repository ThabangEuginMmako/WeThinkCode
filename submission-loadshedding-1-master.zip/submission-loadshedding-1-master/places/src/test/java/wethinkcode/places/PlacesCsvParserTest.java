package wethinkcode.places;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import wethinkcode.places.db.memory.PlacesDb;
import wethinkcode.places.model.Places;

import java.io.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit-test suite for the CSV parser.
 */
public class PlacesCsvParserTest
{
    private LineNumberReader input;

    private PlacesCsvParser parser;

    private Places places;

    @BeforeEach
    public void setUp(){
        input = new LineNumberReader( new StringReader( PlacesTestData.CSV_DATA ));
        parser = new PlacesCsvParser();
    }

    @AfterEach
    public void tearDown(){
        places = null;
        parser = null;
        input = null;
    }

    @Test
    // This method is testing the firstLineSkipped method in the PlacesCsvParser class.
    public void firstLineGetsSkipped() throws IOException {
        final String testLine = """
        Name,Feature_Description,pklid,Latitude,Longitude,Date,MapInfo,Province,fklFeatureSubTypeID,Previous_Name,fklMagisterialDistrictID,ProvinceID,fklLanguageID,fklDisteral,Local Municipality,Sound,District Municipality,fklLocalMunic,Comments,Meaning
        Amatikulu,Station,95756,-29.05111111,31.53138889,31-05-1989,,KwaZulu-Natal,79,,237,4,16,DC28,uMlalazi,,,KZ284,,
        Amatikulu,Town,95757,-29.04666667,31.52805556,31-05-1989,,KwaZulu-Natal,111,,237,4,16,DC28,uMlalazi,,,KZ284,,
        """;
        assertEquals(2, parser.firstLineSkipped(testLine).size());
        assertFalse(parser.firstLineSkipped(testLine).get(0).contains("Name"));
        assertFalse(parser.firstLineSkipped(testLine).get(0).contains("Feature_Description"));
        assertFalse(parser.firstLineSkipped(testLine).get(0).contains("pklid"));
        assertFalse(parser.firstLineSkipped(testLine).get(0).contains("Latitude"));
        assertFalse(parser.firstLineSkipped(testLine).get(0).contains("Date"));
        assertFalse(parser.firstLineSkipped(testLine).get(0).contains("MapInfo"));
        assertFalse(parser.firstLineSkipped(testLine).get(0).contains("Province"));
        assertFalse(parser.firstLineSkipped(testLine).get(0).contains("fklFeatureSubTypeID"));

    }

    @Test
    // This method is testing the splitLineIntoValues method in the PlacesCsvParser class.
    public void splitLineIntoValuesProducesCorrectNoOfValues(){
        final String testLine = "Brakpan,Non_Perennial,92797,-26.60444444,26.34,01-06-1992,,North West,66,,262,8,16,DC40,Matlosana,,,NW403,,";
        assertEquals(1, parser.firstLineSkipped(testLine).size());
        assertEquals(18, parser.firstLineSkipped(testLine).get(0).size());
        assertEquals("Brakpan", parser.firstLineSkipped(testLine).get(0).get(0));
        assertEquals("Non_Perennial", parser.firstLineSkipped(testLine).get(0).get(1));
        assertEquals("NW403", parser.firstLineSkipped(testLine).get(0).get(17));

    }

    @Test
    // Testing the urbanPlacesAreWanted method in the PlacesCsvParser class.
    public void urbanPlacesAreWanted(){
        final String testLine = "Brakpan,Urban Area,92799,-26.23527778,28.37,31-05-1995,,Gauteng,114,,280,3,16,EKU,Ekurhuleni Metro,,,EKU,,\n";
        String type = "Urban Area";
        assertEquals(1, parser.findPlaces(testLine, type).size());
        assertEquals("Brakpan", parser.findPlaces(testLine,type).get(0).getName());
        assertEquals("Gauteng", parser.findPlaces(testLine, type).get(0).getProvince());
    }

    @Test
    // Testing the townsAreWanted method in the PlacesCsvParser class.
    public void townsAreWanted(){
        final String testLine = "Brakpan,Town,92802,-27.95111111,26.53333333,30-05-1975,,Free State,68,,155,2,16,DC18,Matjhabeng,,,FS184,,";
        String type = "Town";
        assertEquals(1, parser.findPlaces(testLine, type).size());
        assertEquals("Brakpan", parser.findPlaces(testLine,type).get(0).getName());
        assertEquals("Free State", parser.findPlaces(testLine, type).get(0).getProvince());

    }

    @Test
    // This method is testing the findPlaces method in the PlacesCsvParser class.
    public void otherFeaturesAreNotWanted(){
        final String testLine = "Amatikulu,Station,95756,-29.05111111,31.53138889,31-05-1989,,KwaZulu-Natal,79,,237,4,16,DC28,uMlalazi,,,KZ284,,";
        String type = "Station";
        assertEquals(0, parser.findPlaces(testLine, type).size());
        assertTrue(parser.findPlaces(testLine, type).isEmpty());
    }

    @Test
    // This method is testing the parseDataLines method in the PlacesCsvParser class.
    public void parseBulkTestData(){
        final Places db = parser.parseDataLines( input );
        assertEquals( 5, db.size() );
    }

    @Test
    public void dataFileDoesNotExist() {
        assertThrows(FileNotFoundException.class, () -> {
            parser.parseCsvSource(new File("/path/to/file.csv"));
        });
    }


    @Test
    public void dataFileFound() {
        assertTrue(new File(System.getProperty("user.dir")+"/resources/PlaceNamesZA2008.csv")
                .isFile());
        assertTrue(new File(System.getProperty("user.dir")+"/resources/PlaceNamesZA2008.csv")
                .exists());
        try {
            assertEquals(PlacesDb.class, parser.parseCsvSource(new File(System.getProperty("user.dir")+"/resources/PlaceNamesZA2008.csv")).getClass());
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void dataFileIncompleteOrBroken() throws FileNotFoundException {
        File file = new File(System.getProperty("user.dir")+"/resources/brokeninfo.csv");
        assertTrue(file.exists());
        places = parser.parseCsvSource(file);
        assertEquals(2, places.size());
    }


    @Test
    public void dataIsOK() throws FileNotFoundException {
        File file = new File(System.getProperty("user.dir")+"/resources/okdata.csv");
        assertTrue(file.exists());
        places = parser.parseCsvSource(file);
        assertEquals(11, places.size());
    }
}
