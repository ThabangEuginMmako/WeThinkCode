package wethinkcode.places.db.memory;

import java.util.Set;

import org.junit.jupiter.api.*;
import wethinkcode.places.model.Town;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;


/**
 * Uncomment the body of the test methods. They can't compile until you add appropriate code
 * to the PlacesDb class. Once you make them compile, the tests should fail at first. Now
 * make the tests green.
 */
public class PlacesDbTest
{
    public static final Set<Town> TOWNS = Set.of(
        new Town( "Cape Town", "Western Cape" ),
        new Town( "Worcester", "Western Cape" ),
        new Town( "Riversdale", "Western Cape" ),
        new Town( "Gqeberha", "Eastern Cape" ),
        new Town( "Queenstown", "Eastern Cape" ),
        new Town( "Sandton-East", "Gauteng" ),
        new Town( "Riversdale", "Gauteng" ),
        new Town( "Mabopane", "Gauteng" ),
        new Town( "Brakpan", "Gauteng" )
    );

    @Test
    public void testProvinces(){
        final PlacesDb db = new PlacesDb( TOWNS );
        assertEquals(db.provinces().size(), 3);
        assertEquals(3, db.provinces().size());

    }

    @Test
    public void testTownsInProvince() {
        final PlacesDb db = new PlacesDb(TOWNS);
        assertEquals(4, db.townsIn("Gauteng").size());
        assertEquals(2, db.townsIn("Eastern Cape").size());
        assertEquals(3, db.townsIn("Western Cape").size());
        assertEquals(0, db.townsIn("Northern Cape").size());
        assertTrue(db.townsIn( "Northern Cape" ).isEmpty());
    }
}
