package wethinkcode.places;

import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import kong.unirest.Unirest;
import org.junit.jupiter.api.*;
import picocli.CommandLine;

import static org.junit.jupiter.api.Assertions.*;

/**
 * *Functional* tests of the PlaceNameService.
 */
public class PlaceNameApiTest
{
    public static final int TEST_PORT = 7777;

    private static PlaceNameService server = new PlaceNameService();




    @BeforeAll
    public static void startServer(){
        String cvsDataFile = System.getProperty("user.dir")+"/resources/PlaceNamesZA2008.csv";
        String[] args = new String[] {"-s", String.valueOf(TEST_PORT), "-f", cvsDataFile};
        new CommandLine(server).parseArgs(args);
        server.initialise();
        server.start();
    }

    @AfterAll
    public static void stopServer(){
        server.stop();
    }

    @Test
    public void getProvincesJson(){
        HttpResponse<JsonNode> response = Unirest.get(serverUrl()+"/provinces").asJson();
        assertTrue(response.isSuccess());
        assertTrue(response.getBody().isArray());

    }

    @Test
    public void getTownsInAProvince_provinceExistsInDb(){
        HttpResponse<JsonNode> response = Unirest.get( serverUrl() + "/towns/KwaZulu-Natal" ).asJson();
        assertTrue(response.isSuccess());
        assertTrue(response.getBody().isArray());

    }

    @Test
    public void getTownsInAProvince_noSuchProvinceInDb(){
        HttpResponse<JsonNode> response = Unirest.get( serverUrl() + "/towns/Oregon" ).asJson();
        assertTrue(response.isSuccess());
        assertTrue(response.getBody().isArray());
        assertTrue(response.getBody().getArray().isEmpty());

    }

    private String serverUrl(){
        return "http://localhost:" + TEST_PORT;
    }
}
