import random

def code_generator(): 
    """This function generates the random code."""
    
    global code
    code = [0,0,0,0]

    for i in range(4):
        value = random.randint(1, 8) 
        while value in code:
            value = random.randint(1, 8)  
        code[i] = value 
    return code   


def code_check(answer): 
    """Compares the user input to the code and calculates the output to 
       present to the user."""
    correct = False
    turns = 0
    while not correct and turns < 12:
        answer=input("Input 4 digit code: ")
        if len(answer) < 4 or len(answer) > 4:
            print("Please enter exactly 4 digits.")
            continue

        correct_digits_and_position = 0
        correct_digits_only = 0

        for i in range(len(answer)): 
                if code[i] == int(answer[i]):
                    correct_digits_and_position += 1
                elif int(answer[i]) in code:
                    correct_digits_only += 1 
        #correct_digits_and_position, correct_digits_only = code_check(answer)
        print('Number of correct digits in correct place:     '+str(correct_digits_and_position))
        print('Number of correct digits not in correct place: '+str(correct_digits_only))
        turns += 1

        if correct_digits_and_position == 4:
            correct = True
            print('Congratulations! You are a codebreaker!')
        else:
            print('Turns left: '+str(12 - turns))
        #return correct_digits_and_position, correct_digits_only


def display_code():
    """Displays the random code generated to the user at the end of the game."""
    print('The code was: ' + str(code))


# TODO: Decompose into functions

def run_game():
    """This function executes the function calls and outputs"""
    code = code_generator()
    print('4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.')
    code_check(code)
    display_code()
    

if __name__ == "__main__":
    run_game()
