package za.co.wethinkcode.toyrobot;

public enum Direction {NORTH}