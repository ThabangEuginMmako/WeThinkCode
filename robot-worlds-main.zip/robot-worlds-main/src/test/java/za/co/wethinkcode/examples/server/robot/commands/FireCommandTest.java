package za.co.wethinkcode.examples.server.robot.commands;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;


import org.junit.Test;

public class FireCommandTest {
    
    @Test
    public void testConstructor() {
        FireCommand actualFireCommand = new FireCommand();
        assertEquals("", actualFireCommand.getArgument());
        assertFalse(actualFireCommand.miss);
        assertFalse(actualFireCommand.hit);
        assertEquals("fire", actualFireCommand.getCommandName());
    }

}

