package za.co.wethinkcode.examples.server.robot.commands;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class LaunchCommandTest {
    
    @Test
    public void testConstructor() {
        LaunchCommand actualLaunchCommand = new LaunchCommand();
        assertEquals("", actualLaunchCommand.getArgument());
        assertEquals("launch", actualLaunchCommand.getCommandName());
    }

}

