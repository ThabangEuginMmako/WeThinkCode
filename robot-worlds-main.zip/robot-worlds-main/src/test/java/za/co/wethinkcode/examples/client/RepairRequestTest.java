package za.co.wethinkcode.examples.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import org.json.JSONObject;
import org.junit.Test;

public class RepairRequestTest {
    
    @Test
    public void testConstructor() {
        RepairRequest actualRepairRequest = new RepairRequest("Name");
        JSONObject expectedRequest = actualRepairRequest.request;
        JSONObject request = actualRepairRequest.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }
}

