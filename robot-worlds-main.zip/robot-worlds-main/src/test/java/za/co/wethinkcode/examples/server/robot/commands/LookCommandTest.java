package za.co.wethinkcode.examples.server.robot.commands;

import static org.junit.Assert.assertEquals;


import org.junit.Test;

public class LookCommandTest {
    
    @Test
    public void testConstructor() {
        LookCommand actualLookCommand = new LookCommand();
        assertEquals("", actualLookCommand.getArgument());
        assertEquals("look", actualLookCommand.getCommandName());
    }

}

