package za.co.wethinkcode.examples.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import org.json.JSONObject;
import org.junit.Test;

public class LaunchRequestTest {
    
    @Test
    public void testConstructor() {
        LaunchRequest actualLaunchRequest = new LaunchRequest("Robot", "Kind");

        JSONObject expectedRequest = actualLaunchRequest.request;
        JSONObject request = actualLaunchRequest.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }

    
    @Test
    public void testConstructor3() {
        LaunchRequest actualLaunchRequest = new LaunchRequest("Robot", "42");

        JSONObject expectedRequest = actualLaunchRequest.request;
        JSONObject request = actualLaunchRequest.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }
}

