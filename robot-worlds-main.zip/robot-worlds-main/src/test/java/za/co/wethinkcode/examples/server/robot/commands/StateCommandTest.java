package za.co.wethinkcode.examples.server.robot.commands;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class StateCommandTest {
    
    @Test
    public void testConstructor() {
        StateCommand actualStateCommand = new StateCommand();
        assertEquals("", actualStateCommand.getArgument());
        assertEquals("state", actualStateCommand.getCommandName());
    }

}

