package za.co.wethinkcode.examples.server.robot.commands;

import static org.junit.Assert.assertEquals;


import org.junit.Test;

public class ForwardCommandTest {
    
    @Test
    public void testConstructor() {
        ForwardCommand actualForwardCommand = new ForwardCommand("Argument");
        assertEquals("Argument", actualForwardCommand.getArgument());
        assertEquals("forward", actualForwardCommand.getCommandName());
    }
}

