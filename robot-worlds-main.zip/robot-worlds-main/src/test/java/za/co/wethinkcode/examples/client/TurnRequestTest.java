package za.co.wethinkcode.examples.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import org.json.JSONObject;
import org.junit.Test;

public class TurnRequestTest {
    
    @Test
    public void testConstructor() {
        TurnRequest actualTurnRequest = new TurnRequest("Name", true);

        JSONObject expectedRequest = actualTurnRequest.request;
        JSONObject request = actualTurnRequest.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }

    
    @Test
    public void testConstructor2() {
        TurnRequest actualTurnRequest = new TurnRequest("Name", false);

        JSONObject expectedRequest = actualTurnRequest.request;
        JSONObject request = actualTurnRequest.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }
}

