package za.co.wethinkcode.examples.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import org.json.JSONObject;
import org.junit.Test;

public class ReloadRequestTest {
    
    @Test
    public void testConstructor() {
        ReloadRequest actualReloadRequest = new ReloadRequest("Name");
        JSONObject expectedRequest = actualReloadRequest.request;
        JSONObject request = actualReloadRequest.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }
}

