package za.co.wethinkcode.examples.server.robot.commands;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TurnCommandTest {
    
    @Test
    public void testConstructor() {
        TurnCommand actualTurnCommand = new TurnCommand("Argument");
        assertEquals("Argument", actualTurnCommand.getArgument());
        assertEquals("turn", actualTurnCommand.getCommandName());
    }
}

