package za.co.wethinkcode.examples.server.robot.commands;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class HelpCommandTest {
    
    @Test
    public void testConstructor() {
        HelpCommand actualHelpCommand = new HelpCommand();
        assertEquals("", actualHelpCommand.getArgument());
        assertEquals("help", actualHelpCommand.getCommandName());
    }

    
}

