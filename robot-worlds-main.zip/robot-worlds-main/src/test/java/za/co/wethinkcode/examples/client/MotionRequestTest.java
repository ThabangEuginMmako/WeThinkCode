package za.co.wethinkcode.examples.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import org.json.JSONObject;
import org.junit.Test;

public class MotionRequestTest {
    
    @Test
    public void testConstructor() {
        MotionRequest actualMotionRequest = new MotionRequest("Name", true, "Steps");

        JSONObject expectedRequest = actualMotionRequest.request;
        JSONObject request = actualMotionRequest.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }

    
    @Test
    public void testConstructor2() {
        MotionRequest actualMotionRequest = new MotionRequest("Name", false, "Steps");

        JSONObject expectedRequest = actualMotionRequest.request;
        JSONObject request = actualMotionRequest.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }

    
    @Test
    public void testConstructor4() {
        MotionRequest actualMotionRequest = new MotionRequest("Name", true, "42");

        JSONObject expectedRequest = actualMotionRequest.request;
        JSONObject request = actualMotionRequest.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }
}

