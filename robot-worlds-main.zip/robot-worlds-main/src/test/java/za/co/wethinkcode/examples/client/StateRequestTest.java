package za.co.wethinkcode.examples.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import org.json.JSONObject;
import org.junit.Test;

public class StateRequestTest {
    
    @Test
    public void testConstructor() {
        StateRequest actualStateRequest = new StateRequest("Name");
        JSONObject expectedRequest = actualStateRequest.request;
        JSONObject request = actualStateRequest.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }
}

