package za.co.wethinkcode.examples.server.world;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;
import za.co.wethinkcode.examples.server.robot.Position;
import za.co.wethinkcode.examples.server.robot.Robot;
import za.co.wethinkcode.examples.server.world.maze.EmptyMaze;
import za.co.wethinkcode.examples.server.world.obstructions.Obstacle;

public class WorldTest {
    
    @Test
    public void testConstructor() {
        EmptyMaze emptyMaze = new EmptyMaze();
        World actualWorld = new World(emptyMaze);
        assertSame(emptyMaze, actualWorld.getMaze());
        List<Obstacle> obstacleList = actualWorld.obsList;
        List<Obstacle> obstacles = actualWorld.getObstacles();
        assertSame(obstacleList, obstacles);
        List<Robot> players = actualWorld.getPlayers();
        assertEquals(players, obstacles);
        assertEquals(obstacleList, players);
    }

    
    @Test
    public void testConstructor2() {
        EmptyMaze emptyMaze = new EmptyMaze();
        World actualWorld = new World(emptyMaze);
        assertSame(emptyMaze, actualWorld.getMaze());
        List<Obstacle> expectedPlayers = actualWorld.obsList;
        List<Robot> players = actualWorld.getPlayers();
        assertEquals(expectedPlayers, players);
        assertEquals(players, actualWorld.getObstacles());
        Position bOTTOM_RIGHT = actualWorld.getBOTTOM_RIGHT();
        assertEquals(100, bOTTOM_RIGHT.getX());
        assertEquals(-100, bOTTOM_RIGHT.getY());
        Position tOP_LEFT = actualWorld.getTOP_LEFT();
        assertEquals(-100, tOP_LEFT.getX());
        assertEquals(100, tOP_LEFT.getY());
    }

    

    
    @Test
    public void testIsNewPositionAllowed() {
        World world = new World(new EmptyMaze());
        assertTrue(world.isNewPositionAllowed(new Position(2, 3)));
    }

    
    @Test
    public void testIsNewPositionAllowed2() {
        World world = new World(new EmptyMaze());
        assertFalse(world.isNewPositionAllowed(new Position(Integer.MIN_VALUE, 3)));
    }

    
    @Test
    public void testIsNewPositionAllowed3() {
        World world = new World(new EmptyMaze());
        assertFalse(world.isNewPositionAllowed(new Position(2, Integer.MIN_VALUE)));
    }
}

