package za.co.wethinkcode.examples.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThrows;

import org.json.JSONObject;
import org.junit.Test;

public class RequestTest {
    
    @Test
    public void testCreate() {
        assertThrows(IllegalArgumentException.class, () -> Request.create("Instruction", "Name"));
        assertThrows(IllegalArgumentException.class, () -> Request.create("Unsupported command: ", "Name"));
    }

    
    @Test
    public void testCreate2() {
        Request actualCreateResult = Request.create("back", "Name");
        JSONObject expectedRequest = actualCreateResult.request;
        JSONObject request = actualCreateResult.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }

    
    @Test
    public void testCreate3() {
        Request actualCreateResult = Request.create("fire", "Name");
        JSONObject expectedRequest = actualCreateResult.request;
        JSONObject request = actualCreateResult.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }

    
    @Test
    public void testCreate4() {
        Request actualCreateResult = Request.create("forward", "Name");
        JSONObject expectedRequest = actualCreateResult.request;
        JSONObject request = actualCreateResult.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }

    
    @Test
    public void testCreate5() {
        Request actualCreateResult = Request.create("left", "Name");
        JSONObject expectedRequest = actualCreateResult.request;
        JSONObject request = actualCreateResult.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }

    
    @Test
    public void testCreate6() {
        Request actualCreateResult = Request.create("look", "Name");
        JSONObject expectedRequest = actualCreateResult.request;
        JSONObject request = actualCreateResult.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }

    
    @Test
    public void testCreate7() {
        Request actualCreateResult = Request.create("reload", "Name");
        JSONObject expectedRequest = actualCreateResult.request;
        JSONObject request = actualCreateResult.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }

    
    @Test
    public void testCreate8() {
        Request actualCreateResult = Request.create("repair", "Name");
        JSONObject expectedRequest = actualCreateResult.request;
        JSONObject request = actualCreateResult.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }

    
    @Test
    public void testCreate9() {
        Request actualCreateResult = Request.create("right", "Name");
        JSONObject expectedRequest = actualCreateResult.request;
        JSONObject request = actualCreateResult.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }

    
    @Test
    public void testCreate10() {
        Request actualCreateResult = Request.create("state", "Name");
        JSONObject expectedRequest = actualCreateResult.request;
        JSONObject request = actualCreateResult.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }
}

