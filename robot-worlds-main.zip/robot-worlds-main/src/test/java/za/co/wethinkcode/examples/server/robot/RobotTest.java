package za.co.wethinkcode.examples.server.robot;

import static org.junit.Assert.assertFalse;

import java.io.BufferedWriter;
import java.io.StringWriter;

import org.junit.Test;
import za.co.wethinkcode.examples.server.world.World;
import za.co.wethinkcode.examples.server.world.maze.EmptyMaze;

public class RobotTest {
    /**
     * Method under test: {@link Robot#blocksPath(Position, Position)}
     */
    @Test
    public void testBlocksPath() {
        BufferedWriter out = new BufferedWriter(new StringWriter());
        Alexander alexander = new Alexander("Name", out, new World(new EmptyMaze()));
        Position a = new Position(2, 3);

        assertFalse(alexander.blocksPath(a, new Position(2, 3)));
    }

    /**
     * Method under test: {@link Robot#blocksPath(Position, Position)}
     */
    @Test
    public void testBlocksPath2() {
        BufferedWriter out = new BufferedWriter(new StringWriter());
        Alexander alexander = new Alexander("42", out, new World(new EmptyMaze()));
        Position a = new Position(2, 3);

        assertFalse(alexander.blocksPath(a, new Position(2, 3)));
    }

    /**
     * Method under test: {@link Robot#blocksPath(Position, Position)}
     */
    @Test
    public void testBlocksPath3() {
        BufferedWriter out = new BufferedWriter(new StringWriter());
        Alexander alexander = new Alexander("", out, new World(new EmptyMaze()));
        Position a = new Position(2, 3);

        assertFalse(alexander.blocksPath(a, new Position(2, 3)));
    }

    /**
     * Method under test: {@link Robot#blocksPath(Position, Position)}
     */
    @Test
    public void testBlocksPath4() {
        BufferedWriter out = new BufferedWriter(new StringWriter());
        Alexander alexander = new Alexander("Name", out, new World(new EmptyMaze()));
        Position a = new Position(3, 3);

        assertFalse(alexander.blocksPath(a, new Position(2, 3)));
    }

    /**
     * Method under test: {@link Robot#blocksPath(Position, Position)}
     */
    @Test
    public void testBlocksPath5() {
        BufferedWriter out = new BufferedWriter(new StringWriter());
        Alexander alexander = new Alexander("Name", out, new World(new EmptyMaze()));
        Position a = new Position(1, 3);

        assertFalse(alexander.blocksPath(a, new Position(2, 3)));
    }

    /**
     * Method under test: {@link Robot#blocksPath(Position, Position)}
     */
    @Test
    public void testBlocksPath6() {
        BufferedWriter out = new BufferedWriter(new StringWriter());
        Alexander alexander = new Alexander("Name", out, new World(new EmptyMaze()));
        Position a = new Position(-1, 3);

        assertFalse(alexander.blocksPath(a, new Position(2, 3)));
    }
}

