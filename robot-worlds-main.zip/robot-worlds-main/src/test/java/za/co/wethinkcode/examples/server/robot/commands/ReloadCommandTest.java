package za.co.wethinkcode.examples.server.robot.commands;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.BufferedWriter;
import java.io.StringWriter;

import org.junit.Test;
import za.co.wethinkcode.examples.server.robot.Alexander;
import za.co.wethinkcode.examples.server.world.World;
import za.co.wethinkcode.examples.server.world.maze.EmptyMaze;

public class ReloadCommandTest {
    /**
     * Method under test: default or parameterless constructor of {@link ReloadCommand}
     */
    @Test
    public void testConstructor() {
        ReloadCommand actualReloadCommand = new ReloadCommand();
        assertEquals("", actualReloadCommand.getArgument());
        assertEquals("reload", actualReloadCommand.getCommandName());
    }

    /**
     * Method under test: {@link ReloadCommand#execute(za.co.wethinkcode.examples.server.robot.Robot)}
     */
    @Test
    public void testExecute() {
        ReloadCommand reloadCommand = new ReloadCommand();
        BufferedWriter out = new BufferedWriter(new StringWriter());
        Alexander alexander = new Alexander("Name", out, new World(new EmptyMaze()));

        assertTrue(reloadCommand.execute(alexander));
        assertEquals(5, alexander.getState().size());
        assertEquals(5, alexander.getData().size());
        assertEquals("OK", alexander.getResults());
        assertEquals(10, alexander.getShots());
        assertFalse(alexander.getEmptyGun());
    }
}

