package za.co.wethinkcode.examples.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

public class HelpRequestTest {
    
    @Test
    public void testConstructor() {
        JSONArray jsonArray = new JSONArray();
        HelpRequest actualHelpRequest = new HelpRequest("Name", "Command", jsonArray);

        JSONObject expectedRequest = actualHelpRequest.request;
        JSONObject request = actualHelpRequest.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
        assertTrue(jsonArray.toList().isEmpty());
    }
}

