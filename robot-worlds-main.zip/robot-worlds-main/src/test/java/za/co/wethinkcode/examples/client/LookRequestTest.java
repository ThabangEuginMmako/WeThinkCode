package za.co.wethinkcode.examples.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import org.json.JSONObject;
import org.junit.Test;

public class LookRequestTest {
    
    @Test
    public void testConstructor() {
        LookRequest actualLookRequest = new LookRequest("Name");
        JSONObject expectedRequest = actualLookRequest.request;
        JSONObject request = actualLookRequest.getRequest();
        assertSame(expectedRequest, request);
        assertEquals(3, request.length());
    }
}

