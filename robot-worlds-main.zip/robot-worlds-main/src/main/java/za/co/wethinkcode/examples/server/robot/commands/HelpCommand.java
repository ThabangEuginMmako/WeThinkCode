package za.co.wethinkcode.examples.server.robot.commands;

import za.co.wethinkcode.examples.server.robot.Robot;

public class HelpCommand extends Commands {
    public HelpCommand(){
        super("help");
    }

    @Override
    public boolean execute(Robot target){
        target.setResults("I can understand these commands:\n" +
                "LAUNCH  - Launch a robot into the world\n" +
                "STATE  - Ask the world for the state of the robot\n" +
                "LOOK  - Look around in the world\n" +
                "REPAIR  - Instruct the robot to repair its shields\n" +
                "RELOAD  - Instruct the robot to reload its weapons\n" +
                "FIRE  - Instruct the robot to fire its gun\n" +
                "OFF  - Shut down robot\n" +
                "HELP - provide information about commands\n" +
                "FORWARD - move forward by specified number of steps, e.g. 'FORWARD 10'" +
                "");
        return true;
    }
}