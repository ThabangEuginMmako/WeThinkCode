package za.co.wethinkcode.examples.server.world.maze;
import java.util.ArrayList;
import java.util.List;

import za.co.wethinkcode.examples.server.robot.Position;
import za.co.wethinkcode.examples.server.world.obstructions.Obstacle;
import za.co.wethinkcode.examples.server.world.obstructions.SquareObstacle;

public class GameMaze  implements Maze{

    String[] maze = {
        "###################    #################",
        "##                                    ##",
        "####   ##      ##     ########    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "##                                    ##",
        "####   ##########     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "##                                    ##",
        "####   ##      ##     ########    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "##                                    ##",
        "####   ##      #########    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "##                                    ##",
        "####   ##      ##     ########    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "                                        ",
        "       ##                     ##        ",
        "       ##                     ##        ",
        "                                        ",
        "##          ##       ###              ##",
        "####   ##########     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "##                                    ##",
        "####   ##      #########    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "##                                    ##",
        "####   ##      ##     ########    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "##                                    ##",
        "####   ##      #########    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "##                                    ##",
        "####   ##########     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "####   ##      ##     ##    ##    ##  ##",
        "## ##       ##       ###     ###      ##",
        "#################    ###################"

    };

    private List <Obstacle> newList = new  ArrayList<>();
    private Obstacle obs2 = new SquareObstacle(0, 0);

    public GameMaze(){
        int vert = maze.length;
        int hori = maze[0].length();
        char charAt;

        for (int y = 0; y < vert; y++){
            for (int x = 0; x < hori; x++){
                charAt = maze[y].charAt(x);
                if (Character.compare(charAt, '#') == 0){
                    this.newList.add(new SquareObstacle(x*5-100, y*5-200));
                }
            }
        }
        
    }

    @Override
    public List<Obstacle> getObstacles() {
        
        return this.newList;
    }

    @Override
    public boolean blocksPath(Position a, Position b) {
        Obstacle obs;

        for (int i = 0; i < this.newList.size(); i++){
            obs = this.newList.get(i);
            if (obs.blocksPath(a, b)){
                obs2 = obs;
                return true;
            }
        }

        return false;
    }

    @Override
    public Obstacle getObs2() {
        return obs2;
    }
    
}
