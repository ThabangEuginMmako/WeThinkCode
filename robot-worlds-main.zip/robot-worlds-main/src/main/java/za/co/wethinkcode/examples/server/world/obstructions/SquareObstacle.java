package za.co.wethinkcode.examples.server.world.obstructions;

import za.co.wethinkcode.examples.server.robot.Position;

public class SquareObstacle  implements Obstacle{
    private int newX;
    private int newY;

    Position BLOCK_BOTTOM_LEFT;
    Position BLOCK_TOP_RIGHT;

    public SquareObstacle (int newX, int newY){
        this.newX = newX;
        this.newY = newY;
        this.BLOCK_BOTTOM_LEFT = new Position(this.newX,this.newY);
        this.BLOCK_TOP_RIGHT = new Position(newX+4,newY+4);

    }

    @Override
    public int getBottomLeftX() {
        // TODO Auto-generated method stub
        return this.newX;
    }

    @Override
    public int getBottomLeftY(){
        // TODO Auto-generated method stub
        return this.newY;
    }

    @Override
    public int getSize() {
        // TODO Auto-generated method stub
        return 5;
    }

    @Override
    public boolean blocksPosition(Position position) {
        // TODO Auto-generated method stub

        boolean inLeft = BLOCK_BOTTOM_LEFT.getY() <= position.getY() && position.getY() <= BLOCK_TOP_RIGHT.getY() && position.getX() == BLOCK_BOTTOM_LEFT.getX();
        boolean inBottom = BLOCK_BOTTOM_LEFT.getX() <= position.getX() && position.getX()  <= BLOCK_TOP_RIGHT.getX() && position.getY() == BLOCK_BOTTOM_LEFT.getY();

        boolean inRight = BLOCK_BOTTOM_LEFT.getY() <= position.getY() && position.getY()  <= BLOCK_TOP_RIGHT.getY() && position.getX() == BLOCK_TOP_RIGHT.getX();
        boolean inTop = BLOCK_BOTTOM_LEFT.getX() <= position.getX() && position.getX()  <= BLOCK_TOP_RIGHT.getX() && position.getY() == BLOCK_TOP_RIGHT.getY();
        
        return inTop || inBottom || inLeft || inRight;
    }

    @Override
    public boolean blocksPath(Position a, Position b) {
        // TODO Auto-generated method stub

        if (a.getX() == b.getX()){
            for (int i = a.getY(); i <= b.getY(); i++){
                Position newPosition = new Position(a.getX(), i);
                if (blocksPosition(newPosition)){
                    return true;
                }

            }
        }else if (a.getY() == b.getY()){
            for (int i = a.getX(); i <= b.getX(); i++){
                Position newPosition = new Position(i, a.getY());
                if (blocksPosition(newPosition)){
                    return true;
                }

            }

        }        
        
        return false;
    }
    
}
