package za.co.wethinkcode.examples.server.robot.commands;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// import org.json.JSONObject;

import za.co.wethinkcode.examples.server.robot.Robot;
import za.co.wethinkcode.examples.server.world.obstructions.Obstacle;

public class LookCommand extends Commands {

    public LookCommand(){
        super("look");
    }

    @Override
    public boolean execute(Robot target) {
        // TODO Auto-generated method stub

        List<Obstacle> obj = new ArrayList<>();
        List<Robot> obj2 = new ArrayList<>();

        obj =  target.getWorld().lookObstacles(target);
        
        obj2 =  target.getWorld().lookRobots(target);

        for (Robot rob : obj2) {
            System.out.println(rob.getPosition().getX() +", "+ rob.getPosition().getY());
            
        }

        for (Obstacle obs : obj) {
            System.out.println(obs.getBottomLeftX() +", "+ obs.getBottomLeftY());
            
        }

        String results = "OK";
        Map<String, Object> data = new HashMap<>();
        Map<String, Object> state = new HashMap<>();

        data.put("message", "DONE");
        data.put("objects", obj);

        state.put("position", target.getPosition());
        state.put("direction", target.getCurDirection());
        state.put("shields", target.getShield());
        state.put("shots",  target.getShots());
        state.put("status", "NORMAL");
        
        target.setResults(results);
        target.setData(data);
        target.setState(state);

        return true;
    }
    
}
