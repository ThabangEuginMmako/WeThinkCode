package za.co.wethinkcode.examples.server.robot;

import java.io.BufferedWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

// import org.json.JSONObject;

import za.co.wethinkcode.examples.server.robot.commands.Commands;
import za.co.wethinkcode.examples.server.world.IWorld;
import za.co.wethinkcode.examples.server.world.World;

public abstract class Robot {
    private String name;
    private World world;
    private BufferedWriter out;

    // private JSONObject response;
    private String results;
    private Map<String, Object> data;
    private Map<String, Object> state;

    private Position position;

    private Direction tarDirection;

    private Direction curDirection;
    private boolean emptyGun = false;

    private int repairSpeed = 10000;
    private final int maxShield = 10;
    private int shield = 10;

    private int distance = 0;

    private int reloadSpeed = 10000;
    // private final int maxShots = 10;
    private final int maxNumberOfShots = 10;
    private int shots = 10;

    // private String status;

    Position BLOCK_BOTTOM_LEFT ;
    Position BLOCK_TOP_RIGHT;

    

    // private String result;

    public Robot(String name, BufferedWriter o, World w){
        this.name = name;
        this.world = w;
        this.out = o;


        this.position = getRandomStartPosition();
        this.BLOCK_BOTTOM_LEFT = new Position((position.getX()-2), (position.getY()-2));
        this.BLOCK_TOP_RIGHT  = new Position((position.getX()+2), (position.getY()+2));
        this.curDirection = Direction.NORTH;

        data = new HashMap<>();
        state = new HashMap<>();

        // state.put("position", position);
        // state.put("direction", curDirection);
        // state.put("shields", 10);
        // state.put("shots",  10);
        // state.put("status", "NORMAL");
    }
    
    public String getName() {
        return name;
    }

    public World getWorld() {
        return world;
    }
    
    public BufferedWriter getOut() {
        return out;
    }

    // public JSONObject getResponse() {
        // return response;
    // }

    // public void setResponse(JSONObject response) {
        // this.response = response;
    // }

    public String getResults() {
        return results;
    }

    public void setResults(String results) {
        this.results = results;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    public Map<String, Object> getState() {
        return state;
    }

    public void setState(Map<String, Object> state) {
        this.state = state;
    }

    public Position getPosition() {
        return position;
    }

    public Direction getCurDirection() {
        return curDirection;
    }

    public int getShield() {
        return shield;
    }

    public int getShots() {
        return shots;
    }

    // public String getResult() {
        // return result;
    // }

    // public void setResult(String result) {
        // this.result = result;
    // }

    public Position getRandomStartPosition() {
        
        Random rand = new Random();

        int startX = rand.nextInt(100 - (-100)) + (-100);
        int startY = rand.nextInt(200 - (-200)) + (-200);

        // this.position = ;

        
        return new Position(startX, startY);
    }

    public IWorld.UpdateResponse updatePosition(int nrSteps) {
        // TODO Auto-generated method stub

        int newX = this.position.getX();
        int newY = this.position.getY();

        if (Direction.NORTH.equals(curDirection)) {
            newY = newY + nrSteps;
        }else if (Direction.SOUTH.equals(curDirection)) {
            newY = newY - nrSteps;
        }else if (Direction.WEST.equals(curDirection)) {
            newX = newX - nrSteps;
        }else if (Direction.EAST.equals(curDirection)) {
            newX = newX + nrSteps;
        }

        Position newPosition = new Position(newX, newY);
        if (newPosition.isIn(getWorld().getTOP_LEFT(), getWorld().getBOTTOM_RIGHT())){
           if (!getWorld().getMaze().blocksPath(position, newPosition)){
                this.position = newPosition;
                return  IWorld.UpdateResponse.SUCCESS ;
           }
//            return IWorld.UpdateResponse.FAILED_OBSTRUCTED;

        }
        return IWorld.UpdateResponse.FAILED_OUTSIDE_WORLD;

    }


    public void updateDirection(boolean turnRight) {
        // TODO Auto-generated method stub
        if (turnRight){
            if (Direction.NORTH.equals(this.curDirection)) {
                this.curDirection = Direction.EAST;
            }else if (Direction.SOUTH.equals(this.curDirection)) {
                this.curDirection = Direction.WEST;
            }else if (Direction.WEST.equals(this.curDirection)) {
                this.curDirection = Direction.NORTH;
            }else if (Direction.EAST.equals(this.curDirection)) {
                this.curDirection = Direction.SOUTH;
            }

        }else{
            
            if (Direction.NORTH.equals(this.curDirection)) {
                this.curDirection = Direction.WEST;
            }else if (Direction.SOUTH.equals(this.curDirection)) {
                this.curDirection = Direction.EAST;
            }else if (Direction.WEST.equals(this.curDirection)) {
                this.curDirection = Direction.SOUTH;
            }else if (Direction.EAST.equals(this.curDirection)) {
                this.curDirection = Direction.NORTH;
            }
        }

    }


    public void updateShield(Boolean shot) {
        // TODO Auto-generated method stub
        if(shot) {
            shield -= 1;
        }
        // if(shot.equalsIgnoreCase("mine")) {
            // shield -= 2;
        // }
        
        else if (!shot) {
            try {
                Thread.sleep(this.repairSpeed);
            } catch (Exception e) {
                //TODO: handle exception
            }
            
            shield = maxShield;
        }

        if (shield <= 0) {
            getWorld().remove(this);
            // world.removeRobotFromWorldMap(this);
            // this.status = "You died";
//            alive = false;
//            shield = 0;
        }

    }


    public void updateShots(boolean shoot) {
        // TODO Auto-generated method stub
        if (!emptyGun && shoot) {
            this.shots -= 1;
            if (shots == 0) {
                emptyGun = true;
            }
        }
        if(!shoot) {
            try {
                Thread.sleep(this.reloadSpeed);
            } catch (Exception e) {
                //TODO: handle exception
            }
            
            this.shots = maxNumberOfShots;
            this.emptyGun = false;
        }

    }

    public boolean handleCommand(Commands command){
        return command.execute(this);
    }

    // public void updatePosition(int i) {
    // }

    // private void doShotNorth(){
    // }

    // private void doShotSouth(){
    // }

    // private void doShotEast(){
    // }

    // private void doShotWest(){
    // }

    public boolean isInShootingRange(Robot shooter, Robot target){
        boolean isInYRangePositive = (target.getPosition().getY() - shooter.getPosition().getY() )*-1 <= distance;
        boolean isInXRangePositive = (target.getPosition().getX() - shooter.getPosition().getX() )*-1 <= distance;

        boolean isInYRangeNegative = (shooter.getPosition().getY() - target.getPosition().getY())*-1 <= distance;
        boolean isInXRangeNegative = (shooter.getPosition().getX() - target.getPosition().getX())*-1 <= distance;

        if (shooter.getPosition().getX() == target.getPosition().getX() ){
            if (shooter.getPosition().getY() < target.getPosition().getY()){
                tarDirection = Direction.NORTH;
                return isInYRangePositive;
            }else if (shooter.getPosition().getY() > target.getPosition().getY()){
                tarDirection = Direction.SOUTH;
                return isInYRangeNegative;
            }
            // return isInYRange;

        }else if (shooter.getPosition().getY() == target.getPosition().getY()){
            if (shooter.getPosition().getX() < target.getPosition().getX()){
                tarDirection = Direction.EAST;
                return isInXRangePositive;
            }else if (shooter.getPosition().getX() > target.getPosition().getX()){
                tarDirection = Direction.WEST;
                return isInXRangeNegative;
            }
            // return isInXRange;

        }

        return false;
    }

    public boolean updateBullet() {
        // int newX = this.position.getX();
        // int newY = this.position.getY();
        

        if (emptyGun){
            return false;
        }
            

        if (shots == 5) {distance = 1;}
        if (shots == 4) {distance = 2;}
        if (shots == 3) {distance = 3;}
        if (shots == 2) {distance = 4;}
        if (shots == 1) {distance = 5;}

        // switch (getCurDirection()){
            // case NORTH:
                // doShotNorth();
            // case EAST:
                // doShotEast();
            // case WEST:
                // doShotWest();
            // case SOUTH:
                // doShotSouth();
        // }

        for (Robot robot : world.getPlayers()) {
            // Position newPosition  = new Position(newX, newY);
            if (!robot.getName().contains(this.getName())){

                if (isInShootingRange(this, robot)){
                    if (!robot.blocksPath(this.getPosition(), robot.getPosition())) {
                        if (this.getCurDirection() == tarDirection){
                            robot.updateShield(true); 
                            return true;
                        }
                        
                    }
                }
            }
            
            
        }
        return false;
    }

    public boolean getEmptyGun() {
        return emptyGun;
    }

    public boolean blocksPosition(Position position) {
        // TODO Auto-generated method stub

        boolean inLeft = BLOCK_BOTTOM_LEFT.getY() <= position.getY() && position.getY() <= BLOCK_TOP_RIGHT.getY() && position.getX() == BLOCK_BOTTOM_LEFT.getX();
        boolean inBottom = BLOCK_BOTTOM_LEFT.getX() <= position.getX() && position.getX()  <= BLOCK_TOP_RIGHT.getX() && position.getY() == BLOCK_BOTTOM_LEFT.getY();

        boolean inRight = BLOCK_BOTTOM_LEFT.getY() <= position.getY() && position.getY()  <= BLOCK_TOP_RIGHT.getY() && position.getX() == BLOCK_TOP_RIGHT.getX();
        boolean inTop = BLOCK_BOTTOM_LEFT.getX() <= position.getX() && position.getX()  <= BLOCK_TOP_RIGHT.getX() && position.getY() == BLOCK_TOP_RIGHT.getY();

        return inTop || inBottom || inLeft || inRight;
    }

    public boolean blocksPath(Position a, Position b) {
        // TODO Auto-generated method stub

        if (a.getX() == b.getX()){
            for (int i = a.getY(); i <= b.getY(); i++){
                Position newPosition = new Position(a.getX(), i);
                if (blocksPosition(newPosition)){
                    return true;
                }

            }
        }else if (a.getY() == b.getY()){
            for (int i = a.getX(); i <= b.getX(); i++){
                Position newPosition = new Position(i, a.getY());
                if (blocksPosition(newPosition)){
                    return true;
                }

            }

        }

        return false;
    }

}
