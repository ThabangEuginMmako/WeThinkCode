package za.co.wethinkcode.examples.client;

import org.json.JSONArray;

public class HelpRequest extends Request{

    public HelpRequest(String name, String command, JSONArray arguments) {
        super(name, command, arguments);
        //TODO Auto-generated constructor stub
    }

    
}
