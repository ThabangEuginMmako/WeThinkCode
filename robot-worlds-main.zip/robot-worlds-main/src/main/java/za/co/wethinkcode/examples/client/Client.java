package za.co.wethinkcode.examples.client;

import org.json.JSONObject;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
// import java.util.Map;
import java.util.Scanner;

public class Client {

    private Socket socket;
    private BufferedReader in;
    private BufferedWriter out;
    private String robotName;
    // private ArrayList<String> argsList = new ArrayList<>(); 

    private JSONObject request;
    private JSONObject response;

    private static Scanner scan;

    public Client(Socket socket) {
        try {
            this.socket = socket;
            this.out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        
        } catch (Exception e) {
            closeClient(socket, in, out);
        }
    }

    public void sendMessage(){
        try {

            ArrayList<String> robots = new ArrayList<>();
            robots.add("alexander");
            robots.add("barron");
            robots.add("caddock");
            robots.add("duncan");

            Scanner scanner = new Scanner(System.in);
            System.out.println("What do you want to name your robot? ");
            robotName = scanner.nextLine();
            // scanner.close();

            String input;


            System.out.println("Choose From The Available Combat Robots: \n" +
            "Alexander: defender of men. \n" +
            "Barron: fighter. \n" +
            "Caddock: war-ready, battle sharp. \n" +
            "Duncan: dark fighter");

            input = scanner.nextLine();

            String[] inputArgs = input.toLowerCase().trim().split(" ");

            while (!inputArgs[0].contains("launch") || !robots.contains(inputArgs[1])){

                System.out.println("Choose From The Available Combat Robots: \n" +
                    "Alexander: defender of men. \n" +
                    "Barron: fighter. \n" +
                    "Caddock: war-ready, battle sharp. \n" +
                    "Duncan: dark fighter");

                input = scanner.nextLine();

                inputArgs = input.toLowerCase().trim().split(" ");

            }

            Request launch = Request.create(input, robotName);
            request = launch.getRequest();

            out.write(request.toString());
            out.newLine();
            out.flush();


            scan = new Scanner(System.in);
            while (socket.isConnected()) {

                try {
                    System.out.println("What do you want to do next?");
                    input = scan.nextLine().toLowerCase();

                    if (input.contains("quit")){
                        System.exit(0);
                        break;
                    }

                    Request obj = Request.create(input, robotName);
                    request = obj.getRequest();
                    
                    out.write(request.toString());
                    out.newLine();
                    out.flush();
                } catch (Exception e) {
                    //TODO: handle exception
                    continue;
                }
                


            }
        } catch (IOException e) {
            closeClient(socket, in, out);
        }
    }

    public void listener() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String serverMsg;

                while (socket.isConnected()) {
                    try {
                        serverMsg = in.readLine();
                        response = new JSONObject(serverMsg);

                        System.out.println(response);

                        try {
                            if (response.getString("message").contains("quit")){
                                System.out.print("GAME Over!\n Enter quit to exit game:");

                            }
                        } catch (Exception e) {
                            //TODO: handle exception
                            continue;
                        }
                        

                    } catch (IOException e) {
                        closeClient(socket, in, out);
                    }
                }
            }
        }).start();
    }

    public void closeClient(Socket socket, BufferedReader reader, BufferedWriter writer){

        try {
            if (reader != null){
                reader.close();
            }
            if (writer != null){
                writer.close();
            }
            if (socket != null){
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    

    public static void main(String args[]) throws IOException {

        
        Socket socket = new Socket("localhost", 5001);
        Client client = new Client(socket);
        client.listener();
        client.sendMessage();

    }
}
