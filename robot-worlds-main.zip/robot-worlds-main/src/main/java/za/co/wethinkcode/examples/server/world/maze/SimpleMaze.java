package za.co.wethinkcode.examples.server.world.maze;

import java.util.ArrayList;
import java.util.List;

import za.co.wethinkcode.examples.server.robot.Position;
import za.co.wethinkcode.examples.server.world.obstructions.Obstacle;
import za.co.wethinkcode.examples.server.world.obstructions.SquareObstacle;

public class SimpleMaze implements Maze {
    private List <Obstacle> newList = new ArrayList<>();
    private Obstacle obs2 = new SquareObstacle(0, 0);

    public Obstacle getObs2() {
        return obs2;
    }

    @Override
    public List<Obstacle> getObstacles() {


        newList.add(new SquareObstacle(1, 1));

        return newList;
    }

    @Override
    public boolean blocksPath(Position a, Position b) {

        Obstacle obs;

        for (int i = 0; i < this.newList.size(); i++){
            obs = this.newList.get(i);
            if (obs.blocksPath(a, b)){
                obs2 = obs;
                return true;
            }
        }
        return false;
    }
}
