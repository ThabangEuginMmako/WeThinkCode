package za.co.wethinkcode.examples.server.world;


import java.util.List;
import java.util.ArrayList;



import org.json.JSONObject;


import za.co.wethinkcode.examples.server.robot.Direction;
import za.co.wethinkcode.examples.server.robot.Position;
import za.co.wethinkcode.examples.server.robot.Robot;
import za.co.wethinkcode.examples.server.world.maze.Maze;
import za.co.wethinkcode.examples.server.world.obstructions.Obstacle;

import static za.co.wethinkcode.examples.server.world.IWorld.CENTRE;

public class World {

    private JSONObject worldMsg;
    private List<Robot> players = new ArrayList<>();
    public List<Obstacle> obsList = new ArrayList<>();

    private Position CENTER = new Position(0, 0);
    private Position TOP_LEFT = new Position(-100, 100);
    private Position BOTTOM_RIGHT = new Position(100, -100);


    private Position position;
    private Direction currentDirection;
    // private String status;
    // private String name;
    private Maze maze;

    public List<Robot> getPlayers() {
        return players;
    }

    public World(Maze maze){
        this.maze = maze;
        this.obsList = maze.getObstacles();
        this.position = CENTRE;
        this.currentDirection = Direction.NORTH;
        // this.status = "Ready";
    }

    public boolean playerExists(String name){
        for (Robot in : players) {
            if (in.getName().contains(name)){
                return true;
            }
        }
        return false;
    }


    public void join(Robot player){

        if (playerExists(player.getName())){

        }
        
        players.add(player);
    }

    public Position getTOP_LEFT() {
        return TOP_LEFT;
    }

    public Position getBOTTOM_RIGHT() {
        return BOTTOM_RIGHT;
    }

    public void remove(Robot player){
        if (playerExists(player.getName())){
            players.remove(player);
        }
    }

    public List<Robot> lookRobots(Robot robot){
        Position neWPosition;
        List<Robot> lRobots = new ArrayList<>();
        if(robot.getCurDirection() == Direction.NORTH){
            for (Robot robot2 : getPlayers()) {
                for (int i = 0; i < 5; i++) {
                    neWPosition = new Position(robot.getPosition().getX(), robot.getPosition().getY()+(i+1));
                    if(robot2.getPosition().equals(neWPosition)){
                        lRobots.add(robot2);
                    }
                }
            }

        }else if(robot.getCurDirection() == Direction.SOUTH){
            for (Robot robot2 : getPlayers()) {
                for (int i = 0; i < 5; i++) {
                    neWPosition = new Position(robot.getPosition().getX(), robot.getPosition().getY()-(i+1));
                    if(robot2.getPosition().equals(neWPosition)){
                        lRobots.add(robot2);
                    }
                }
            }

        }else if(robot.getCurDirection() == Direction.EAST){
            for (Robot robot2 : getPlayers()) {
                for (int i = 0; i < 5; i++) {
                    neWPosition = new Position(robot.getPosition().getX()+(i+1), robot.getPosition().getY());
                    if(robot2.getPosition().equals(neWPosition)){
                        lRobots.add(robot2);
                    }
                }
            }

        }else if(robot.getCurDirection() == Direction.WEST){
            for (Robot robot2 : getPlayers()) {
                for (int i = 0; i < 5; i++) {
                    neWPosition = new Position(robot.getPosition().getX()-(i+1), robot.getPosition().getY());
                    if(robot2.getPosition().equals(neWPosition)){
                        lRobots.add(robot2);
                    }
                }
            }
        }

        return lRobots;
    }

    public List<Obstacle> lookObstacles(Robot robot){
        Position neWPosition;
        List<Obstacle> lObstacles = new ArrayList<>();
        if(robot.getCurDirection() == Direction.NORTH){
            for (int i = 0; i < 5; i++) {
                neWPosition = new Position(robot.getPosition().getX(), robot.getPosition().getY()+(i+1));
                if(maze.blocksPath(new Position(robot.getPosition().getX(), robot.getPosition().getY()+(i)), neWPosition)){
                    lObstacles.add(maze.getObs2());
                    break;
                }
            }

        }else if(robot.getCurDirection() == Direction.SOUTH){
            for (int i = 0; i < 5; i++) {
                neWPosition = new Position(robot.getPosition().getX(), robot.getPosition().getY()-(i+1));
                if(maze.blocksPath(new Position(robot.getPosition().getX(), robot.getPosition().getY()-(i)), new Position(robot.getPosition().getX(), robot.getPosition().getY()-(i+1)))){
                    lObstacles.add(maze.getObs2());
                    break;
                }
            }

        }else if(robot.getCurDirection() == Direction.EAST){
            for (int i = 0; i < 5; i++) {
                neWPosition = new Position(robot.getPosition().getX()+(i+1), robot.getPosition().getY());
                if(maze.blocksPath(new Position(robot.getPosition().getX()+(i), robot.getPosition().getY()), new Position(robot.getPosition().getX()+(i+1), robot.getPosition().getY()))){
                    lObstacles.add(maze.getObs2());
                    break;
                }
            }

        }else if(robot.getCurDirection() == Direction.WEST){
            for (int i = 0; i < 5; i++) {
                neWPosition = new Position(robot.getPosition().getX()-(i+1), robot.getPosition().getY());
                if(maze.blocksPath(new Position(robot.getPosition().getX()-(i), robot.getPosition().getY()), new Position(robot.getPosition().getX()-(i+1), robot.getPosition().getY()))){
                    lObstacles.add(maze.getObs2());
                    break;
                }
            }

        }

        return lObstacles;
    }

    public Maze getMaze() {
        return maze;
    }


    public boolean isNewPositionAllowed(Position position) {
        // TODO Auto-generated method stub
        if (position.isIn(TOP_LEFT, BOTTOM_RIGHT)){

            return true;
        }
        return false;
    }


    public void reset() {
        // TODO Auto-generated method stub
        this.currentDirection = Direction.NORTH;
        this.position = CENTRE;
        
    }
    
    public List<Obstacle> getObstacles() {
        // TODO Auto-generated method stub

        return this.obsList;
    }


    public void showObstacles() {
        // TODO Auto-generated method stub

        int num = this.obsList.size();        
        for (int i = 0; i < num; i++){
            Obstacle square = obsList.get(i);
            int x = square.getBottomLeftX();
            int y = square.getBottomLeftY();

            System.out.println("- At position "+x+","+y+" (to "+(x+4)+","+(y+4)+")");
        }
        
    }


    public void notifyPlayers(String msg){
        for (Robot player : players){
            try {
                    worldMsg = new JSONObject();
                    worldMsg.put("message", msg);
                    player.getOut().write(worldMsg.toString());
                    player.getOut().newLine();
                    player.getOut().flush();
            } catch (Exception e) {
                System.out.println("Error!");
            }
        }
    }

    public void removePlay(String msg, Robot player){
        players.remove(player);
        notifyPlayers(msg);
    }

    
}


