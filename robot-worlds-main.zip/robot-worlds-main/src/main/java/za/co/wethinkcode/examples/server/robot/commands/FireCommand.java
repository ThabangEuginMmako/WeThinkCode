package za.co.wethinkcode.examples.server.robot.commands;

import java.util.HashMap;
import java.util.Map;

import za.co.wethinkcode.examples.server.robot.Robot;

public class FireCommand extends Commands{
    public boolean hit;
    public boolean miss;
    public FireCommand() { super("fire"); }

    @Override
    public boolean execute(Robot target) {

        String message;

        if(target.updateBullet()) {
            this.hit = true;
            this.miss = false;
            message = "Hit";
            target.updateShots(true);
        }
        else {
            if(!target.getEmptyGun()) {
                this.miss = true;
                this.hit = false;
                message = "Miss";
                target.updateShots(true);
            }
            else {
                message = "Out Of Ammo";
            }
        }

        String results = "OK";
        Map<String, Object> data = new HashMap<>();
        Map<String, Object> state = new HashMap<>();

        data.put("message", message);

        state.put("position", target.getPosition());
        state.put("direction", target.getCurDirection());
        state.put("shields", target.getShield());
        state.put("shots",  target.getShots());
        state.put("status", "FIRE");
        
        target.setResults(results);
        target.setData(data);
        target.setState(state);
        


        return true;
    }
}