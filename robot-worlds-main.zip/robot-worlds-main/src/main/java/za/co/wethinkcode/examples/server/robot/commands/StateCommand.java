package za.co.wethinkcode.examples.server.robot.commands;

// import java.lang.annotation.Target;
import java.util.HashMap;
import java.util.Map;

// import org.json.JSONObject;

import za.co.wethinkcode.examples.server.robot.Robot;

public class StateCommand extends Commands {

    public StateCommand(){
        super("state");
    }

    @Override
    public boolean execute(Robot target) {
        // TODO Auto-generated method stub

        String results = "OK";
        Map<String, Object> data = new HashMap<>();
        Map<String, Object> state = new HashMap<>();

        state.put("position", target.getPosition());
        state.put("direction", target.getCurDirection());
        state.put("shields", target.getShield());
        state.put("shots",  target.getShots());
        state.put("status", "NORMAL");
        
        target.setResults(results);
        target.setData(data);
        target.setState(state);
        
        return true;
    }
    
}
