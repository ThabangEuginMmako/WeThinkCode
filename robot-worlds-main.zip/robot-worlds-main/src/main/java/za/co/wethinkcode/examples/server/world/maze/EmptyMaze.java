package za.co.wethinkcode.examples.server.world.maze;

import java.util.ArrayList;
import java.util.List;

import za.co.wethinkcode.examples.server.robot.Position;
import za.co.wethinkcode.examples.server.world.obstructions.Obstacle;

public class EmptyMaze implements Maze{
    List <Obstacle> newList = new ArrayList<>();

    @Override
    public List<Obstacle> getObstacles() {
        // TODO Auto-generated method stub

        
        return newList;
    }

    @Override
    public boolean blocksPath(Position a, Position b) {
        // TODO Auto-generated method stub
        Obstacle obs;

        for (int i = 0; i < this.newList.size(); i++){
            obs = this.newList.get(i);
            if (obs.blocksPath(a, b)){
                return true;
            }
        }
        return false;
    }

    @Override
    public Obstacle getObs2() {
        // TODO Auto-generated method stub
        return null;
    }
    
}
