package za.co.wethinkcode.examples.client;

import org.json.JSONArray;

public class MotionRequest extends Request {
    public MotionRequest(String name, boolean forward, String steps) {
        super(name, forward? "forward" : "back", new JSONArray("[" + steps + "]"));
    }
}