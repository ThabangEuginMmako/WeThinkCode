package za.co.wethinkcode.examples.server.robot.commands;

import java.util.HashMap;
import java.util.Map;

// import org.json.JSONObject;

import za.co.wethinkcode.examples.server.robot.Robot;

public class DefaultCommand extends Commands {

    public DefaultCommand(String incorrectInput){
        super("default", incorrectInput);
    }

    @Override
    public boolean execute(Robot target) {
        // TODO Auto-generated method stub

        Map<String, Object> data = new HashMap<>();

        data.put("message", "Unsupported command");

        Map<String, Object> state = new HashMap<>();
        
        target.setResults("ERROR");
        target.setData(data);
        target.setState(state);

        return true;
    }
    
}
