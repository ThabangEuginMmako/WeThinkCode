package za.co.wethinkcode.examples.server;

import java.io.BufferedWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.json.JSONObject;

import za.co.wethinkcode.examples.server.robot.Robot;
import za.co.wethinkcode.examples.server.world.World;
import za.co.wethinkcode.examples.server.world.obstructions.Obstacle;

public class WorldThread implements Runnable {

    private Server server;
    private World world;

    public WorldThread(World w, Server server){
        this.server = server;
        this.world = w;
    }

    /**
     * 
     */
    public void quite(){
        
        System.out.println("Quiting game");
        

        for (PlayingThread play : server.getPlayList()) {

            JSONObject quitResponse = new JSONObject();
            quitResponse.put("results", "OK");
            Map<String, Object> data = new HashMap<>();
            data.put("message", "quit");

            quitResponse.put("data", data);

            BufferedWriter out = play.getOut();
            try {
                // System.out.println("quit response");
                out.write(quitResponse.toString());
                out.newLine();
                out.flush();

            } catch (Exception e) {
                //TODO: handle exception
            }
            
        }

        // for (Thread thread : server.getThreadsList()) {
        //     thread.;
        // }


    }

    public void dump(){
        System.out.println("Dump");
        System.out.println("Robots available in the world: ");
        System.out.println("_".repeat(20));
        for (Robot robot: world.getPlayers()) {
            System.out.println("Name: " + robot.getName());
            System.out.println("Position: " + robot.getPosition());
            System.out.println("Direction: " + robot.getCurDirection());
            System.out.println("State: " + robot.getState());
        }

        System.out.println("\n Obstacles available in the world: ");
        for(Obstacle obstacle: world.getObstacles())
        System.out.println(obstacle.getBottomLeftX()+ ", "+ obstacle.getBottomLeftY());

    }

    public void robot(){
        System.out.println("Robot");
        for(Robot robot : world.getPlayers()){
            System.out.println("Name: " + robot.getName());
            System.out.println("Position: " + robot.getPosition());
            System.out.println("Direction: " + robot.getCurDirection());
            System.out.println("State: " + robot.getState());
        }

    }

    @Override
    public void run() {
        // TODO Auto-generated method stub
        String termInput;

        while (true){
            System.out.println("Running");
            Scanner scan = new Scanner(System.in);
            termInput = scan.nextLine();
            // scan.close();

            switch (termInput){
                case "quit":
                    quite();
                    break;
                case "dump":
                    dump();
                    break;
                case "robot":
                    robot();
                    break;
            }
            
        }

        
        
    }
    
}
