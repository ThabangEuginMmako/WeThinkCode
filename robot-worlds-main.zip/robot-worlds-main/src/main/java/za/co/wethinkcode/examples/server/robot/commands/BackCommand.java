package za.co.wethinkcode.examples.server.robot.commands;

import java.util.HashMap;
import java.util.Map;

import za.co.wethinkcode.examples.server.robot.Robot;

public class BackCommand extends Commands {

    @Override
    public boolean execute(Robot target) {
        int nrSteps = Integer.parseInt(getArgument());
        target.updatePosition(-nrSteps);

        String results = "OK";
        Map<String, Object> data = new HashMap<>();
        Map<String, Object> state = new HashMap<>();

        data.put("message", "");
        data.put("movement","Back");
        data.put("steps",nrSteps);
        // data.put("turn",turn);

        state.put("position", target.getPosition());
        state.put("direction", target.getCurDirection());
        state.put("shields", target.getShield());
        state.put("shots",  target.getShots());
        state.put("status", "NORMAL");

        target.setResults(results);
        target.setData(data);
        target.setState(state);

        return true;
    }

    public BackCommand(String argument) {
        super("back", argument);
    }
}
