package za.co.wethinkcode.examples.server.world;

// import za.co.wethinkcode.examples.server.robot.Robot;
// import za.co.wethinkcode.examples.server.robot.commands.Commands;

public class Configure {

    public Configure(String name) {
        
    }

    
    
}
