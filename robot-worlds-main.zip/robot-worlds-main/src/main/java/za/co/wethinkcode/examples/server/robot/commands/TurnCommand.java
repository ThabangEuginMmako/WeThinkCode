package za.co.wethinkcode.examples.server.robot.commands;

import java.util.HashMap;
import java.util.Map;

import za.co.wethinkcode.examples.server.robot.Robot;

public class TurnCommand extends Commands {
    @Override
    public boolean execute(Robot target) {
         String turn_direction = getArgument();

         String results = "OK";
         Map<String, Object> data = new HashMap<>();
         Map<String, Object> state = new HashMap<>();


         if (turn_direction.equalsIgnoreCase("right")) {
             target.updateDirection(true);
           
             data.put("message", "");
             // data.put("movement","Forward");
             data.put("steps",0);
             data.put("turn","Right");
            

         }else if (turn_direction.equalsIgnoreCase("left")) {
             target.updateDirection(false);
            
             data.put("message", "");
             // data.put("movement","Forward");
             data.put("steps",0);
             data.put("turn","Left");

         }else {
             throw new IllegalArgumentException("Could not parse arguments");
         }

         state.put("position", target.getPosition());
         state.put("direction", target.getCurDirection());
         state.put("shields", target.getShield());
         state.put("shots",  target.getShots());
         state.put("status", "NORMAL");
         target.setResults(results);
         target.setData(data);
         target.setState(state);

        return true;
    }

    public TurnCommand(String argument) {
        super("turn", argument);
    }
}