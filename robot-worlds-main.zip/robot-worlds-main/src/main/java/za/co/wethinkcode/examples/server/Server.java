package za.co.wethinkcode.examples.server;

import za.co.wethinkcode.examples.server.world.World;
import za.co.wethinkcode.examples.server.world.maze.EmptyMaze;
import za.co.wethinkcode.examples.server.world.maze.GameMaze;
import za.co.wethinkcode.examples.server.world.maze.Maze;
import za.co.wethinkcode.examples.server.world.maze.SimpleMaze;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

public class Server {

    private List<PlayingThread> playList = new ArrayList<>();
    private List<Thread> threadsList = new ArrayList<>();
    private ServerSocket server;
    private static Maze maze;
    private World world;



    public List<Thread> getThreadsList() {
        return threadsList;
    }

    public List<PlayingThread> getPlayList() {
        return playList;
    }

    public Server(ServerSocket s, World w){
        this.server = s;
        this.world = w;
        
    }

    public void startServer(){
        try {
            

            while (!server.isClosed()){
                Socket socket = server.accept();
                System.out.println("Connection: " + socket);
                
                PlayingThread play = new PlayingThread(socket, world);

                
                Thread pThread = new Thread(play);
                playList.add(play);
                threadsList.add(pThread);

                
                pThread.start();

            }
        } catch (IOException e){
            
        }
    }

    public void closeServer(){
        try {
            if (server != null){
                server.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws ClassNotFoundException, IOException {

        ServerSocket s = new ServerSocket(5001);
        try {
            if (args[0].toLowerCase().contains("emptymaze")){
                maze = new EmptyMaze();
            }else if (args[0].toLowerCase().contains("simplemaze")){
                System.out.println("Simple Maze!");
                maze = new SimpleMaze();
            }else if (args[0].toLowerCase().contains("gamemaze")){
                maze = new GameMaze();
                
            }
        } catch (Exception e) {
            //TODO: handle exception
            maze = new EmptyMaze();
        }

        World w = new World(maze);

        
        

        System.out.println("Server running & waiting for client connections.");
        w.showObstacles();
        Server runningServer = new Server(s, w);
        WorldThread worldThread = new WorldThread(w, runningServer);
        Thread wThread = new Thread(worldThread);
        wThread.start();
        runningServer.startServer();
        
    }
}
