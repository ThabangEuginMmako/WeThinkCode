package za.co.wethinkcode.examples.server.robot;

import java.io.BufferedWriter;

import za.co.wethinkcode.examples.server.world.World;

public class Alexander extends Robot{

    public Alexander(String name , BufferedWriter out, World world) {
        super(name, out, world);
        //TODO Auto-generated constructor stub
    }

}
