package za.co.wethinkcode.examples.server.robot.commands;

import java.util.HashMap;
import java.util.Map;

// import org.json.JSONObject;

import za.co.wethinkcode.examples.server.robot.Robot;

public class LaunchCommand extends Commands{

    public LaunchCommand() {
        super("launch");
        //TODO Auto-generated constructor stub
    }

    @Override
    public boolean execute(Robot target) {
        // TODO Auto-generated method stub


        target.getWorld().join(target);

        String results = "OK";
        Map<String, Object> data = new HashMap<>();
        Map<String, Object> state = new HashMap<>();

        data.put("position", target.getPosition());
        data.put("visibility", true);
        data.put("reload", 3);
        data.put("repair", 3);
        data.put("shields", target.getShield());

        state.put("position", target.getPosition());
        state.put("direction", target.getCurDirection());
        state.put("shields", target.getShield());
        state.put("shots",  target.getShots());
        state.put("status", "NORMAL");
        
        target.setResults(results);
        target.setData(data);
        target.setState(state);



        target.getWorld().notifyPlayers(target.getName()+" has entered the world");

        return false;
    }
    
}
