package za.co.wethinkcode.examples.server;

import org.json.JSONArray;
import org.json.JSONObject;
import za.co.wethinkcode.examples.server.robot.*;
import za.co.wethinkcode.examples.server.robot.commands.Commands;
import za.co.wethinkcode.examples.server.world.World;

import java.io.*;
import java.net.*;


public class PlayingThread implements  Runnable{
    private Socket socket;
    private BufferedReader in;
    private BufferedWriter out;
    private String robotName;

    private World world;
    private Robot robot;
    private Commands command;
    private JSONObject request;
    private JSONObject response;


    public PlayingThread(Socket socket, World w) {

        try {
            this.socket = socket;
            this.out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.world = w;
        } catch (IOException e){
            closeThread(socket, in, out);
        }

    }
    
    public String getRobotName() {
        return robotName;
    }

    public BufferedWriter getOut() {
        return out;
    }

    public void run() {

        String clientMsg;

        try {
            String launch = in.readLine();
            System.out.println(launch);

            request = new JSONObject(launch);
            String com = request.getString("command");
            JSONArray arg = (JSONArray) request.get("arguments");

            if (!com.equalsIgnoreCase("launch")){
                out.write(response.toString());
                out.newLine();
                out.flush();
                
                launch = in.readLine();
                System.out.println(launch);

                request = new JSONObject(launch);
                com = request.getString("command");
                arg = (JSONArray) request.get("arguments");
            }else {
                switch (arg.getString(0)){
                    case ("alexander"):
                        robot = new Alexander(request.getString("robot"), out, world);
                    case ("barron"):
                        robot = new Barron(request.getString("robot"), out, world);
                    case ("caddock"):
                        robot = new Caddock(request.getString("robot"), out, world);
                    case ("duncan"):
                        robot = new Duncan(request.getString("robot"), out, world);

                }
            }

            command = Commands.create(request.getString("command"), arg);
            robot.handleCommand(command);

            createResponse();

            out.write(response.toString());
            out.newLine();
            out.flush();

        }catch (IOException e){

        }

        while (socket.isConnected()){
            try {
                clientMsg = in.readLine();
                System.out.println(clientMsg);

                request = new JSONObject(clientMsg);

                JSONArray arg = (JSONArray) request.get("arguments");

                command = Commands.create(request.getString("command"), arg);
                robot.handleCommand(command);
                
                createResponse();

                out.write(response.toString());
                out.newLine();
                out.flush();

            } catch (IOException e) {
                closeThread(socket, in, out);
                break;
            }
        }

    }

    public void createResponse(){
        response = new JSONObject();

        response.put("result", robot.getResults());
        response.put("data", robot.getData());
        response.put("state", robot.getState());
    }


    
    public void closeThread(Socket socket, BufferedReader reader, BufferedWriter writer){

        try {
            if (reader != null){
                reader.close();
            }
            if (writer != null){
                writer.close();
            }
            if (socket != null){
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
