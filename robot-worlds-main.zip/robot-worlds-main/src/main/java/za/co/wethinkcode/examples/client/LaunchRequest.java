package za.co.wethinkcode.examples.client;

import org.json.JSONArray;

public class LaunchRequest extends Request{
    public LaunchRequest(String robot, String kind) {
        super(robot, "launch",
                new JSONArray("[" + kind +"]") );
    }
}