package za.co.wethinkcode.examples.server.robot.commands;

import org.json.JSONArray;

import za.co.wethinkcode.examples.server.robot.Robot;

public abstract class Commands {
    private final String commandName;
    private String argument;

    public abstract boolean execute(Robot target);

    public Commands(String name){
        this.commandName = name;
        this.argument = "";

    }

    public Commands(String name, String argument){
        this.commandName = name;
        this.argument = argument;

    }

    public String getCommandName() {
        return commandName;
    }

    public String getArgument() {
        return argument;
    }

    public static Commands create(String instruction, JSONArray arg){
        // String[] arg = args;
        System.out.println(arg);

        switch (instruction){
            case "launch":
                return new LaunchCommand();
            case "look":
                return new LookCommand();
            case "state":
                return new StateCommand();
            case "fire":
                return new FireCommand();
            case "forward":
                return new ForwardCommand(arg.get(0).toString());
            case "back":
                return new BackCommand(arg.get(0).toString());
             case "turn":
                 return  new TurnCommand(arg.getString(0));
//            case "right":
//                return new RightCommand();
//            case "left":
//                return new LeftCommand();
            case "reload":
                return  new ReloadCommand();
            case "repair":
                return  new RepairCommand();
            case "help":
                return  new HelpCommand();
            default:
                return new DefaultCommand(instruction);
        }
    }
}