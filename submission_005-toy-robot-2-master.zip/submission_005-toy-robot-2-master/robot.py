def robot_name():
    """allows the user to name the robot by taking in input from the user """
    name = input("What do you want to name your robot? ")
    print(f"{name}: Hello kiddo!")
    return name


def input_command(rob_name):
    """allows the user to tell the robot how to move by taking in input from the user"""
    user_command =input(f"{rob_name}: What must I do next? ")
    origin_command = user_command
    user_command = user_command.upper().split()
    return user_command, origin_command


def process_command(input_com,rob_name,steps,pos):
    """takes in the users commands, makes sense of them and prints or runs the appropriate function"""
    command_list = ["OFF","HELP","FORWARD","BACK","RIGHT", "LEFT", "SPRINT"]

    if input_com[0][0] not in command_list:
        print(f"{rob_name}: Sorry, I did not understand '{input_com[1]}'.")
    elif input_com[0][0] == command_list[0]:
        print(f"{rob_name}: Shutting down..")
        return
    elif input_com[0][0] == command_list[1]:
        print(help_command())
    elif input_com[0][0] == command_list[2]:
        pos = track_position(+steps,pos)
        if check_position_range(pos) ==  False:
            pos = track_position(-steps,pos)
            print(f"{rob_name}: Sorry, I cannot go outside my safe zone.")
            print( f" > {rob_name} now at position ({pos[0]},{pos[1]}).")
        else: 
            print(forward_command(rob_name, steps))
            print(f" > {rob_name} now at position ({pos[0]},{pos[1]}).")
            
    elif input_com[0][0] == command_list[3]:
        pos = track_position(-steps,pos)
        if check_position_range(pos) ==  False:
            pos = track_position(+steps,pos)
            print(f"{rob_name}:Sorry, I cannot go outside my safe zone.")
            print( f" > {rob_name} now at position ({pos[0]},{pos[1]}).")
        else:
            print(backward_command(rob_name,steps))
            print(f" > {rob_name} now at position ({pos[0]},{pos[1]}).")
    elif input_com[0][0] == command_list[4]:
        print(turn_right(rob_name))
        pos[2] += 90
        pos = track_position(+steps,pos)
        print( f" > {rob_name} now at position ({pos[0]},{pos[1]}).")
    elif input_com[0][0] == command_list[5]:
        print(turn_left(rob_name))
        pos[2] -= 90
        pos = track_position(+steps,pos)
        print( f" > {rob_name} now at position ({pos[0]},{pos[1]}).")
    elif input_com[0][0] == command_list[6]:
        if check_position_range(pos) ==  False:
                print(f"{rob_name}:Sorry, I cannot go outside my safe zone.")
                print( f" > {rob_name} now at position ({pos[0]},{pos[1]}).")
        else:
            sprint_forward(rob_name, steps, pos)
            # print( f" > {rob_name} now at position ({pos[0]},{pos[1]}).")

    input_com = input_command(rob_name)

    if len(input_com[0]) == 2:
        steps = int(input_com[0][1])
    else: 
        steps = 0

    return process_command(input_com,rob_name,steps,pos)


def help_command():
    """Displays the valid commands the robot can understand"""
    help_txt = str("I can understand these commands:\
\nOFF  - Shut down robot\
\nHELP - provide information about commands?\
\nforward - Moves the robot forward\
\nback - Moves the robot backward\
\nright - Turns the robot right\
\nleft - Turns the robot left\
\nsprint - Sprints the robot forward\
")
    return help_txt


def forward_command(rob_name,steps):
    """Prints the forward command message"""
    forward_txt = str(f" > {rob_name} moved forward by {steps} steps.")
    return forward_txt


def track_position(steps,pos):
    """keeps track of the robots postion"""
    if pos[2] == 0 or pos[2] == 360:
        pos[2] = 0
        pos[1] += steps
    elif pos[2] == 90:
        pos[0] += steps 
    elif pos[2] == 180:
        pos[1] -= steps
    elif pos[2] == 270 or pos[2] == -90:
        pos[2] = 270
        pos[0] -= steps

    return pos


def backward_command(rob_name,steps):
    """Prints the backward command message"""
    backward_txt = str(f" > {rob_name} moved back by {steps} steps.")
    return backward_txt


def turn_right(rob_name):
    """Prints the turn right command message"""
    right_txt = str(f" > {rob_name} turned right.")
    return right_txt


def turn_left(rob_name):
    """Prints the turn left command message"""
    left_txt = str(f" > {rob_name} turned left.")
    return left_txt
    

def check_position_range(pos):
    """makes sure the robot is within the set range """
    if pos[0] not in range(-100, 100) or pos[1] not in range(-200,200):
        return False
    else: 
        return True
    

def sprint_forward(rob_name, steps, pos):
    """gives the robot a short burst of speed and moves extra distance forward"""
    pos =  track_position(+steps,pos)
    if steps > 0 :
        print(f" > {rob_name} moved forward by {steps} steps.")
        steps -= 1
        sprint_forward(rob_name, steps, pos)
    else:
        print(f" > {rob_name} now at position ({pos[0]},{pos[1]}).")
    

def robot_start():
    """Calls the process_command function to run the program"""
    rob_name = robot_name()
    input_com = input_command(rob_name)
    if len(input_com[0]) == 2 and input_com[0][1].isnumeric():
        steps = int(input_com[0][1])
    else:
        steps = 0
    pos = [0,0,0]
    process_command(input_com, rob_name, steps, pos,)


if __name__ == "__main__":
    robot_start()
