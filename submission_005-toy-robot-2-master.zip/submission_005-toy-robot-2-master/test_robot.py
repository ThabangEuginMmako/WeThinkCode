import unittest
from unittest.main import main
import robot
from unittest.mock import patch
from io import StringIO

class TestRobot(unittest.TestCase):
    @patch("sys.stdin",StringIO("Droid\n")) 
    @patch("sys.stdout",new_callable = StringIO)
    def test_robot_name(self,fakeout):
        robot_name = robot.robot_name()
        self.assertEqual(robot_name,"Droid")
        self.assertEqual(fakeout.getvalue(), "What do you want to name your robot? Droid: Hello kiddo!\n")        


    @patch("sys.stdin",StringIO("OFF\n")) 
    @patch("sys.stdout",new_callable = StringIO)
    def test_input_command(self,fakeout):
        output = robot.input_command("Droid")
        self.assertEqual(fakeout.getvalue(), "Droid: What must I do next? ") 
        self.assertEqual(["OFF"], output[0])


    @patch("sys.stdin",StringIO("Off\n")) 
    @patch("sys.stdout",new_callable = StringIO)
    def test_incorrect_input(self, fakeout):

        robot.process_command((["JUMP"], "Jump"), "Droid", 0, [0, 0, 0])
        output = fakeout.getvalue().strip()
        self.assertEqual(output,"Droid: Sorry, I did not understand 'Jump'.\n\
Droid: What must I do next? Droid: Shutting down..")
        


    @patch("sys.stdin",StringIO("OFF")) 
    @patch("sys.stdout",new_callable = StringIO)
    def test_function(self, fakeout):
        robot.process_command((["OFF"], "off"), "Droid", 0, [0, 0, 0])
        output = fakeout.getvalue().strip()
        self.assertEqual("""Droid: Shutting down..""", output)


    @patch("sys.stdin",StringIO("off\n")) 
    @patch("sys.stdout",new_callable = StringIO)
    def test_help_(self, fakeout):

        robot.process_command((["HELP"], "HELO"), "Droid", 0, [0, 0, 0])

        output = fakeout.getvalue().strip()
        self.assertEqual("""I can understand these commands:
OFF  - Shut down robot
HELP - provide information about commands?
forward - Moves the robot forward
back - Moves the robot backward
right - Turns the robot right
left - Turns the robot left
sprint - Sprints the robot forward
Droid: What must I do next? Droid: Shutting down..""", output)


    @patch("sys.stdin",StringIO("off\n")) 
    @patch("sys.stdout",new_callable = StringIO)
    def test_forward_10_then_off(self, fakeout):

        
        robot.process_command((["FORWARD", "10"], "forward 10"), "Droid", 10, [0, 0, 0])

        output = fakeout.getvalue().strip()
        self.assertEqual("""> Droid moved forward by 10 steps.
 > Droid now at position (0,10).
Droid: What must I do next? Droid: Shutting down..""", output)

    @patch("sys.stdin",StringIO("off\n")) 
    @patch("sys.stdout",new_callable = StringIO)
    def test_back_10_then_off(self, fakeout):

        
        robot.process_command((["BACK", "10"], "back 10"), "Droid", 10, [0, 0, 0])

        output = fakeout.getvalue().strip()
        self.assertEqual("""> Droid moved back by 10 steps.
 > Droid now at position (0,-10).
Droid: What must I do next? Droid: Shutting down..""", output)

    @patch("sys.stdin",StringIO("off\n")) 
    @patch("sys.stdout",new_callable = StringIO)
    def test_right_then_off(self, fakeout):

        robot.process_command((["RIGHT"], "right"), "Droid", 0, [0, 0, 0])

        output = fakeout.getvalue().strip()
        self.assertEqual("""> Droid turned right.
 > Droid now at position (0,0).
Droid: What must I do next? Droid: Shutting down..""", output)

    @patch("sys.stdin",StringIO("off\n")) 
    @patch("sys.stdout",new_callable = StringIO)
    def test_left_then_off(self, fakeout):

        robot.process_command((["LEFT"], "left"), "Droid", 0, [0, 0, 0])

        output = fakeout.getvalue().strip()
        self.assertEqual("""> Droid turned left.
 > Droid now at position (0,0).
Droid: What must I do next? Droid: Shutting down..""", output)


    @patch("sys.stdin",StringIO("off\n")) 
    @patch("sys.stdout",new_callable = StringIO)
    def test_step11_sprint5_then_off(self, fakeout):
        robot.process_command((["SPRINT"], "sprint"), "Droid", 5, [0, 0, 0])

        output = fakeout.getvalue().strip()
        
        self.assertEqual("""> Droid moved forward by 5 steps.
 > Droid moved forward by 4 steps.
 > Droid moved forward by 3 steps.
 > Droid moved forward by 2 steps.
 > Droid moved forward by 1 steps.
 > Droid now at position (0,15).
Droid: What must I do next? Droid: Shutting down..""", output)


if __name__ ==  "__main__":
    unittest.main()
