import unittest
import super_algos
from io import StringIO
import sys


class TestFunctions(unittest.TestCase):
    def test_find_min(self):
        my_list = [14, 3, 9, 7, 11]
        empty_list = []
        min_num1 = min(my_list)
        min_num2 = super_algos.find_min(my_list)
        self.assertEqual(min_num1, min_num2)
        self.assertEqual(super_algos.find_min(empty_list
         ), -1, "Either the list is empty or the list contains invalid data type!")

    def test_sum_all(self):
        my_list = [2, 4, 6, 8, 10]
        empty_list = []
        sum_all_1 = sum(my_list)
        sum_all_2 = super_algos.sum_all(my_list)
        self.assertEqual(sum_all_1, sum_all_2)
        self.assertEqual(super_algos.sum_all(empty_list
         ), -1, "Either the list is empty or the list contains invalid data type!")

    def test_find_possible_strings(self):
        character_set = ["a", "b"]
        test_results = ['aa', 'ab', 'ba', 'bb']
        int_lst = [2, 4, 6]
        n = 2
        results = super_algos.find_possible_strings(character_set, n)
        self.assertEqual(results, test_results)
        self.assertEqual(super_algos.find_possible_strings(
            int_lst, n), [], "The list contains invalid entry!")


sys.stdout = StringIO()
if __name__ == "__main__":
    unittest.main()
