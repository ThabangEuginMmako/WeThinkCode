
def find_min(element):
    """It goes through a list of integers recursively and returns
    the smallest value"""

    if len(element) == 0:
        return -1
    if len(element) == 1:
        return element[0]

    for num in range(len(element)):
        if type(element[num]) != int:
            return -1
    if element[0] < element[1]:
        element.pop(1)
    else:
        element.pop(0)
    return find_min(list(element))


def sum_all(element):
    """It goes through a list of integers recursively and returns
     the sum of all elements"""
    if len(element) == 0:
        return -1
    if len(element) == 1:
        return element[0]

    for num in range(len(element)):
        if type(element[num]) != int:
            return -1

    return element[0] + sum_all(element[1::])


def find_possible_strings(char_set, n):
    """It goes through a list of string characters recursively and prints all
     the possible string combinations multiplied by n by calling a recursive
     function and also appending into an empty list """
    k = len(char_set)
    empty_lst = []

    for char in char_set:
        if type(char) != type(str()):
            return empty_lst
    return possible_stringsRec(char_set, "", k, n, empty_lst)


def possible_stringsRec(char_set, prefix, k, n, empty_lst):
    """Recursive function to iteratively permutate characters and appending 
     them into an empty list"""
    if n == 0:
        print(prefix)
        empty_lst.append(prefix)
        return

    for i in range(k):
        newPrefix = prefix + char_set[i]
        possible_stringsRec(char_set, newPrefix, k, n - 1, empty_lst)
    return empty_lst


def run_prog():
    """This function calls all the functions and passes all the arguments 
     to parameters of the functions and runs the program """
    my_list = [14, 3, 9, 5, 8, 2]
    print(sum_all(my_list))
    my_list2 = [1, 2, 3, 4, 5, 7, 8, 9]
    print(sum_all(my_list2))
    char_set = ['a', 'b']
    n = 3
    possible_strings = find_possible_strings(char_set, n)
    print(possible_strings)


if __name__ == '__main__':
    run_prog()
