package weshare.model;

/*
 ** DO NOT CHANGE!!
 */


import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;
import com.google.common.base.Strings;
import org.javamoney.moneta.Money;
import org.javamoney.moneta.function.MonetaryFunctions;
import weshare.WeShareException;

import javax.money.MonetaryAmount;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Comparator;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.stream.Collectors;

import static weshare.model.MoneyHelper.ZERO_RANDS;

public class Expense extends PersistentModel<Expense> {
    private final Person person;
    private final String description;
    private final MonetaryAmount amount;
    private final LocalDate date;
    private final ConcurrentLinkedDeque<PaymentRequest> paymentRequests;
    private final ConcurrentLinkedDeque<Payment> payments;

    public Expense(Person person, String description, MonetaryAmount amount, LocalDate date) {
        checkDate(date);
        this.person = person;
        this.description = Strings.isNullOrEmpty(description) ? "Unspecified" : description;
        this.amount = amount;
        this.date = date;
        this.paymentRequests = new ConcurrentLinkedDeque<>();
        this.payments = new ConcurrentLinkedDeque<>();
    }

    public PaymentRequest requestPayment(Person personWhoShouldPayBack, MonetaryAmount amountToPay, LocalDate dueDate) {
        PaymentRequest paymentRequest = new PaymentRequest(this, personWhoShouldPayBack, amountToPay, dueDate);
        paymentRequests.add(paymentRequest);
        return paymentRequest;
    }

    public Collection<PaymentRequest> listOfPaymentRequests() {
        return paymentRequests.stream()
                .sorted(Comparator.comparing(PaymentRequest::daysLeftToPay))
                .collect(Collectors.toUnmodifiableList());
    }

    public MonetaryAmount totalAmountOfPaymentsRequested() {
        var maybeSum = paymentRequests.stream()
                .map(PaymentRequest::getAmountToPay)
                .reduce(MonetaryFunctions.sum());
        return maybeSum.orElse(Money.zero(this.amount.getCurrency()));
    }

    public MonetaryAmount totalAmountAvailableForPaymentRequests() {
        return this.amount.subtract(this.totalAmountOfPaymentsRequested());
    }

    public MonetaryAmount totalAmountForPaymentsReceived() {
        return paymentRequests.stream()
                .filter(PaymentRequest::isPaid)
                .map(PaymentRequest::getAmountToPay)
                .reduce(MonetaryFunctions.sum())
                .orElse(Money.zero(this.amount.getCurrency()));
    }

    public MonetaryAmount amountLessPaymentsReceived() {
        var sum = totalAmountForPaymentsReceived();
        return this.amount.subtract(sum);
    }

    @Deprecated
    public Payment payPaymentRequest(int paymentRequestId, Person personWhoShouldPayBack, LocalDate date) {
        Payment payment = this.listOfPaymentRequests().stream()
                .filter(pr -> pr.getId().equals(paymentRequestId))
                .findFirst()
                .orElseThrow(() -> new WeShareException("Cannot find payment request"))
                .pay(personWhoShouldPayBack, date);
        this.payments.add(payment);
        return payment;
    }

    public boolean isFullyPaidByOthers() {
        return amountLessPaymentsReceived().isEqualTo(ZERO_RANDS);
    }

    public void recallPaymentRequest(Integer paymentRequestId) {
        this.paymentRequests.removeIf( paymentRequest ->
                        paymentRequest.getId().equals(paymentRequestId) && !paymentRequest.isPaid());
    }

    public Person getPerson() {
        return person;
    }

    public String getDescription() {
        return description;
    }

    public MonetaryAmount getAmount() {
        return amount;
    }

    public LocalDate getDate() {
        return date;
    }

    private void checkDate(LocalDate date) {
        if (date.isAfter(LocalDate.now())) throw new WeShareException("Expense cannot be in the future");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Expense expense = (Expense) o;
        return Objects.equal(id, expense.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("person", person)
                .add("description", description)
                .add("amount", amount)
                .add("date", date)
                .add("id", id)
                .toString();
    }
}
