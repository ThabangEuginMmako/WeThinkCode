package za.co.wethinkcode.mastermind;

import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;


import static org.junit.jupiter.api.Assertions.*;

class PlayerTest {
    @Test
    void testIsDigits() {
        Player player = new Player();

        assertTrue(player.isDigits("1234"));
        assertFalse(player.isDigits("chars"));
    }

    @Test
    void testGuessCorrect() {
        Player player = new Player(new ByteArrayInputStream("1324\n".getBytes()));
        String guess = player.getGuess();

        assertEquals("1324", guess);
    }

    @Test
    void testIsRightRange() {
        Player player = new Player();

        assertTrue(player.isRightRange("1468"));
        assertFalse(player.isRightRange("0234"));
        assertFalse(player.isRightRange("2349"));
    }

    @Test
    void testIsRightLength() {
        Player player = new Player();

        assertTrue(player.isRightLength("1234"));
        assertFalse(player.isRightLength("12345"));
    }
}

