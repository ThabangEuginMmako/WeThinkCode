def create_outline():
    """
    TODO: implement your code here
    """
    problems = ["Problem 1" , "Problem 2", "Problem 3"]    
    topics = {'Introduction to Python',
              'Tools of the Trade',
              'How to make decisions',
              'How to repeat code',
              'How to structure data',
              'Functions',
              'Modules'}
    status = ["STARTED", "GRADED", "COMPLETED"]
    topics_list = list(topics)
    topics_list = sorted(topics_list)
    topics_dict = {topics_list[0] : problems,  
                   topics_list[1] : problems,
                   topics_list[2] : problems,
                   topics_list[3] : problems,
                   topics_list[4] : problems,
                   topics_list[5] : problems,
                   topics_list[6] : problems}

    students = [("Thabang", topics_list[1], problems[2], status[1]),
                ("Tshepo", topics_list[4], problems[0], status[0]),
                ("Tebogo", topics_list[0], problems[1], status[2])]
    students.sort(key = lambda x:x[3], reverse = True)

    print("Course Topics:")

    for topic in topics_list:
        print("{} {}".format('*', topic))
    
    print("Problems:")
    for key, value in topics_dict.items():
        print("{} {} : {}, {}, {}".format('*',key,value[0],value[1],value[2]))

    count = 1

    print("Student Progress:")
    for student in students:
        print("{}.{} - {}-{} [{}]".format(str(count),student[0],student[1],student[2],student[3]))
        count += 1

if __name__ == "__main__":
    create_outline()
    pass



