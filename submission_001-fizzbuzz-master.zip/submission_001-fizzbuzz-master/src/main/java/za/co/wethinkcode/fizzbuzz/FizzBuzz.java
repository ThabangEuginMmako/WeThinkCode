package za.co.wethinkcode.fizzbuzz;
import java.util.LinkedList;

public class FizzBuzz {

    public String checkNumber(int number) {

        boolean divisibleBy3 = number % 3 == 0;
        boolean divisibleBy5 = number % 5 == 0;
        if (divisibleBy3 || divisibleBy5) {
            if (divisibleBy3 && divisibleBy5) {
                return "FizzBuzz";
            } else if (divisibleBy3) {
                return "Fizz";
            } else if (divisibleBy5) {
                return "Buzz";
            }
        }
        return String.valueOf(number);
    }

    public String countTo(int number) {
        LinkedList<String> myList = new LinkedList<String>();
        for (int i = 1; i <= number; i++) {
            myList.add(checkNumber(i));
        }
        return myList.toString();
    }


}