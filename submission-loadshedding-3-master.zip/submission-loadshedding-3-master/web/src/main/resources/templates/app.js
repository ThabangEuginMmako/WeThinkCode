var province_List = ""
var town_List = ""

const defaultTemplate = Handlebars.compile($('#default-template').html());
const townsPage = Handlebars.compile($('#town-list-template').html());
const schedulePage = Handlebars.compile($('#schedule-list-template').html());



async function getProvinces() {
    console.log('Getting provinces...');

    const options = {
        method: 'GET',
        headers: {
            "Content-Type": "application/json",
        },
    };

    let response = await fetch('http://localhost:7000/provinces', options)
    province_List = await response.json();
    console.log(province_List);

    const template = document.getElementById('province_list_template').innerText;
    const compiledFunction = Handlebars.compile(template);
    document.getElementById('province_list').innerHTML = compiledFunction(province_List);
}

async function getTownsOfProvince() {
    console.log('Getting Towns...');

    var province = window.location.href.split("?")[1];

    const options = {
        method: 'GET',
        headers: {
            "Content-Type": "application/json",
        },
    };

    let townResponse = await fetch(`http://localhost:7000/towns/${province}`, options)
    town_List = await townResponse.json();

    const template = document.getElementById('town-list-response-template').innerText;
    const compiledFunction = Handlebars.compile(template);
    document.getElementById('town_list').innerHTML = compiledFunction(town_List);
}

async function getSchedule() {
    console.log('Getting schedules...')

    var province = window.location.href.split('?')[1];
    var town = window.location.href.split('?')[2];
    var stage = 0;

    const options = {
        method: 'GET',
        headers: {
            "Content-Type": "application/json",
            // "Access-Control-Allow-Origin": "http://localhost:6969/*",
        },
    };

    let schedulesResponse = await fetch(`http://localhost:7002/${province}/${town}/${stage}`, options)
    loadsheddingSchedule = await schedulesResponse.json();
    loadsheddingSchedule.startDate = loadsheddingSchedule.startDate[2]+"/"+loadsheddingSchedule.startDate[1]+"/"+loadsheddingSchedule.startDate[0]
    loadsheddingSchedule.days.forEach(day => {
        day.slots.forEach(slot => {
            slot.start = slot.start[0]+":"+slot.start[1]+"0";
            slot.end = slot.end[0]+":"+slot.end[1]+"0";
        });
    });
    console.log(loadsheddingSchedule);

    const template = document.getElementById('schedule-response-template').innerText;
    const compiledFunction = Handlebars.compile(template);
    document.getElementById('schedule_list').innerHTML = compiledFunction(loadsheddingSchedule);
}

window.addEventListener("load", ()=> {

    const app = $('#app');

    const router = new Router({
        mode:'hash',
        root:'index.html',
        page404: (path) => {
            console.log('404');
            const html = defaultTemplate();
            app.html(html);
            getProvinces();
        }
    });

    router.add('/province_list', async () => {
        console.log('router');
        html = defaultTemplate();
        app.html(html);
        getProvinces();
    });

    router.add('/towns_list', async () => {
        html = townsPage();
        app.html(html);
        getTownsOfProvince();
    });

    router.add('/schedule', async () => {
        html = schedulePage();
        app.html(html);
        getSchedule();
    })

    console.log(`something`)
    router.addUriListener();
    router.navigateTo('/province_list');
})