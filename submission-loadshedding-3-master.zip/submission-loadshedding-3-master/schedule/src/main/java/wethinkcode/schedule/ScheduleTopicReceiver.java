package wethinkcode.schedule;

public class ScheduleTopicReceiver {
    //Modify default stage inside schedule service
}
